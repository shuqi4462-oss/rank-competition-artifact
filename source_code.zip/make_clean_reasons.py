"""Build compact reason annotation tables from the verified extraction."""
import csv
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent / 'reason_analysis'
OUT = ROOT / 'clean_annotation'
FIELDS = ['experiment', 'agent_id', 'round', 'intrinsic_ability',
          'rank_before_decision', 'investment', 'reason', 'label']


def save(path, rows):
    with path.open('w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(rows)


def main():
    OUT.mkdir(exist_ok=False)
    (OUT / 'by_experiment').mkdir()
    groups = defaultdict(list)
    with (ROOT / 'all_reasons.csv').open(encoding='utf-8-sig', newline='') as f:
        for row in csv.DictReader(f):
            experiment = row['experiment_id'].split('__exp')[0].replace('__', '_')
            groups[experiment].append({
                'experiment': experiment,
                'agent_id': row['agent_id'],
                'round': row['round'],
                'intrinsic_ability': row['intrinsic_ability'],
                'rank_before_decision': row['visible_rank_before_decision'],
                'investment': row['investment'],
                'reason': row['reason'],
                'label': '',
            })
    # Short experiment identifiers must still uniquely identify each run.
    assert len(groups) == len(list((ROOT / 'by_experiment').glob('*.csv')))
    rows = []
    for experiment, records in sorted(groups.items()):
        records.sort(key=lambda r: (int(r['agent_id']), int(r['round'])))
        assert len({(r['agent_id'], r['round']) for r in records}) == len(records)
        save(OUT / 'by_experiment' / f'{experiment}.csv', records)
        rows.extend(records)
    save(OUT / 'reasons_for_annotation.csv', rows)
    with (OUT / 'reasons_for_annotation.csv').open(encoding='utf-8-sig', newline='') as f:
        readback = list(csv.DictReader(f))
    assert readback == rows
    assert len(rows) == 180000
    (OUT / 'README.txt').write_text(
        'reasons_for_annotation.csv 是精简总表；by_experiment 内为按实验拆分的同格式表。\n'
        '同一实验内按 agent_id、round 排序，方便连续阅读每位 agent 的解释。\n\n'
        'experiment：实验条件，如 std1_q_0.4_reward_5000（std 为能力分布标准差，q 为获奖比例）。\n'
        'agent_id：该实验内的 agent 编号；与 experiment 合用可识别 agent。\n'
        'round：决策轮次。\n'
        'intrinsic_ability：真实能力，研究者可见，不代表 agent 已知。\n'
        'rank_before_decision：决策前最近公布的排名；首 5 轮无排名，留空。\n'
        'investment：本轮投资额。\n'
        'reason：完整原文，未改写、清洗或删除异常记录。\n'
        'label：留空，供人工标注。\n\n'
        'CSV 编码为 UTF-8 BOM，可用 Excel 打开。全部原始记录保留，完整提取文件仍在上级目录。\n',
        encoding='utf-8')
    print(f'Verified {len(rows)} rows, {len(groups)} experiments, {len(FIELDS)} columns.')


if __name__ == '__main__':
    main()
