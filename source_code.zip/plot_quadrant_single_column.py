"""Single-column Figure 10, no inset, larger budget-size contrast."""
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'output/pdf/collective_outcomes_v2'
d=pd.read_csv(OUT/'all16_plot_data.csv')
assert len(d)==16
plt.rcParams.update({'font.family':'Arial','font.size':7,'pdf.fonttype':42,'svg.fonttype':'none',
 'axes.labelsize':7.5,'xtick.labelsize':7,'ytick.labelsize':7,
 'text.color':'#26384B','axes.labelcolor':'#26384B','xtick.color':'#425466','ytick.color':'#425466',
 'axes.spines.top':False,'axes.spines.right':False})
fig,ax=plt.subplots(figsize=(3.35,3.65))
xlim=(-1.95,.52);ylim=(-.095,.212)
ax.set(xlim=xlim,ylim=ylim)
ax.fill_between([xlim[0],0],0,ylim[1],color='#EAF2EF',zorder=0)
ax.fill_between([0,xlim[1]],ylim[0],0,color='#F6ECE9',zorder=0)
size=lambda p: 12+260*(np.asarray(p)/2800000.)
norm=Normalize(.06,.7)
# Largest points first so small, nearby configurations remain visible on top.
plot=d.sort_values('P',ascending=False)
sc=ax.scatter(plot.DeltaD,plot.DeltaQ,s=size(plot.P),c=plot.q,cmap='viridis',norm=norm,
 edgecolors='#344B60',linewidths=.6,alpha=.82,zorder=3)
ax.axhline(0,color='#758391',lw=.65,ls=(0,(3,2)),zorder=1)
ax.axvline(0,color='#758391',lw=.65,ls=(0,(3,2)),zorder=1)
ax.set_xticks([-1.5,-1,-.5,0,.5]);ax.set_yticks([-.05,0,.05,.1,.15,.2])
ax.set_xlabel('$\Delta D$ (LLM $-$ Bayesian)',labelpad=3)
ax.set_ylabel('$\Delta Q$ (LLM $-$ Bayesian)',labelpad=3)
ax.tick_params(length=2,width=.5,pad=2)
ax.grid(color='#DFE5EB',lw=.45);ax.set_axisbelow(True)
ax.spines[['left','bottom']].set_color('#9BA7B3');ax.spines[['left','bottom']].set_linewidth(.55)
for x,y,t,ha,col in [(.02,.98,'Higher $Q$\nLower $D$','left','#386653'),
 (.98,.98,'Higher $Q$\nHigher $D$','right','#7E6A49'),
 (.02,.02,'Lower $Q$\nLower $D$','left','#65778B'),
 (.98,.02,'Lower $Q$\nHigher $D$','right','#934F46')]:
    ax.text(x,y,t,transform=ax.transAxes,ha=ha,va='top' if y>.5 else 'bottom',fontsize=6.6,color=col)
cax=fig.add_axes([.88,.29,.025,.62])
cb=fig.colorbar(sc,cax=cax,ticks=[.1,.4,.7]);cb.ax.tick_params(labelsize=6.5,length=2,pad=2)
cb.set_label('Winner proportion, $q$',fontsize=7,labelpad=4);cb.outline.set_linewidth(.4)
handles=[ax.scatter([],[],s=size(p),facecolor='#CED9E3',edgecolor='#63778A',lw=.5,label=lab)
 for p,lab in [(50000,'50k'),(250000,'250k'),(1000000,'1m'),(2800000,'2.8m')]]
fig.legend(handles=handles,title='Prize budget, $P$',loc='lower center',bbox_to_anchor=(.5,-.055),
 ncol=2,frameon=False,fontsize=6.3,title_fontsize=7,columnspacing=1.5,handletextpad=.7,handlelength=3.2,
 labelspacing=1.8)
fig.subplots_adjust(left=.17,right=.84,top=.94,bottom=.28)
for ext in ['pdf','png','svg']:
    fig.savefig(OUT/('collective_delta_single_column.'+ext),dpi=350,bbox_inches='tight',pad_inches=.045)
print('All 16 points; no inset; area = 12 + 260 P / 2,800,000')
