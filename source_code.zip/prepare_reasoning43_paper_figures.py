"""Paper-size renderings of already audited reasoning summaries."""
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=Path(__file__).resolve().parent/'output/reasoning43_reanalysis_20261022'
OUT=P/'paper_figures';OUT.mkdir(exist_ok=True)
C=['D1a','D1b','D1c','D2a','D2b','D2c','D2d','D3b']
N=['Reward-cost\ncomparison','Qualification\ntrade-off','Capital retention','Secure lead','Qualification at risk',
   'Catch-up attainable*','Catch-up unlikely','Weak investment\nreturns']
plt.rcParams.update({'font.family':'Arial','font.size':7,'axes.titlesize':8,'axes.labelsize':7,
 'xtick.labelsize':6.6,'ytick.labelsize':6.8,'pdf.fonttype':42,'svg.fonttype':'none',
 'axes.spines.top':False,'axes.spines.right':False,'axes.spines.left':False,
 'text.color':'#26384B','axes.labelcolor':'#26384B','xtick.color':'#425466','ytick.color':'#425466'})
def save(fig,name):
    fig.savefig(OUT/(name+'.pdf'),bbox_inches='tight',pad_inches=.035)
    fig.savefig(OUT/(name+'.png'),dpi=300,bbox_inches='tight',pad_inches=.035)
    plt.close(fig)
def annotate(ax,a,cut=55):
    for i in range(a.shape[0]):
        for j in range(a.shape[1]):ax.text(j,i,f'{a.iloc[i,j]:.1f}',ha='center',va='center',fontsize=6.8,color='white' if a.iloc[i,j]>cut else '#26384B')

d=pd.read_csv(P/'strategy_label_profiles.csv')
a=d[d.period=='post_feedback_snapshots'].pivot(index='code',columns='strategy',values='equal_condition_percent').loc[C,['aggressive','moderate','conservative']]
fig,ax=plt.subplots(figsize=(3.35,2.8))
im=ax.imshow(a,vmin=0,vmax=100,cmap='YlGnBu',aspect='auto')
ax.set(xticks=range(3),xticklabels=['Aggressive','Moderate','Conservative'],yticks=range(8),yticklabels=N)
ax.xaxis.tick_top();ax.tick_params(length=0,pad=3);annotate(ax,a)
for s in ax.spines.values():s.set_visible(False)
fig.subplots_adjust(left=.40,right=.99,top=.93,bottom=.16)
cax=fig.add_axes([.42,.06,.56,.035]);cb=fig.colorbar(im,cax=cax,orientation='horizontal',ticks=[0,25,50,75,100]);cb.set_label('Within-cluster prevalence (%)',labelpad=1);cb.outline.set_visible(False);cb.ax.tick_params(labelsize=6.3,pad=1,length=2)
save(fig,'reasoning43_strategy')

m=pd.read_csv(P/'matched_label_contrasts.csv')
fig,axs=plt.subplots(1,2,figsize=(6.85,2.95),sharey=True)
for ax,kind,title in zip(axs,['rank','ability'],['(a) Similar ability, different rank','(b) Similar rank, different ability']):
    mm=m[m.setting==kind+'_primary'].set_index('code').loc[C]
    per=pd.read_csv(P/(kind+'_primary_condition_effects.csv'))
    for i,c in enumerate(C):ax.scatter(per[c],np.repeat(i,len(per)),s=8,c='#8193A6',alpha=.40,edgecolors='none')
    ax.scatter(mm.delta_pp,np.arange(8),s=20,c='#173F70',zorder=3)
    ax.axvline(0,c='#8794A2',lw=.6,ls='--');ax.set_xlim(-25,25);ax.set_xticks([-20,-10,0,10,20])
    ax.set_title(title,loc='left',fontsize=7.8,pad=10)
    ax.set_yticks(range(8),N);ax.grid(axis='x',alpha=.12);ax.set_axisbelow(True)
    ax.set_xlabel('Judgment difference (percentage points)',labelpad=3);ax.tick_params(length=2,width=.5)
axs[0].invert_yaxis();fig.subplots_adjust(left=.215,right=.99,bottom=.14,top=.91,wspace=.15)
save(fig,'reasoning43_matching')

d=pd.read_csv(P/'judgments_near_reward_boundary.csv').set_index('boundary_position')
a=d.loc[['inside_buffer10plus','inside_last10','outside_first10','outside_farther10'],['D2a','D2b','D2c','D2d']]
fig,ax=plt.subplots(figsize=(3.35,1.8));im=ax.imshow(a,vmin=0,vmax=60,cmap='YlGnBu',aspect='auto')
ax.set(xticks=range(4),xticklabels=['Secure\nlead','At risk','Catch-up\nattainable*','Catch-up\nunlikely'],yticks=range(4),
       yticklabels=['Inside: buffer >=10','Inside: last 10','Outside: first 10','Outside: farther >10'])
ax.tick_params(length=0,pad=2);annotate(ax,a,32)
for s in ax.spines.values():s.set_visible(False)
fig.subplots_adjust(left=.36,right=.985,top=.99,bottom=.39)
cax=fig.add_axes([.41,.09,.54,.045]);cb=fig.colorbar(im,cax=cax,orientation='horizontal',ticks=[0,20,40,60]);cb.set_label('Judgment prevalence (%)',labelpad=1);cb.outline.set_visible(False);cb.ax.tick_params(labelsize=6.3,pad=1,length=2)
save(fig,'reasoning43_boundary')

fig,ax=plt.subplots(figsize=(3.35,2.5));d=pd.read_csv(P/'within_agent_rank_associations_std1.csv').set_index('code');val=d.loc[C,'pp_per20_better_rank']
ax.barh(N,val,color=['#52779C' if v>=0 else '#B66B58' for v in val]);ax.axvline(0,c='#8A929B',lw=.6)
for i,v in enumerate(val):ax.text(v+(.1 if v>=0 else -.1),i,f'{v:+.2f}',ha='left' if v>=0 else 'right',va='center',fontsize=6.4)
ax.invert_yaxis();ax.set_xlim(-7,8);ax.set_xlabel('Percentage points per 20-place better rank');ax.tick_params(length=2,width=.5)
fig.tight_layout(pad=.5);save(fig,'reasoning43_within_agent')

fig,axs=plt.subplots(1,2,figsize=(6.85,2.4))
d=pd.read_csv(P/'dimension_coverage.csv');d=d[d.period=='post_feedback']
names=['D1 Rewards/costs','D2 Perceived position','D3 Efficacy/ability','D4 Action intent','D5 Others']
axs[0].barh(names,d.equal_condition_percent,color='#52779C')
for i,v in enumerate(d.equal_condition_percent):axs[0].text(v+1,i,f'{v:.1f}%',va='center',fontsize=6.7)
axs[0].set(xlim=(0,112),xlabel='At least one substantive code (%)',title='(a) Five coding dimensions');axs[0].invert_yaxis()
d=pd.read_csv(P/'literal_topic_mentions_postfeedback.csv').set_index('topic')
cs=['focus_cost_reward','focus_position','focus_qualification','focus_effectiveness','focus_ability','focus_time','focus_others','focus_learning']
axs[1].barh(['Rewards/costs','Position','Qualification','Effectiveness','Own ability','Time','Others','Learning'],d.loc[cs,'equal_condition_percent'],color='#8A9254')
for i,v in enumerate(d.loc[cs,'equal_condition_percent']):axs[1].text(v+1,i,f'{v:.1f}%',va='center',fontsize=6.7)
axs[1].set(xlim=(0,115),xlabel='Literal topic mention (%)',title='(b) Separate topic-mention checks');axs[1].invert_yaxis()
fig.tight_layout(pad=.5,w_pad=2);save(fig,'reasoning43_coverage')

s=pd.read_csv(P/'matching_support.csv');fig,axs=plt.subplots(1,2,figsize=(6.85,2.5))
for ax,kind in zip(axs,['rank','ability']):
    h=s[s.setting.str.startswith(kind)].copy()
    lab=h.setting.str.replace(kind+'_','',regex=False).replace({'tight':'Ability gap <=0.025 SD','wide':'Ability gap <=0.10 SD','gap40':'Rank gap >=40',
        'rank5':'Rank gap <=5','rank20':'Rank gap <=20','gap05':'Ability gap >=0.5 SD','extreme_quartiles':'Extreme quartiles',
        'first_after_feedback':'First post-feedback round','primary':'Primary specification'})
    ax.barh(lab,h.n_pairs,color='#52779C')
    for i,v in enumerate(h.n_pairs):ax.text(v,i,f' {int(v):,}',va='center',fontsize=6.6)
    ax.invert_yaxis();ax.set_xlim(0,h.n_pairs.max()*1.24);ax.set_xlabel('Pairs within condition and round');ax.set_title('(a) Rank comparison' if kind=='rank' else '(b) Ability comparison',loc='left')
fig.tight_layout(pad=.5,w_pad=2);save(fig,'reasoning43_support')
print(OUT)
