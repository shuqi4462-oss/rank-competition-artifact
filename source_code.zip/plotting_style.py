"""Shared, muted strategy colors for the paper figures."""

STRATEGY_COLORS = {
    'aggressive': '#B66B58',
    'moderate': '#8A9254',
    'conservative': '#365D8D',
}
STRATEGY_LIGHT_COLORS = {
    'aggressive': '#EAD4CD',
    'moderate': '#E1E5CB',
    'conservative': '#CEDBED',
}

# 大面积柱形使用更明亮的同色系配色；保留散点图已确认的配色。
BAR_STRATEGY_COLORS = {
    'aggressive': '#CD7864',
    'moderate': '#9EAD5D',
    'conservative': '#4D7FB1',
}
