"""Conservative, evidence-linked initial coding of the reason corpus.

Uses reason text only. Labels are rule-assisted candidates, not adjudicated
human annotations or calibrated model predictions.
"""
import csv
import hashlib
import json
import random
import re
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'reason_analysis/clean_annotation/reasons_for_annotation.csv'
OUT = ROOT / 'reason_analysis/labeled_v1'
VERSION = 'rules_v1.1'

LABELS = {
    'D1a': '奖励金额比较', 'D1b': '获奖机会权衡', 'D1c': '保留资金优先', 'D1d': '探索价值', 'D1u': '未表达',
    'D2a': '安全领先', 'D2b': '资格受威胁', 'D2c': '可追赶', 'D2d': '难以追赶', 'D2e': '明确不确定', 'D2u': '未表达',
    'D3a': '投入有效', 'D3b': '投入效果弱', 'D3c': '效果不确定', 'D3d': '能力优势', 'D3e': '能力劣势', 'D3f': '噪声归因', 'D3u': '未表达',
    'D4a': '追赶', 'D4b': '保位', 'D4c': '节省', 'D4d': '退出', 'D4e': '试探', 'D4f': '维持', 'D4u': '未明确',
    'D5a': '跟随竞争投入', 'D5b': '预防他人加码', 'D5c': '利用他人低投入', 'D5d': '相对投入判断', 'D5u': '未表达',
    'Q1': '可编码', 'Q2': '信息不足', 'Q3': '系统异常',
}
# Sentence-local matches retain the exact source evidence; require relational
# language rather than coding from investment amounts or external ranks.
PATTERNS = {
 'D1a': [
  r'(?:reward|prize).{0,100}(?:outweigh|exceed|dominat|much larger|far larger|greater than|relative to|compared (?:with|to)).{0,90}(?:cost|capital|sav|invest|spend|100|5[,.]?000)',
  r'(?:cost|capital|saving|investment).{0,80}(?:small|minor|modest|negligible|limited|inexpensive|cheap|less|relative|compared).{0,90}(?:reward|prize)',
  r'(?:reward.to.cost|risk.reward) (?:ratio|trade.?off)',
  r'(?:reward|prize).{0,45}(?:greater|larger|large|substantial|high).{0,50}(?:justify|worth|cost)',
  r'(?:cost|risking|sacrificing).{0,65}(?:justified|worthwhile).{0,45}(?:larger|greater|substantial).{0,25}(?:prize|reward)',
 ],
 'D1b': [
  r'(?:reach|enter|qualif|recover).{0,65}(?:unlikely|little chance|negligible)',
  r'(?:probability|odds|chance).{0,110}(?:justify|worth|cost|sacrific|outweigh|valuable|value|preferable|gain|improv|increas|protect|preserv|maintain|maximi|raising)',
  r'(?:improv|increas|protect|preserv|maintain|maximi|raise|reducing).{0,80}(?:probability|odds|chance)',
  r'(?:additional|extra|further|another|single|one.final|this.round.s) (?:investment|spending|100|score).{0,100}(?:ranking|qualif|reward|cutoff).{0,80}(?:benefit|value|improv|protect|unlikely|limited|little)',
  r'(?:ranking|qualification|reward).{0,50}(?:benefit|protection|probability).{0,90}(?:limited|little|uncertain|justify|cost|sacrific)',
  r'(?:invest|spend).{0,65}(?:unlikely|little|minimal|limited).{0,70}(?:improv|change|protect|qualif|reward|ranking)',
  r'(?:low.probability|unlikely|unrealistic).{0,65}(?:recovery|reward|qualif|comeback|chance)',
 ],
 'D1c': [
  r'(?:preserv|retain|keep|secur|conserv|sav).{0,65}(?:wealth|capital|units|funds|money|100|guaranteed)',
  r'(?:guaranteed|certain|uninvested).{0,35}(?:wealth|capital|saving|funds|income)',
  r'(?:avoid|limit|reduc).{0,45}(?:wast|unnecessary (?:cost|spend)|loss of (?:wealth|capital))',
  r'capital preservation',
 ],
 'D1d': [
  r'\b(?:test|testing|experiment|probe|exploratory|exploration|benchmark)\b',
  r'(?:gather|obtain|collect|gain|learn|clarif|assess).{0,55}(?:information|signal|observation|evidence|whether|competitiveness)',
  r'(?:investment|invest|spend).{0,70}(?:learn|information|signal|diagnostic)',
 ],
 'D2a': [
  r'\b(?:comfortably|safely|securely|well|deep|far) (?:ranked|inside|within|above|ahead|in)\b',
  r'(?:strong|large|substantial|comfortable|ample|wide|safe) (?:current )?(?:ranking )?(?:buffer|cushion|margin)',
  r'(?:rank|position|qualification).{0,25}(?:is|remains|appears) (?:safe|secure)\b',
  r'(?:one|single|final).{0,40}(?:score|round).{0,55}(?:unlikely to|cannot|will not).{0,45}(?:erase|threaten|dislodge|eliminate).{0,30}(?:cushion|buffer|position|lead)',
 ],
 'D2b': [
  r'(?:limited|little|insufficient|not.{0,10}enough) (?:rank(?:ing)? )?(?:cushion|margin|buffer)',
  r'safely but not decisively|not with enough margin',
  r'(?:not|never|hardly|insufficiently) (?:yet |fully |comfortably |completely |safely )?(?:secure|safe|guaranteed)',
  r'(?:rank|position|qualification|eligible).{0,65}(?:precarious|vulnerable|not guaranteed|not secure|at risk|little (?:margin|buffer)|risk of|narrowly)',
  r'(?:narrowly|barely|only narrowly|just) (?:inside|within|eligible)',
  r'(?:inside|within|eligible).{0,70}(?:close.{0,20}(?:cutoff|boundary)|risk|threat)',
  r'(?:near|at|close to|exactly at).{0,35}(?:cutoff|boundary|reward line).{0,65}(?:protect|defen|risk|vulnerab|precarious)',
  r'(?:risk of|could|may|might).{0,40}(?:slipping|falling|dropping|losing).{0,35}(?:below|outside|qualif|eligib|reward)',
 ],
 'D2c': [
  r'(?:rank|position|gap|deficit|ranking).{0,65}(?:recoverable|within (?:plausible )?striking distance|realistic.{0,20}(?:chance|recovery)|close enough)',
  r'\b(?:still recoverable|within (?:plausible )?striking distance|realistic chance of (?:reaching|entering|qualifying)|plausible chance of (?:reaching|entering|qualifying))\b',
  r'(?:rounds|time) (?:remain|left|available).{0,70}(?:recover|move into|reach|improve from)',
  r'(?:still|enough).{0,25}(?:time|rounds).{0,65}(?:recover|catch up|reach|improve|qualif)',
  r'(?:only|just).{0,25}(?:ranks|places|positions).{0,25}(?:below|outside|away).{0,60}(?:chance|recover|reach|qualif)',
 ],
 'D2d': [
  r'(?:low|negligible|little|minimal) (?:likelihood|probability|chance).{0,45}(?:qualif|reach|recover|reward)',
  r'(?:too far|out of reach|unattainable|unrecoverable|almost.certain|no realistic (?:chance|path)|negligible chance)',
  r'(?:reach|enter|qualif|recover|catch up|close the gap).{0,80}(?:unlikely|implausible|unrealistic|improbable|nearly impossible|very low|little chance)',
  r'(?:unlikely|implausible|unrealistic|improbable|low.probability|very low.probability).{0,65}(?:recover|qualif|reward|catch|comeback|enter|reach)',
  r'(?:probability|chance|prospect|likelihood).{0,65}(?:recover|qualif|reward|reach).{0,45}(?:low|small|negligible|remote|limited)',
  r'(?:little|no|negligible|minimal) (?:realistic )?(?:chance|prospect|probability).{0,50}(?:qualif|reward|recover|reach)',
 ],
 'D2e': [
  r'(?:no|missing|without|lack of|insufficient|not enough).{0,30}(?:rank(?:ing)? (?:data|information|feedback|signal|evidence)|ranking)',
  r'(?:qualification|reward|top.{0,12}) (?:probability|chance).{0,25}(?:uncertain|unknown|unresolved|unclear)',
  r'(?:uncertain|unknown|unclear).{0,35}(?:competitiveness|competitive position|rank|qualification)',
 ],
 'D3a': [
  r'(?:recent|previous|prior|historical|last|higher|full|maximum|100.unit|investment level).{0,75}(?:investment|investments|investing|spending|level).{0,55}(?:produced|generated|yielded|delivered|supported).{0,20}(?:strong|best|positive|high|competitive|good|solid|favorable) (?:scores?|results?|performance)',
  r'(?:invest|spend).{0,30}(?:100|full|maximum|higher|more).{0,55}(?:produced|generated|yielded).{0,35}(?:strong|best|positive|high|competitive)',
  r'(?:zero|lower|low).{0,15}investment.{0,40}(?:caused|produced|generated).{0,20}(?:collapse|zero|weak|poor)',
  r'(?:only|strongest|best).{0,35}(?:investment|investing|100).{0,45}(?:produced|generated).{0,20}(?:positive|strong|best|high)',
 ],
 'D3b': [
  r'(?:investment|investments|spending|investing|conversion|score response|returns).{0,55}(?:weak|poor|ineffective|zero scores|near.zero|unreliable|no reliable|no clear|little|insufficient|no demonstrated)',
  r'(?:weak|poor|unreliable|ineffective|limited).{0,30}(?:investment|conversion|returns|score response|benefit from investing)',
  r'(?:no|little|not).{0,35}(?:evidence|benefit|improve|response).{0,50}(?:invest|spend)',
  r'no (?:consistent|reliable) scoring (?:advantage|benefit) from investing',
  r'zero.investment.{0,35}(?:as well as|same as|similar to).{0,25}(?:100|maximum|full)',
  r'(?:zero|low|lower|small|5.unit|10.unit).{0,20}(?:investment|investments|investing).{0,50}(?:strong|best|similar|same|positive|good|competitive|maintained|not threatened)',
  r'(?:higher|large|more|additional|extra).{0,25}(?:investment|spending).{0,55}(?:unnecessary|unjustified|not justified|no clear|no evidence)',
 ],
 'D3c': [
  r'(?:uncertain|unclear|unknown|unproven|unreliable|not established).{0,45}(?:effect|benefit|value|return|response|relationship|investment)',
  r'(?:investment|investments|investing|score response|marginal value|benefit).{0,50}(?:uncertain|unclear|unknown|unproven|not established)',
  r'(?:no|insufficient|not enough).{0,30}(?:evidence|observations|data).{0,55}(?:effect|investment|investing|spending|response)',
 ],
 'D3d': [
  r'(?:my|own|demonstrated|superior|strong|high).{0,20}(?:scoring |intrinsic )?ability.{0,35}(?:strong|high|advantage|superior)',
  r'(?:strong|high|superior) (?:intrinsic |scoring )?ability',
  r'(?:my|own).{0,25}(?:scoring advantage|ability advantage)',
 ],
 'D3e': [
  r'(?:weak|low|poor|limited|insufficient) (?:intrinsic |scoring |competitive )?ability',
  r'(?:my|own|scoring) ability.{0,35}(?:weak|low|poor|limited|insufficient)',
 ],
 'D3f': [r'\b(?:noise|noisy|randomness|random factors|luck|stochastic)\b'],
 'D4a': [
  r'(?:invest|spend|push|attempt).{0,150}(?:recover|catch up|close the gap|re.enter|cross.{0,12}cutoff|mov(?:e|ing) into|enter the reward|reach the reward)',
  r'(?:rank|position).{0,50}(?:requires?|needs?).{0,30}(?:recovery|aggressive|push|improvement)',
  r'(?:improv|recover).{0,20}(?:from rank|into the top|enough ranking|reward eligibility)',
 ],
 'D4b': [
  r'(?:protect\w*|defen\w*|preserv\w*|maintain\w*|secur\w*|safeguard\w*).{0,45}(?:my |the |current |existing |favorable |strong |top.{0,15})?(?:rank(?:ing)?|position|qualification|eligibility|buffer|cushion)',
  r'(?:qualification|rank) (?:protection|insurance)',
  r'(?:insurance|hedge).{0,45}(?:rank|qualif|deterioration|competitor)',
  r'(?:avoid|prevent|limit).{0,35}(?:losing|loss of|rank deterioration|falling outside|dropping below)',
 ],
 'D4c': [
  r'(?:invest(?:ing)? (?:0|zero|nothing)|retain|preserv|keep|conserv|sav|reduce|lower|small|modest|moderate|low.cost).{0,90}(?:wealth|capital|cost|spend|unnecessary|units)',
  r'(?:higher|large|additional|extra|further).{0,25}(?:investment|spending).{0,35}(?:unnecessary|not justified|unjustified)',
 ],
 'D4d': [
  r'(?:invest(?:ing)? (?:0|zero|nothing)|retain|preserv|keep|conserv|avoid|stop|withdraw|abandon|exit|give up).{0,70}(?:100|full|all|capital|wealth|investment|spending|competition|contest)',
  r'(?:rather than|instead of).{0,45}(?:spend|invest|sacrific|risk)',
 ],
 'D4e': [r'\b(?:test|testing|experiment|probe|exploratory|exploration|benchmark)\b',
          r'(?:gather|obtain|collect|learn|clarif).{0,45}(?:information|signal|observation|evidence|whether|competitiveness)'],
 'D4f': [r'\b(?:maintain|continue|repeat|keep|stick with|sustain).{0,45}(?:level|strategy|investment|investing|approach)',
          r'(?:same|recent|proven|established|consistent).{0,20}(?:strategy|investment level|approach)'],
}
COMPILED = {k:[re.compile(p,re.I) for p in ps] for k,ps in PATTERNS.items()}
OTHERS = re.compile(r'\b(?:other (?:agents|players|investors)|others|competitors?|rivals?|opponents?|neighbors?)\b',re.I)


def sentences(text):
    return [s.strip() for s in re.split(r'(?<=[.!?])\s+(?=[A-Z])',text) if s.strip()]


def matches(text):
    evidence = {}
    passages = sentences(text)
    for code, patterns in COMPILED.items():
        hits=[]
        for sentence in passages:
            if any(p.search(sentence) for p in patterns):
                hits.append(sentence)
        if hits:
            evidence[code]=list(dict.fromkeys(hits))
    return evidence


def code_reason(text):
    flags=[]
    if not text.strip():
        return {'D1':'D1u','D2':'D2u','D3':'D3u','D4_primary':'D4u','D4_secondary':'',
                'D5':'D5u','D5_source':'','quality':'Q2','review_reason':'空文本'}, {}
    if any(s in text for s in ['Error code:', '����', '熔断', '使用默认', 'No detailed reason']):
        return {'D1':'','D2':'','D3':'','D4_primary':'','D4_secondary':'',
                'D5':'','D5_source':'','quality':'Q3','review_reason':'系统错误或乱码'}, {}
    ev=matches(text)
    # Exclude explicit negation/low-return context from positive demonstrations
    # and intended actions. Preserve ambiguity rather than infer from metadata.
    if 'D1c' in ev:
        ev['D1c']=[s for s in ev['D1c'] if not re.search(r'(?:preserv|conserv|retain).{0,75}(?:less valuable|little value|would have little|provides little)',s,re.I)]
        if not ev['D1c']:del ev['D1c']
    if 'D2c' in ev:
        ev['D2c']=[s for s in ev['D2c'] if not re.search(r'\b(?:unlikely|implausible|impossible|low.probability|negligible chance)\b',s,re.I)]
        if not ev['D2c']:del ev['D2c']
    if 'D3a' in ev:
        ev['D3a']=[s for s in ev['D3a'] if not re.search(r'(?:zero|no|nothing|low)\W*investment.{0,55}(?:strong|best|positive|high)|(?:only strong score).{0,30}(?:zero|nothing)',s,re.I)]
        if not ev['D3a']:del ev['D3a']
    if 'D4a' in ev:
        ev['D4a']=[s for s in ev['D4a'] if not re.search(r'(?:rather than|instead of|avoid|not|stop).{0,50}(?:spend|invest|sacrific|risk).{0,55}(?:recover|reach|qualif)',s,re.I)]
        if not ev['D4a']:del ev['D4a']
    # Negative claims do not count as demonstrations of ability advantage.
    for code in ['D3d','D3e']:
        if code in ev:
            ev[code]=[s for s in ev[code] if not re.search(r'\b(?:no evidence|not proven|rather than proven|no demonstrated|without evidence|not shown sufficient)\b',s,re.I)]
            if not ev[code]: del ev[code]
    # A low-probability marginal benefit while already safe is not a low chance
    # of qualifying. Only retain D2d when the passage describes recovery/entry.
    if 'D2d' in ev:
        ev['D2d']=[s for s in ev['D2d'] if re.search(r'recover|catch|comeback|reach|enter|qualif|too far|out of reach|unattainable|unrecoverable|chance.{0,35}reward|reward.{0,35}unlikely',s,re.I)]
        if not ev['D2d']: del ev['D2d']
    if 'D2a' in ev:
        ev['D2a']=[s for s in ev['D2a'] if not re.search(r'not (?:comfortably|safely|securely|well) (?:inside|within|ranked|secure)|safely but not|comfortably but not',s,re.I)]
        if not ev['D2a']: del ev['D2a']
    other_sources=set()
    other_unmatched=False
    for sentence in sentences(text):
        if not OTHERS.search(sentence): continue
        lower=sentence.lower()
        if re.search(r'no.{0,35}(?:competitor|neighbor|other player).{0,10}(?:data|information)|once.{0,60}competitor behavior|after observing.{0,70}competitor|future.{0,60}other players',lower):
            other_unmatched=True
            continue
        code=None
        if re.search(r'(?:competitors?|others|other (?:agents|players)|rivals?|neighbors?).{0,45}(?:may|might|could|likely|expected|possible|potential|will).{0,45}(?:push|increas|rais|escalat|invest|spend|aggressive)|(?:competitor|others).{0,25}(?:push|surge|escalation)|(?:final|late).{0,20}(?:competitor|rival).{0,20}push',lower):
            code='D5b'
        elif re.search(r'(?:competitors?|others|other (?:agents|players)|rivals?|neighbors?).{0,55}(?:reduc|low investment|invest less|withdraw|exit|stop|conserv)|(?:others|competitors?).{0,30}lying flat',lower):
            code='D5c'
        elif re.search(r'(?:others|competitors?|other (?:agents|players)|rivals?|neighbors?).{0,50}(?:high|maximum|heavy|aggressive|more|increas).{0,40}(?:invest|spend)|(?:others|competitors?|other (?:agents|players)|rivals?|neighbors?).{0,35}(?:invest|spend).{0,15}(?:heavily|more|aggressively|a lot|high)|(?:match|keep up with).{0,35}(?:others|competitors?)',lower):
            code='D5a'
        elif re.search(r'(?:relative|compared|exceed|outspend|outinvest|below|above|than|against).{0,50}(?:others|competitors?|other (?:agents|players))|(?:others|competitors?).{0,55}(?:investment level|investments|spending|investing)',lower):
            code='D5d'
        if code:
            ev.setdefault(code,[]).append(sentence)
            if re.search(r'\b(?:may|might|could|expect|expected|likely|anticipat\w*|potential|possible|will)\b',lower):other_sources.add('预测假设')
            elif re.search(r'\b(?:observed|recent|have|has|were|was|last|currently|already|shown)\b',lower):other_sources.add('观察声称')
            else:other_sources.add('来源不明')
        else:other_unmatched=True
    if other_unmatched:flags.append('提及他人但当前D5标签证据不足')
    dims={}
    for dim in ['D1','D2','D3','D5']:
        codes=sorted(k for k in ev if k.startswith(dim))
        dims[dim]=';'.join(codes) if codes else dim+'u'
    if ';' in dims['D2']:flags.append('位置判断多标签，需判定主判断或矛盾')
    # Encode saving/withdrawal intent only with textual justification, not with
    # the numeric investment column or the researcher's rank assessment.
    intent=[]
    if 'D4d' in ev and 'D2d' in ev:
        intent.append('D4d')
    elif 'D4c' in ev and 'D2a' in ev:
        intent.append('D4c')
    if 'D4a' in ev:intent.append('D4a')
    if 'D4b' in ev:intent.append('D4b')
    if 'D4e' in ev:intent.append('D4e')
    if not intent and 'D4f' in ev:intent.append('D4f')
    if len(intent)>1:flags.append('多个行动目的，主次为规则建议')
    if len(intent)>2:flags.append('第三个行动目的详见证据文件')
    if not intent:flags.append('行动意图未明确匹配')
    if all(dims[d]==d+'u' for d in ['D1','D2','D3','D5']) and not intent:quality='Q2'
    else:quality='Q1'
    if re.search(r'\b(?:if|unless|future investment|later decisions|should be reduced|should be stopped)\b',text,re.I):
        flags.append('包含条件或未来行动，检查是否误作当前判断')
    if any(ord(c)>127 for c in text):flags.append('非ASCII文本，核查特殊字符或非英语表述')
    if dims['D2']=='D2u':flags.append('位置判断未明确匹配')
    dims.update({'D4_primary':intent[0] if intent else 'D4u',
                 'D4_secondary':intent[1] if len(intent)>1 else '',
                 'D5_source':';'.join(sorted(other_sources)), 'quality':quality,
                 'review_reason':'；'.join(dict.fromkeys(flags))})
    # Only emit evidence for actual assigned codes. Extra intent candidates
    # are preserved under a separate key for review.
    assigned=set(';'.join(dims[d] for d in ['D1','D2','D3','D5']).split(';'))
    assigned.update(intent)
    actual={k:v for k,v in ev.items() if k in assigned}
    if len(intent)>2:actual['other_action_candidates']=intent[2:]
    return dims,actual


def csv_write(path, rows, fields):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields)
        w.writeheader();w.writerows(rows)


def main():
    OUT.mkdir(exist_ok=True)
    base=['experiment','agent_id','round','intrinsic_ability','rank_before_decision','investment','reason']
    coding=['D1','D2','D3','D4_primary','D4_secondary','D5','D5_source','quality','evidence','review_reason','coder']
    fields=base+coding
    records=[];groups=defaultdict(list);counts=Counter();summary=[]
    with SOURCE.open(encoding='utf-8-sig',newline='') as f, (OUT/'evidence.jsonl').open('w',encoding='utf-8') as ef:
        for raw in csv.DictReader(f):
            codes,ev=code_reason(raw['reason'])
            row={k:raw[k] for k in base}
            row.update(codes)
            row['evidence']=' | '.join(k+': '+v[0] for k,v in ev.items() if k!='other_action_candidates')
            row['coder']=VERSION
            records.append(row);groups[row['experiment']].append(row)
            for d in ['D1','D2','D3','D4_primary','D4_secondary','D5','quality']:
                for c in row[d].split(';'):
                    if c:counts[(d,c)]+=1
            for code, passages in ev.items():
                if code=='other_action_candidates':continue
                assert all(s in raw['reason'] for s in passages)
            ef.write(json.dumps({'experiment':row['experiment'],'agent_id':row['agent_id'],'round':row['round'],
                                 'evidence':ev},ensure_ascii=False)+'\n')
    csv_write(OUT/'reasons_labeled.csv',records,fields)
    for experiment,rows in sorted(groups.items()):
        csv_write(OUT/'by_experiment'/f'{experiment}.csv',rows,fields)
        for dim in ['D1','D2','D3','D4_primary','D4_secondary','D5','quality']:
            cnt=Counter(c for r in rows for c in r[dim].split(';') if c)
            for code,n in sorted(cnt.items()):
                summary.append({'experiment':experiment,'dimension':dim,'code':code,'label':LABELS[code],
                                'count':n,'n_records':len(rows),'fraction':round(n/len(rows),6)})
    csv_write(OUT/'label_summary.csv',summary,list(summary[0]))
    # Reproducible pilot review: each experiment includes random records and
    # candidates selected for ambiguous positions/actions/other-agent claims.
    sample=[];rng=random.Random(20261012)
    for experiment,rows in sorted(groups.items()):
        picked=rng.sample(rows,20)
        special=[r for r in rows if ';' in r['D2'] or r['D5']!='D5u' or r['quality']!='Q1' or r['D4_secondary']]
        picked+=rng.sample(special,min(20,len(special)))
        seen=set()
        for r in picked:
            key=(r['agent_id'],r['round'])
            if key not in seen:
                sample.append({**r,'human_D1':'','human_D2':'','human_D3':'','human_D4_primary':'',
                               'human_D4_secondary':'','human_D5':'','human_quality':'','human_notes':''})
                seen.add(key)
    csv_write(OUT/'pilot_review.csv',sample,list(sample[0]))
    codebook=[{'code':k,'label':v,'dimension':k[:2] if not k.startswith('Q') else 'quality'} for k,v in LABELS.items()]
    csv_write(OUT/'codebook.csv',codebook,list(codebook[0]))
    # Exact round-trip and full corpus identity checks.
    with (OUT/'reasons_labeled.csv').open(encoding='utf-8-sig',newline='') as f:
        loaded=list(csv.DictReader(f))
    assert loaded==records
    assert len({(r['experiment'],r['agent_id'],r['round']) for r in records})==len(records)==180000
    for r in records:
        for dim in ['D1','D2','D3','D5']:
            codes=r[dim].split(';')
            assert not (len(codes)>1 and dim+'u' in codes)
            assert all(c in LABELS or not c for c in codes)
    report={'version':VERSION,'method':'sentence-local regex rules; provisional initial labels',
            'input_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
            'records':len(records),'experiments':len(groups),'pilot_review_records':len(sample),
            'rows_marked_for_review':sum(bool(r['review_reason']) for r in records),
            'system_records':sum(r['quality']=='Q3' for r in records),
            'roundtrip_verified':True,'identity_unique':True,'evidence_substrings_verified':True,
            'manual_adjudication_completed':False,'intercoder_reliability_measured':False,
            'label_counts':{d+':'+c:n for (d,c),n in sorted(counts.items())}}
    (OUT/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    (OUT/'rules.json').write_text(json.dumps({'version':VERSION,'patterns':PATTERNS},ensure_ascii=False,indent=2),encoding='utf-8')
    (OUT/'README.md').write_text('''# Reason 初始编码 v1

本版为基于 reason 原文的规则辅助初始编码，覆盖全部记录。没有使用 agent 的真实能力、实际排名、投资额或最终结果推断标签。
标签均为待验证的候选值，不是已完成人工裁决的金标准；未测量标注者一致性，未提供未经校准的置信度。

## 使用
- reasons_labeled.csv：总表；by_experiment/：18 份分实验表。
- pilot_review.csv：每实验随机抽样与歧义/少见标签抽样，附人工修正列。它是复核表，不是已经完成的人工验证。
- codebook.csv：标签代码与中文名；label_summary.csv：候选标签频数。多选比例合计可超过 100%。
- evidence.jsonl：所有命中原文证据；总表 evidence 列每个标签展示一个证据句。
- validation.json：完整性校验；rules.json：可追溯的匹配规则。详细流程脚本在项目根目录 label_reasons.py。

## 编码语义
D1 收益与投入逻辑：a 奖励金额比较；b 获奖机会权衡；c 保留资金优先；d 探索价值；u 未表达。
D2 主观竞争位置：a 安全领先；b 资格受威胁；c 可追赶；d 难以追赶；e 明确不确定；u 未表达。
D3 投入效果与能力：a 投入有效；b 投入效果弱；c 效果不确定；d 能力优势；e 能力劣势；f 噪声归因；u 未表达。
D4 行动意图：a 追赶；b 保位；c 节省；d 退出；e 试探；f 维持；u 未明确。
D5 他人行为：a 跟随竞争投入；b 预防他人加码；c 利用他人低投入；d 相对投入判断；u 未表达。
Q1 可编码；Q2 信息不足；Q3 系统异常。系统异常的维度留空，不伪装为模型未表达。

D1/D3/D5 多选，用分号分隔；u 与实质标签互斥。D2 本应单选，但冲突候选保留多标签并标记待复核，不强行裁决。
D4_primary/D4_secondary 为规则建议主次：有退出/安全节省证据时先列，再列追赶、保位、试探；多个目的全部待复核。
节省需文本中安全领先证据；退出需难以追赶证据。单凭投资为零不能编码退出。
D5_source 只表示文本声称观察到、预测假设或来源不明，不表示真实拥有他人行为信息。
u 在本版仅表示规则未匹配到明确表达，不能直接解释为模型没有该想法；隐含表达、否定、条件句和同义表述可能漏判或误判。
review_reason 记录规则已发现的复核理由；无标记也不代表无需抽查。条件/未来陈述需与当前行动区分。
intrinsic_ability 是真实能力；rank_before_decision 是决策前公布排名；未获反馈时为空。
reason 全部原样保留，包括系统异常；原始精简表未修改，原 label 列为空时在新表中移除。

## 后续研究
先对 pilot_review 独立人工复核，修订边界与规则，再形成后续版本。初始频数不能直接作为论文最终结论。
本版没有进行跨轮更新编码，完成单条复核后才能比较同一 agent 的标签变化。
''',encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
