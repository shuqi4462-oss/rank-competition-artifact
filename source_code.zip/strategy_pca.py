#!/usr/bin/env python3
"""
全局聚类的 PCA 散点图。
合并所有 Q、reward 和快照轮次，只拟合一次 TF-IDF、K-Means 和 PCA。
只绘制两张图：
  1. 固定 R=20000，分面 Q=0.1, 0.4, 0.7（3列 × 5行）
  2. 固定 Q=0.4，分面 R=2500, 5000, 10000, 20000（4列 × 5行）
"""
import os, sys, json
import numpy as np
import re
import matplotlib
matplotlib.rcParams.update({
    'font.family': 'Arial', 'mathtext.fontset': 'dejavusans',
    'pdf.fonttype': 42, 'ps.fonttype': 42,
    'text.color': '#25282C', 'axes.labelcolor': '#25282C',
    'xtick.color': '#454B51', 'ytick.color': '#454B51',
})
import matplotlib.pyplot as plt
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from collections import defaultdict, Counter
from matplotlib.patches import Ellipse
from matplotlib.lines import Line2D
from matplotlib.ticker import MaxNLocator
from scipy.stats import chi2
from plotting_style import STRATEGY_COLORS, STRATEGY_LIGHT_COLORS

# =====================================================================
# 第一部分：全局配置
# =====================================================================
PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_ROOT = os.path.join(PROJECT_DIR, "data", "reward_experiment", "llm_reward")
STD_DIR = "std1"
Q_LIST = ["0.1", "0.4", "0.7"]
REWARDS = ["2500", "5000", "10000", "20000"]
SNAPSHOT_ROUNDS = [5, 15, 25, 35, 45]
OUTPUT_DIR = os.path.join(PROJECT_DIR, "pic")
os.makedirs(OUTPUT_DIR, exist_ok=True)

N_STRATEGIES = 3
STRATEGY_NAMES = ["aggressive", "moderate", "conservative"]

# =====================================================================
# 第二部分：自动扫描实验目录
# =====================================================================
def scan_exp_dirs(data_root, std_dir, q_list, rewards):
    exp_dir_map = {}
    std_path = os.path.join(data_root, std_dir)
    for q in q_list:
        q_dir = os.path.join(std_path, f"q_{q}")
        if not os.path.exists(q_dir):
            continue
        for reward in rewards:
            r_dir = os.path.join(q_dir, f"reward_{reward}")
            if not os.path.exists(r_dir):
                continue
            subdirs = sorted([d for d in os.listdir(r_dir)
                              if d.startswith("exp") and os.path.isdir(os.path.join(r_dir, d))])
            if subdirs:
                exp_dir_map[(q, reward)] = subdirs[-1]
    return exp_dir_map

print("Scanning experiment directories...")
EXP_DIR_MAP = scan_exp_dirs(DATA_ROOT, STD_DIR, Q_LIST, REWARDS)
print(f"Found {len(EXP_DIR_MAP)} (Q, R) combinations")

# =====================================================================
# 第三部分：文本归一化
# =====================================================================
def normalize_reason_text(text):
    text = re.sub(r'\b(2500|5000|10000|20000)\b', '[REWARD]', text)
    text = re.sub(r'\b1\b(?!\d)', '[REWARD]', text)
    text = re.sub(r'rank\s*\d+', '[RANK]', text, flags=re.IGNORECASE)
    text = re.sub(r'\d+\s*rounds?\s*(left|remaining)', '[ROUNDS_LEFT]', text, flags=re.IGNORECASE)
    text = re.sub(r'invest(ment)?\s*\d+', 'invest [INVEST]', text, flags=re.IGNORECASE)
    text = re.sub(r'\b\d+\s*units?\b', '[UNITS]', text)
    text = re.sub(r'top\s*\d+%?', '[TOP_X]', text, flags=re.IGNORECASE)
    text = re.sub(r'score\s*[\d.]+', 'score [SCORE]', text, flags=re.IGNORECASE)
    return text

# =====================================================================
# 第四部分：所有条件共同拟合 TF-IDF + PCA + K-Means
# =====================================================================
def cluster_globally():
    """一次拟合全部实验条件，所有分面共享坐标系和策略分类标准。"""
    texts, meta = [], []
    for (q, reward), exp_dir in EXP_DIR_MAP.items():
        rounds_dir = os.path.join(DATA_ROOT, STD_DIR, f"q_{q}",
                                  f"reward_{reward}", exp_dir, "expdata", "rounds")
        for rnd in SNAPSHOT_ROUNDS:
            fname = os.path.join(rounds_dir, f"round_{rnd:03d}.json")
            if not os.path.exists(fname):
                continue
            with open(fname, encoding='utf-8') as f:
                data = json.load(f)
            for agent in data.get("agents_data", []):
                r = agent.get("reason", "")
                if not r or len(r) < 5:
                    continue
                texts.append(normalize_reason_text(r))
                meta.append((
                    q, rnd, int(agent["agent_id"]),
                    float(agent.get("current_round_investment", 0)),
                    int(agent.get("rank", 100)), reward,
                ))
    
    print(f"  GLOBAL: {len(texts)} samples across {len(EXP_DIR_MAP)} conditions")
    if len(texts) == 0:
        raise RuntimeError('No source data found; no figures generated.')
    
    # TF-IDF
    vec = TfidfVectorizer(stop_words='english', max_df=0.8, min_df=3,
                          max_features=600, ngram_range=(1, 3))
    tfidf = vec.fit_transform(texts)
    
    # PCA
    pca = PCA(n_components=2, random_state=42)
    coords = pca.fit_transform(tfidf.toarray())
    
    # K-Means
    km = KMeans(n_clusters=N_STRATEGIES, random_state=42, n_init=10)
    labels = km.fit_predict(tfidf)
    
    # 按平均投资额命名
    cluster_invest = defaultdict(list)
    for i, lab in enumerate(labels):
        cluster_invest[lab].append(meta[i][3])
    cluster_mean = {k: np.mean(v) for k, v in cluster_invest.items()}
    sorted_clusters = sorted(cluster_mean.items(), key=lambda x: x[1], reverse=True)
    cmap = {old: STRATEGY_NAMES[rank] for rank, (old, _) in enumerate(sorted_clusters)}
    strategy_labels = [cmap[l] for l in labels]
    
    print(f"    Cluster map: {cmap}")
    return {
        "coords": coords,
        "strategy_labels": strategy_labels,
        "meta": meta,
        "pca_model": pca,
    }

# 仅此处拟合一次；下面按 reward 切片，不再拟合模型。
print("\nPerforming GLOBAL TF-IDF, PCA and K-Means...")
global_result = cluster_globally()
reward_results = {}
for r in REWARDS:
    indices = [i for i, m in enumerate(global_result['meta']) if m[5] == r]
    if indices:
        reward_results[r] = {
            'coords': global_result['coords'][indices],
            'strategy_labels': [global_result['strategy_labels'][i] for i in indices],
            'meta': [global_result['meta'][i][:5] for i in indices],
        }
assert sum(len(r['meta']) for r in reward_results.values()) == len(global_result['meta'])
with open(os.path.join(OUTPUT_DIR, 'pca_global_analysis.json'), 'w', encoding='utf-8') as f:
    json.dump({
        'clustering_scope': 'global', 'sample_count': len(global_result['meta']),
        'condition_count': len(EXP_DIR_MAP), 'random_state': 42,
        'strategy_counts': dict(Counter(global_result['strategy_labels'])),
        'pca_explained_variance_ratio': global_result['pca_model'].explained_variance_ratio_.tolist(),
        'experiments': [{'q': q, 'reward': r, 'directory': d}
                        for (q, r), d in EXP_DIR_MAP.items()],
    }, f, indent=2)
np.savez_compressed(os.path.join(OUTPUT_DIR, 'pca_global_coordinates.npz'),
                    coords=global_result['coords'],
                    strategies=global_result['strategy_labels'],
                    meta=np.asarray(global_result['meta']))

# =====================================================================
# 第五部分：置信椭圆
# =====================================================================
def draw_confidence_ellipse(ax, x, y, color, alpha=0.5):
    if len(x) < 3:
        return
    cov = np.cov(x, y)
    if np.isnan(cov).any() or np.linalg.det(cov) == 0:
        return
    eigenvals, eigenvecs = np.linalg.eigh(cov)
    eigenvals = np.maximum(eigenvals, 0)
    angle = np.degrees(np.arctan2(eigenvecs[1, 0], eigenvecs[0, 0]))
    chi2_val = chi2.ppf(0.80, 2)
    width, height = 2 * np.sqrt(eigenvals * chi2_val)
    ellipse = Ellipse(xy=(np.mean(x), np.mean(y)), width=width, height=height,
                      angle=angle, edgecolor='none', facecolor=color,
                      linewidth=0, alpha=alpha, zorder=1)
    ax.add_patch(ellipse)

# =====================================================================
# 第六部分：绘图函数
# =====================================================================
def plot_facet(reward_or_q, mode, facet_values, out_suffix):
    """
    mode='R'：固定 R，分面 Q；mode='Q'：固定 Q，分面 R。
    两者均使用同一份全局聚类和 PCA 结果。
    """
    n_rows = len(SNAPSHOT_ROUNDS)
    n_cols = len(facet_values)
    # 紧凑的论文版面；共享坐标刻度仅放在最外侧。
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(10.8, 11.4),
                             sharex=True, sharey=True, squeeze=False)

    FS_TITLE = 17
    FS_LABEL = 17
    FS_TICK = 12
    FS_ROUND = 15

    # 两张图使用相同范围，并容纳所有原始散点，避免固定范围裁掉数据。
    all_coords = np.concatenate([res['coords'] for res in reward_results.values()])
    lower = all_coords.min(axis=0)
    upper = all_coords.max(axis=0)
    padding = np.maximum((upper - lower) * 0.06, 0.02)

    for ri, rnd in enumerate(SNAPSHOT_ROUNDS):
        for ci, val in enumerate(facet_values):
            ax = axes[ri, ci]
            # 决定该子图使用哪个 reward 的聚类结果
            if mode == 'R':
                reward = reward_or_q   # 固定 R
                q_filter = val          # 分面 Q
            else:
                reward = val            # 分面 R
                q_filter = reward_or_q  # 固定 Q

            res = reward_results.get(reward)
            if res is None:
                ax.text(0.5, 0.5, "No data", ha='center', va='center')
                continue

            # 从该 reward 的结果中筛选出当前 (Q, Round) 的点
            points = []
            for idx, (q, r, aid, invest, rank) in enumerate(res["meta"]):
                if r != rnd or q != q_filter:
                    continue
                points.append({
                    "pca_x": res["coords"][idx, 0],
                    "pca_y": res["coords"][idx, 1],
                    "strategy": res["strategy_labels"][idx],
                })

            if not points:
                ax.text(0.5, 0.5, "No data", ha='center', va='center')
                continue

            # 按策略分组画椭圆和散点
            grouped = defaultdict(list)
            for p in points:
                grouped[p["strategy"]].append(p)
            for strategy, pts in grouped.items():
                xs = [p["pca_x"] for p in pts]
                ys = [p["pca_y"] for p in pts]
                draw_confidence_ellipse(ax, xs, ys,
                                        color=STRATEGY_LIGHT_COLORS[strategy],
                                        alpha=0.5)
            for strategy, pts in grouped.items():
                ax.scatter([p['pca_x'] for p in pts], [p['pca_y'] for p in pts],
                          c=STRATEGY_COLORS[strategy],
                          s=17, alpha=0.88, edgecolors='white', linewidth=0.25,
                          zorder=2, rasterized=True)

            # 坐标轴设置
            ax.set_xlim(lower[0] - padding[0], upper[0] + padding[0])
            ax.set_ylim(lower[1] - padding[1], upper[1] + padding[1])
            ax.grid(False)
            ax.axhline(0, color='#E4E7E9', linewidth=0.55, zorder=0)
            ax.set_axisbelow(True)
            for side, spine in ax.spines.items():
                spine.set_visible(side in ('left', 'bottom'))
                spine.set_linewidth(0.65)
                spine.set_color('#7A8188')
            ax.tick_params(axis='both', labelsize=FS_TICK, direction='out',
                           length=3, width=0.7, pad=5,
                           labelbottom=(ri == n_rows - 1), labelleft=(ci == 0))
            ax.set_xticks([-0.2, 0.0, 0.2, 0.4])
            ax.set_yticks([-0.3, 0.0, 0.3])

            # 子图标题
            if ri == 0:
                label = f'q = {val}' if mode == 'R' else f'R = {int(val):,}'
                ax.set_title(label, fontsize=FS_TITLE, fontweight='medium', pad=10)

    fig.subplots_adjust(left=0.115, right=0.99, top=0.885, bottom=0.065,
                        wspace=0.07, hspace=0.09)
    # 使用统一的画布坐标，保证 3 列和 4 列并排时行标签完全对齐。
    for ri, rnd in enumerate(SNAPSHOT_ROUNDS):
        pos = axes[ri, 0].get_position()
        fig.text(0.055, (pos.y0 + pos.y1) / 2, f'Round {rnd}',
                 rotation=90, va='center', ha='center',
                 fontsize=FS_ROUND)
    fixed = f'R = {int(reward_or_q):,}' if mode == 'R' else f'q = {reward_or_q}'
    fig.suptitle(f'Global strategy differentiation ({fixed})',
                 x=0.54, y=0.985, fontsize=19, fontweight='bold')
    fig.text(0.019, 0.985, 'a' if mode == 'R' else 'b',
             fontsize=23, fontweight='bold', ha='left', va='top')
    handles = [Line2D([], [], linestyle='none', marker='o', markersize=8,
                      markerfacecolor=STRATEGY_COLORS[s], markeredgecolor='white',
                      label=s.capitalize()) for s in STRATEGY_NAMES]
    fig.legend(handles=handles, loc='upper center', bbox_to_anchor=(0.54, 0.954),
               ncol=3, frameon=False, fontsize=14, columnspacing=1.8,
               handletextpad=0.4)
    fig.supxlabel('PC1', x=0.55, y=0.012, fontsize=FS_LABEL)
    fig.supylabel('PC2', x=0.019, y=0.48, fontsize=FS_LABEL)

    for extension in ('pdf', 'png'):
        out_path = os.path.join(OUTPUT_DIR, f"pca_scatter_{out_suffix}.{extension}")
        # 保持相同页面尺寸和边界，避免独立裁边破坏并排对齐。
        fig.savefig(out_path, dpi=300)
        print(f"Saved: {out_path}")
    plt.close(fig)

# =====================================================================
# 第七部分：只绘制两张图
# =====================================================================
print("\nPlotting Figure 1: fixed R=20000, facet by Q")
plot_facet('20000', 'R', Q_LIST, 'R20000')

print("\nPlotting Figure 2: fixed Q=0.4, facet by R")
plot_facet('0.4', 'Q', REWARDS, 'q0.4')

def export_side_by_side():
    from pypdf import PdfReader, PdfWriter, Transformation
    from PIL import Image
    names = ['pca_scatter_R20000', 'pca_scatter_q0.4']
    pages = [PdfReader(os.path.join(OUTPUT_DIR, n + '.pdf')).pages[0] for n in names]
    w, h = float(pages[0].mediabox.width), float(pages[0].mediabox.height)
    assert all(float(p.mediabox.width) == w and float(p.mediabox.height) == h for p in pages)
    writer = PdfWriter()
    page = writer.add_blank_page(width=2 * w, height=h)
    page.merge_page(pages[0])
    page.merge_transformed_page(pages[1], Transformation().translate(tx=w, ty=0))
    writer.write(os.path.join(OUTPUT_DIR, 'pca_scatter_selected_side_by_side.pdf'))
    images = [Image.open(os.path.join(OUTPUT_DIR, n + '.png')) for n in names]
    assert images[0].size == images[1].size
    width, height = images[0].size
    combined = Image.new('RGB', (2 * width, height), 'white')
    for i, image in enumerate(images):
        combined.paste(image, (i * width, 0))
        image.close()
    combined.save(os.path.join(OUTPUT_DIR, 'pca_scatter_selected_side_by_side.png'))


export_side_by_side()
print("All done!")
