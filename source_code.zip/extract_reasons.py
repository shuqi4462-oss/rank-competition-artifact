"""Extract original LLM reasons and analysis metadata without changing source files."""
import csv
import hashlib
import json
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'data/reward_experiment/llm_reward'
OUT = ROOT / 'reason_analysis'
FIELDS = ['record_id', 'experiment_id', 'agent_uid', 'agent_id', 'ability_std', 'q', 'reward',
          'round', 'remaining_rounds_including_current', 'reward_cutoff_rank', 'reason',
          'investment', 'previous_investment', 'score', 'previous_score', 'intrinsic_ability',
          'ability_assessment_logged_after_round', 'visible_rank_before_decision',
          'visible_rank_published_round', 'visible_avg_score_before_decision',
          'rank_distance_to_cutoff_before_decision', 'in_reward_zone_before_decision',
          'rank_logged_after_round', 'avg_score_logged_after_round', 'total_assets_logged',
          'total_investment_logged', 'cumulative_investment_reconstructed',
          'retained_capital_reconstructed', 'financial_identity_difference',
          'reason_status', 'source_file']


def write_csv(path, rows, fields):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def main():
    OUT.mkdir(exist_ok=False)
    all_rows, index, manifest = [], [], []
    for rounds_dir in sorted(SOURCE.glob('**/rounds')):
        parts = rounds_dir.relative_to(SOURCE).parts
        std, qpart, rewardpart, run = parts[:4]
        sigma, q, reward = float(std[3:]), float(qpart[2:]), float(rewardpart[7:])
        experiment = '__'.join(parts[:4])
        files = sorted(rounds_dir.glob('round_*.json'))
        last_round = max(json.loads(f.read_text(encoding='utf-8'))['round'] for f in files)
        rows, by_agent, prev, cumul = [], defaultdict(list), {}, defaultdict(float)
        ranks, averages, published = {}, {}, {}
        hashes = []
        for file in files:
            raw = file.read_bytes()
            data = json.loads(raw)
            t, agents = data['round'], data['agents_data']
            cutoff = round(len(agents) * q)
            hashes.append({'file': file.relative_to(ROOT).as_posix(), 'sha256': hashlib.sha256(raw).hexdigest()})
            for a in sorted(agents, key=lambda x: x['agent_id']):
                aid = a['agent_id']
                investment = a.get('current_round_investment', a.get('input'))
                assert investment is not None
                cumul[aid] += investment
                reason = a.get('reason')
                assert reason is None or isinstance(reason, str)
                rank = ranks.get(aid)
                old = prev.get(aid, {})
                status = ('missing' if not reason else 'system_message' if
                          any(k in reason for k in ['Error code:', '默认', '熔断', 'No detailed reason', '����'])
                          else 'text')
                assets, total = a.get('total_assets'), a.get('total_investment')
                row = dict(zip(FIELDS, [
                    f'{experiment}__agent_{aid:03d}__round_{t:03d}', experiment,
                    f'{experiment}__agent_{aid:03d}', aid, sigma, q, reward, t, last_round-t+1,
                    cutoff, reason, investment, old.get('investment'), a.get('score'), old.get('score'),
                    a.get('calculation_details', {}).get('intrinsic_ability'), a.get('ability_assessment'),
                    rank, published.get(aid), averages.get(aid), None if rank is None else rank-cutoff,
                    None if rank is None else int(rank <= cutoff), a.get('rank'), a.get('avg_score'),
                    assets, total, cumul[aid], 100*t-cumul[aid],
                    None if assets is None or total is None else round(assets+total-100*t, 6),
                    status, file.relative_to(ROOT).as_posix()]))
                rows.append(row)
                by_agent[aid].append(row)
                prev[aid] = row
                # Published rankings are written after this round's decision.
                if t % 5 == 0:
                    ranks[aid], averages[aid], published[aid] = a.get('rank'), a.get('avg_score'), t
        write_csv(OUT / 'by_experiment' / f'{experiment}.csv', rows, FIELDS)
        agent_path = OUT / 'by_agent' / f'{experiment}.jsonl'
        agent_path.parent.mkdir(exist_ok=True)
        with agent_path.open('w', encoding='utf-8', newline='\n') as f:
            for aid, history in sorted(by_agent.items()):
                summary = {'agent_uid': history[0]['agent_uid'], 'experiment_id': experiment,
                           'agent_id': aid, 'ability_std': sigma, 'q': q, 'reward': reward,
                           'intrinsic_ability': history[0]['intrinsic_ability'], 'n_records': len(history),
                           'mean_investment': sum(r['investment'] for r in history)/len(history),
                           'zero_investment_rounds': sum(r['investment']==0 for r in history),
                           'final_rank': history[-1]['rank_logged_after_round'],
                           'won_reward': int(history[-1]['rank_logged_after_round'] <= cutoff),
                           'agent_history_file': agent_path.relative_to(OUT).as_posix()}
                index.append(summary)
                f.write(json.dumps({**summary, 'rounds': history}, ensure_ascii=False)+'\n')
        all_rows.extend(rows)
        manifest.append({'experiment_id': experiment, 'round_files': len(files), 'agents': len(by_agent),
                         'records': len(rows), 'source_hashes': hashes})
    write_csv(OUT / 'all_reasons.csv', all_rows, FIELDS)
    write_csv(OUT / 'agent_index.csv', index, list(index[0]))
    ids = [r['record_id'] for r in all_rows]
    assert len(set(ids)) == len(ids)
    # Verify CSV round-trip preserves every reason, key and value representation.
    with (OUT/'all_reasons.csv').open(encoding='utf-8-sig', newline='') as f:
        loaded = list(csv.DictReader(f))
    assert len(loaded) == len(all_rows)
    for actual, expected in zip(loaded, all_rows):
        assert all(actual[k] == ('' if expected[k] is None else str(expected[k])) for k in FIELDS)
    report = {'experiments': len(manifest), 'records': len(all_rows), 'agent_trajectories': len(index),
              'missing_reasons': sum(r['reason_status']=='missing' for r in all_rows),
              'system_messages_flagged': sum(r['reason_status']=='system_message' for r in all_rows),
              'financial_identity_anomalies': sum(abs(r['financial_identity_difference'] or 0)>0.01 for r in all_rows),
              'unique_record_ids': True, 'csv_roundtrip_verified_all_fields': True,
              'ranking_publish_interval': 5, 'capital_per_round': 100, 'experiments_detail': manifest}
    (OUT/'extraction_manifest.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    (OUT/'README.md').write_text('''# LLM reason 提取数据

## 文件
- all_reasons.csv：全部逐轮决策，一行对应一个实验内的一位 agent 的一轮决策。
- by_experiment/：按实验拆分的 CSV，列结构与总表一致。
- by_agent/：按实验拆分的 JSONL；每行是一位 agent 的完整逐轮记录，rounds 数组按轮次排序。
- agent_index.csv：每个实验内 agent 的索引及行为汇总；汇总与最终结果仅用于研究分组，不是决策时已知信息。
- extraction_manifest.json：提取数量、校验结果以及全部源文件 SHA256。

## 身份和实验条件
agent_id 是源记录 ID；不同实验中会重复。agent_uid 包含实验 ID，唯一识别一条 agent 轨迹。
record_id 唯一识别一条逐轮记录。experiment_id 保留 std、q、reward 和实际运行目录名称。
ability_std 是能力分布的标准差，q 是获奖比例，reward 是每个获奖者的奖励。
intrinsic_ability 是研究者可见的真实能力，不代表 agent 决策时知道该数值。
reward_cutoff_rank 是奖励区最大名次。remaining_rounds_including_current 包括当前轮。

## 排名及时间对齐
visible_rank_before_decision / visible_avg_score_before_decision 是决策前最近一次公布的排名及平均分。
visible_rank_published_round 是该反馈公布轮次；首个反馈之前留空。
根据实验代码每 5 轮结束后公布排名：第 5 轮决策仍没有排名，第 6 轮可见第 5 轮排名；第 50 轮可见第 45 轮排名。
rank_logged_after_round / avg_score_logged_after_round 是源文件保存值；非公布轮可能沿用上次值。
rank_distance_to_cutoff_before_decision = 可见排名 - 获奖名次门槛；负值在奖励区内部，正值在外部。
in_reward_zone_before_decision 为 1/0；没有反馈时留空。previous_investment / previous_score 是上一轮行为及结果。
score 是当前决策后的得分，不应被当作当前决策前的信息。
ability_assessment_logged_after_round 同样保留日志时间语义，不应默认当作当前决策前的信念。

## 财务与数据质量
total_assets_logged / total_investment_logged 完整保留源数据值。
cumulative_investment_reconstructed 是按日志逐轮投资累计；retained_capital_reconstructed = 100 × round - 重建累计投资。
重建值是研究用计算，未替换原值，也不声称是 agent 当时实际看到的财务信息。
financial_identity_difference = 源累计资产 + 源累计投资 - 100 × round；非零表示账目恒等式异常，原因需另行核查。
reason 原样保留，不清洗、不翻译、不去重、不删失败记录。reason_status 的 system_message 仅为系统错误/乱码的候选标记，需人工确认。
空字段表示原始缺失或当前不可用，不等于零。CSV 为 UTF-8 BOM，可直接在 Excel 中打开；JSONL 为 UTF-8。
source_file 是相对项目根目录的原始文件路径，用于回溯。
未预置 aggressive/conservative 等主观分类，也未添加任何人工编码结论。
''',encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k!='experiments_detail'},ensure_ascii=False,indent=2))


if __name__ == '__main__':
    main()
