#!/usr/bin/env python3
"""
绘制能力 vs 排名、投入、财富的三行子图网格。
- 散点：与策略散点图一致的赭红色
- 默认不添加趋势线；可用 SHOW_TREND 开启分箱统计
- 两张图采用统一尺寸和简洁的论文版式
- 自动扫描数据路径，无需手动指定实验文件夹
图1：固定 reward=20000，分面 q = 0.1, 0.4, 0.7
图2：固定 q=0.4，分面 reward = 2500, 5000, 10000, 20000
Rank 纵轴：0 在下，200 在上
"""
import os, sys, json
import re
import numpy as np
import pandas as pd
import matplotlib
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator, FuncFormatter
from plotting_style import STRATEGY_COLORS

# ========================= 全局风格 =========================
mpl.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans"],
    "font.size": 14,
    "axes.titlesize": 17,
    "axes.labelsize": 16,
    "xtick.labelsize": 13,
    "ytick.labelsize": 13,
    "axes.linewidth": 0.8,
    "xtick.major.width": 0.7,
    "ytick.major.width": 0.7,
    "xtick.major.size": 3,
    "ytick.major.size": 3,
    "savefig.dpi": 300,
    "savefig.bbox": None,
    "mathtext.fontset": "dejavusans",
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "text.color": "#25282C",
    "axes.labelcolor": "#25282C",
})

# ========================= 配置 =========================
PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_ROOT = os.path.join(PROJECT_DIR, 'data', 'reward_experiment', 'llm_reward', 'std1')
OUTPUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pic")
os.makedirs(OUTPUT_DIR, exist_ok=True)

# 科研配色
COLOR_POINT   = STRATEGY_COLORS['aggressive']
COLOR_TREND   = "#245A78"   # 趋势线：深蓝
COLOR_BAND    = "#B8D1DE"   # 分位区间：浅蓝
COLOR_GRID    = "#DCE3E8"   # 网格：极浅灰
COLOR_TICK    = "#4A5560"   # 刻度文字
COLOR_BASELINE= "#D18B4C"   # 基准线（仅财富图用）

POINT_ALPHA   = 0.78
POINT_SIZE    = 20
SHOW_TREND    = False       # 与论文中的原始散点图一致，不额外添加统计曲线
N_BINS        = 10          # 分箱数量

# 参数组合
Q_LIST = [0.1, 0.4, 0.7]
REWARD_LIST = [2500, 5000, 10000, 20000]

# ========================= 自动扫描实验 =========================
def discover_experiments():
    exps = []
    for q_dir in os.listdir(DATA_ROOT):
        if not q_dir.startswith('q_'):
            continue
        q_path = os.path.join(DATA_ROOT, q_dir)
        if not os.path.isdir(q_path):
            continue
        try:
            q = float(q_dir.replace('q_', ''))
        except ValueError:
            continue

        for reward_dir in os.listdir(q_path):
            if not reward_dir.startswith('reward_'):
                continue
            reward_path = os.path.join(q_path, reward_dir)
            if not os.path.isdir(reward_path):
                continue
            try:
                reward = int(reward_dir.replace('reward_', ''))
            except ValueError:
                continue

            for exp_dir in os.listdir(reward_path):
                exp_path = os.path.join(reward_path, exp_dir)
                if not os.path.isdir(exp_path):
                    continue
                expdata_path = os.path.join(exp_path, 'expdata')
                summary_path = os.path.join(expdata_path, 'experiment_summary.json')
                round050_path = os.path.join(expdata_path, 'rounds', 'round_050.json')
                if os.path.exists(summary_path) and os.path.exists(round050_path):
                    exps.append((q, reward, expdata_path))
    return exps

# ========================= 加载数据 =========================
print("Loading data...")
all_records = []
experiments = discover_experiments()
print(f"Found {len(experiments)} experiments.")

for q, reward, expdata_path in experiments:
    summary_path = os.path.join(expdata_path, 'experiment_summary.json')
    round050_path = os.path.join(expdata_path, 'rounds', 'round_050.json')

    with open(summary_path, encoding='utf-8') as f:
        summary = json.load(f)
    with open(round050_path, encoding='utf-8') as f:
        round_50 = json.load(f)

    ability_dict = {}
    invest_dict = {}
    for agent in summary.get("agent_final_status", []):
        aid = agent["agent_id"]
        ability_dict[aid] = agent.get("intrinsic_ability", 0)
        invest_dict[aid] = agent.get("total_investment", 0)

    rank_dict = {}
    for agent in round_50.get("agents_data", []):
        aid = agent["agent_id"]
        rank_dict[aid] = agent.get("rank", 200)

    N = len(ability_dict)
    K = int(round(q * N))
    if K < 1:
        K = 1

    for aid in ability_dict.keys():
        if aid in rank_dict:
            rank = rank_dict[aid]
            total_invest = invest_dict[aid]
            final_wealth = 5000 - total_invest
            if rank <= K:
                final_wealth += reward
            all_records.append({
                'ability': ability_dict[aid],
                'rank': rank,
                'total_investment': total_invest,
                'final_wealth': final_wealth,
                'q': q,
                'reward': reward
            })

df = pd.DataFrame(all_records)
print(f"Total records: {len(df)}")
assert not df.empty and np.isfinite(df[['ability', 'rank', 'total_investment', 'final_wealth']]).all().all()
df.to_csv(os.path.join(OUTPUT_DIR, 'ability_plot_data.csv'), index=False)

# ========================= 趋势线绘制函数 =========================
def add_trend(ax, x, y, n_bins=N_BINS):
    """
    在 ax 上绘制分箱中位数趋势线 + 25%/75% 分位数阴影带。
    数据量太少的 bin 自动跳过。
    """
    # 去除 NaN
    mask = ~(np.isnan(x) | np.isnan(y))
    x, y = np.asarray(x)[mask], np.asarray(y)[mask]
    if len(x) < 5:
        return

    # 等宽分箱
    bins = np.linspace(x.min(), x.max(), n_bins + 1)
    bin_centers = (bins[:-1] + bins[1:]) / 2
    medians, q25, q75 = [], [], []

    for i in range(n_bins):
        lo, hi = bins[i], bins[i+1]
        if i == n_bins - 1:
            sel = (x >= lo) & (x <= hi)
        else:
            sel = (x >= lo) & (x < hi)
        if sel.sum() < 3:
            medians.append(np.nan)
            q25.append(np.nan)
            q75.append(np.nan)
        else:
            medians.append(np.median(y[sel]))
            q25.append(np.percentile(y[sel], 25))
            q75.append(np.percentile(y[sel], 75))

    medians = np.array(medians)
    q25 = np.array(q25)
    q75 = np.array(q75)

    # 阴影带
    ax.fill_between(bin_centers, q25, q75,
                    color=COLOR_BAND, alpha=0.45, linewidth=0, zorder=1)
    # 中位数线
    ax.plot(bin_centers, medians,
            color=COLOR_TREND, linewidth=2, zorder=2)

# ========================= 绘图函数 =========================
def plot_three_rows(filter_col, filter_vals, facet_col, facet_vals, out_name):
    df_filtered = df[df[filter_col].isin(filter_vals)]
    if df_filtered.empty:
        print(f"No data for filter {filter_col}={filter_vals}")
        return

    n_cols = len(facet_vals)
    n_rows = 3

    fig, axes = plt.subplots(
        n_rows, n_cols,
        figsize=(10.8, 8.8),
        sharex=True,
        squeeze=False,
    )
    if n_cols == 1:
        axes = axes.reshape(n_rows, 1)

    rows = [
        {'y_col': 'rank',             'ylabel': 'Final rank',       'invert': False, 'baseline': None},
        {'y_col': 'total_investment', 'ylabel': 'Total investment', 'invert': False, 'baseline': None},
        {'y_col': 'final_wealth',     'ylabel': 'Final wealth',     'invert': False, 'baseline': 5000},
    ]

    for row_idx, row in enumerate(rows):
        y_col = row['y_col']
        ylabel = row['ylabel']

        for col_idx, val in enumerate(facet_vals):
            sub = df_filtered[df_filtered[facet_col] == val]
            if sub.empty:
                continue

            ax = axes[row_idx, col_idx]

            # 散点
            ax.scatter(
                sub['ability'], sub[y_col],
                s=POINT_SIZE, alpha=POINT_ALPHA,
                color=COLOR_POINT, edgecolors='white', linewidths=0.3,
                zorder=3, rasterized=True,
            )

            # 趋势线 + 分位带
            if SHOW_TREND:
                add_trend(ax, sub['ability'].values, sub[y_col].values)

            # 基准线（仅财富图）
            if row['baseline'] is not None:
                ax.axhline(y=row['baseline'], color='#8B9298',
                           linestyle=(0, (3, 3)), linewidth=0.8, alpha=0.8, zorder=1)

            if row['invert']:
                ax.invert_yaxis()

            # 标题仅第一行
            if row_idx == 0:
                label = f'q = {val}' if facet_col == 'q' else f'R = {val:,}'
                ax.set_title(label, fontweight='medium', pad=12)

            # 横轴刻度仅最下行，纵轴标题统一放在画布左侧。
            ax.set_xticks([-2, 0, 2])
            ax.yaxis.set_major_locator(MaxNLocator(nbins=3, integer=True))
            if y_col == 'rank':
                ax.set_ylim(0, 205)
                ax.set_yticks([0, 100, 200])
            else:
                ax.yaxis.set_major_formatter(FuncFormatter(
                    lambda v, pos: f'{v/1000:g}k' if abs(v) >= 1000 else f'{v:g}'))
            ax.margins(x=0.05, y=0.09)

            # 样式
            ax.set_axisbelow(True)
            ax.grid(axis='y', color='#E4E7E9', linewidth=0.55)
            ax.spines['top'].set_visible(False)
            ax.spines['right'].set_visible(False)
            for side in ('left', 'bottom'):
                ax.spines[side].set_linewidth(0.65)
                ax.spines[side].set_color('#7A8188')
            ax.tick_params(direction='out', colors=COLOR_TICK, pad=5,
                           labelbottom=(row_idx == n_rows - 1))

    # 两张图相同的绘图区边界，保留各参数条件原有的纵轴范围。
    fig.subplots_adjust(left=0.12, right=0.985, top=0.865, bottom=0.095,
                        wspace=0.32, hspace=0.22)
    for row_idx, row in enumerate(rows):
        pos = axes[row_idx, 0].get_position()
        fig.text(0.026, (pos.y0 + pos.y1) / 2, row['ylabel'],
                 fontsize=16, rotation=90, ha='center', va='center')
    fixed = f'q = {filter_vals[0]}' if filter_col == 'q' else f'R = {filter_vals[0]:,}'
    fig.suptitle(f'Intrinsic ability and individual outcomes ({fixed})',
                 x=0.55, y=0.985, fontsize=19, weight='bold')
    fig.text(0.019, 0.985, 'a' if filter_col == 'q' else 'b',
             fontsize=23, weight='bold', ha='left', va='top')
    fig.supxlabel('Intrinsic ability', x=0.55, y=0.018, fontsize=17)
    fig.text(0.55, 0.925, 'Each point represents one agent',
             fontsize=13, color='#454B51', ha='center')

    # 保存
    out_pdf = os.path.join(OUTPUT_DIR, out_name + '.pdf')
    out_png = os.path.join(OUTPUT_DIR, out_name + '.png')
    fig.savefig(out_pdf, dpi=300)
    fig.savefig(out_png, dpi=300)
    plt.close()
    print(f"Saved: {out_pdf}")
    print(f"Saved: {out_png}")

# ========================= 生成图1：固定 reward=20000，分面 q =========================
plot_three_rows(
    filter_col='reward',
    filter_vals=[20000],
    facet_col='q',
    facet_vals=[0.1, 0.4, 0.7],
    out_name='three_rows_fixedR20000_facetQ'
)

# ========================= 生成图2：固定 q=0.4，分面 reward =========================
plot_three_rows(
    filter_col='q',
    filter_vals=[0.4],
    facet_col='reward',
    facet_vals=[2500, 5000, 10000, 20000],
    out_name='three_rows_fixedQ0.4_facetR'
)

from pypdf import PdfReader, PdfWriter, Transformation
from PIL import Image
names = ['three_rows_fixedQ0.4_facetR', 'three_rows_fixedR20000_facetQ']
pages = [PdfReader(os.path.join(OUTPUT_DIR, n + '.pdf')).pages[0] for n in names]
w, h = float(pages[0].mediabox.width), float(pages[0].mediabox.height)
assert all(float(p.mediabox.width) == w and float(p.mediabox.height) == h for p in pages)
writer = PdfWriter()
page = writer.add_blank_page(width=2*w, height=h)
for i, source in enumerate(pages):
    page.merge_transformed_page(source, Transformation().translate(tx=i*w, ty=0))
writer.write(os.path.join(OUTPUT_DIR, 'ability_outcomes_side_by_side.pdf'))
images = [Image.open(os.path.join(OUTPUT_DIR, n + '.png')) for n in names]
assert images[0].size == images[1].size
width, height = images[0].size
combined = Image.new('RGB', (2*width, height), 'white')
for i, image in enumerate(images):
    combined.paste(image, (i*width, 0))
    image.close()
combined.save(os.path.join(OUTPUT_DIR, 'ability_outcomes_side_by_side.png'))

print("All done!")
