"""Redesign collective-outcome figures from the audited 16 configurations."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
from matplotlib import cm
from matplotlib.ticker import MaxNLocator

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'output/pdf/collective_outcomes_v2';OUT.mkdir(parents=True,exist_ok=True)
d=pd.read_csv(ROOT/'output/mechanism_design_guide/mechanism_design_evidence.csv')
grid=pd.read_csv(ROOT/'output/std1_absolute_qd/metrics_std1.csv')
fixed=pd.read_csv(ROOT/'output/fixed_P250000_complete/all_current_metrics.csv')
assert len(d)==16 and not d.duplicated(['q','R']).any()
for _,r in d.iterrows():
    ref=(grid if ((grid.q==r.q)&(grid.R==r.R)).any() else fixed)
    row=ref[(ref.q==r.q)&(ref.R==r.R)].iloc[0]
    for k in ['Q_LLM','D_LLM','I_LLM','Q_Base','D_Base']:
        assert np.isclose(r[k],row[k],rtol=1e-10,atol=1e-10),(r.q,r.R,k)
    assert np.isclose(r.P,round(200*r.q)*r.R)
assert np.allclose(d.DeltaQ,d.Q_LLM-d.Q_Base)
assert np.allclose(d.DeltaD,d.D_LLM-d.D_Base)
plt.rcParams.update({'font.family':'Arial','font.size':7,'axes.titlesize':8,'axes.labelsize':7,
 'xtick.labelsize':6.5,'ytick.labelsize':6.5,'pdf.fonttype':42,'svg.fonttype':'none',
 'text.color':'#26384B','axes.labelcolor':'#26384B','xtick.color':'#425466','ytick.color':'#425466',
 'axes.spines.top':False,'axes.spines.right':False})
def save(fig,name):
    for ext in ['pdf','png','svg']:
        fig.savefig(OUT/(name+'.'+ext),dpi=320,bbox_inches='tight',pad_inches=.035)
    plt.close(fig)

fig=plt.figure(figsize=(6.85,2.85))
for n,(key,title,cmap,zlim) in enumerate([
 ('Q_LLM','(a) Selection quality, $Q$','viridis',(.85,1.01)),
 ('D_LLM','(b) Resource dissipation, $D$','YlOrRd',(0,7.5))]):
    ax=fig.add_subplot(1,2,n+1,projection='3d')
    x=np.log2(grid.R.to_numpy()); y=grid.q.to_numpy();z=grid[key].to_numpy()
    ax.plot_trisurf(x,y,z,cmap=cmap,vmin=zlim[0],vmax=zlim[1],alpha=.62,
       linewidth=.35,edgecolor='#84909C',antialiased=True)
    ax.scatter(x,y,z,s=12,c='#203C59',edgecolors='white',linewidths=.35,depthshade=False,zorder=5)
    ax.scatter(np.log2(fixed.R),fixed.q,fixed[key],s=24,marker='D',c='#C87543',
       edgecolors='white',linewidths=.45,depthshade=False,zorder=6)
    ax.set_xticks(np.log2([2500,5000,10000,20000]),['2.5k','5k','10k','20k'])
    ax.set_yticks([.1,.4,.7]);ax.set_zlim(*zlim)
    ax.zaxis.set_major_locator(MaxNLocator(4))
    ax.set_xlabel('Reward, $R$',labelpad=-1)
    ax.set_ylabel('Coverage, $q$',labelpad=-1)
    ax.set_zlabel('')
    ax.tick_params(axis='both',pad=-1,length=2,labelsize=6)
    ax.view_init(elev=24,azim=-56);ax.set_box_aspect((1.2,.95,.78))
    ax.set_title(title,pad=1,loc='center')
    for axis in [ax.xaxis,ax.yaxis,ax.zaxis]:
        axis.pane.fill=False
        axis._axinfo['grid'].update(color=(.75,.79,.83,.3),linewidth=.45)
handles=[plt.Line2D([],[],marker='o',lw=0,color='#203C59',markersize=3,label='12 reward-grid configurations'),
         plt.Line2D([],[],marker='D',lw=0,color='#C87543',markersize=3.5,label='4 additional configurations')]
fig.legend(handles=handles,loc='lower center',ncol=2,frameon=False,fontsize=6.7,bbox_to_anchor=(.5,-.015))
fig.subplots_adjust(left=0,right=.98,top=.91,bottom=.12,wspace=.04)
save(fig,'collective_qd_landscape')

fig,ax=plt.subplots(figsize=(6.85,2.65))
xlim=(-1.96,.51);ylim=(-.065,.202)
ax.set(xlim=xlim,ylim=ylim)
ax.fill_between([xlim[0],0],0,ylim[1],color='#E7F1ED',alpha=.65,zorder=0)
ax.fill_between([0,xlim[1]],ylim[0],0,color='#F5E8E5',alpha=.65,zorder=0)
norm=Normalize(.06,.7)
size=lambda p: 16+100*np.sqrt(np.asarray(p)/2800000)
sc=ax.scatter(d.DeltaD,d.DeltaQ,s=size(d.P),c=d.q,cmap='viridis',norm=norm,
    edgecolors='#26384B',linewidths=.45,alpha=.90,zorder=3)
ax.axhline(0,color='#6E7C8A',lw=.7,ls=(0,(3,2)))
ax.axvline(0,color='#6E7C8A',lw=.7,ls=(0,(3,2)))
ax.set_xticks([-1.5,-1,-.5,0,.5]);ax.set_yticks([-.05,0,.05,.1,.15,.2])
ax.set_xlabel('$\Delta D = D_{LLM}-D_{Bayesian}$',labelpad=3)
ax.set_ylabel('$\Delta Q = Q_{LLM}-Q_{Bayesian}$',labelpad=3)
ax.tick_params(length=2,width=.5,pad=2);ax.grid(color='#D9DFE5',lw=.4,alpha=.55)
ax.set_axisbelow(True)
for s in ['left','bottom']:ax.spines[s].set_color('#9AA6B1');ax.spines[s].set_linewidth(.6)
ax.text(.02,.98,'Higher $Q$, lower $D$',transform=ax.transAxes,ha='left',va='top',fontsize=6.5,color='#386653')
ax.text(.98,.98,'Higher $Q$, higher $D$',transform=ax.transAxes,ha='right',va='top',fontsize=6.5,color='#7C6948')
ax.text(.02,.02,'Lower $Q$, lower $D$',transform=ax.transAxes,ha='left',va='bottom',fontsize=6.5,color='#66778B')
ax.text(.98,.02,'Lower $Q$, higher $D$',transform=ax.transAxes,ha='right',va='bottom',fontsize=6.5,color='#934E45')
for q,R,text,offset in [(.5,2500,'$q=.5, R=2.5k$',(-43,10)),(.4,20000,'$q=.4, R=20k$',(-58,6))]:
    r=d[(d.q==q)&(d.R==R)].iloc[0]
    ax.annotate(text,(r.DeltaD,r.DeltaQ),xytext=offset,textcoords='offset points',fontsize=6,
      arrowprops=dict(arrowstyle='-',color='#738091',lw=.5),bbox=dict(fc='white',ec='none',alpha=.8,pad=.7))
cax=fig.add_axes([.645,.26,.012,.65]);cb=fig.colorbar(sc,cax=cax,ticks=[.1,.4,.7]);cb.ax.tick_params(labelsize=6,length=2,pad=2)
cb.set_label('Winner proportion, $q$',fontsize=6.5,labelpad=3);cb.outline.set_linewidth(.4)
handles=[ax.scatter([],[],s=size(p),fc='#D3DCE4',ec='#637487',lw=.45,label=lab) for p,lab in [(50000,'50k'),(250000,'250k'),(1000000,'1m'),(2800000,'2.8m')]]
fig.legend(handles=handles,title='Prize budget, $P$',loc='lower center',bbox_to_anchor=(.36,-.015),
 ncol=4,frameon=False,fontsize=6,title_fontsize=6.5,columnspacing=.8,handletextpad=.35)
fig.subplots_adjust(left=.085,right=.62,bottom=.28,top=.92)
detail=fig.add_axes([.795,.30,.19,.55])
eq=d[abs(d.DeltaQ)<1e-9].sort_values(['q','R']).reset_index(drop=True)
detail.axvline(0,color='#8794A2',lw=.6,ls='--')
detail.scatter(eq.DeltaD,range(len(eq)),s=size(eq.P),c=eq.q,cmap='viridis',norm=norm,
 edgecolors='#26384B',linewidths=.45,zorder=3)
detail.set_yticks(range(len(eq)),[f'{r.q:g}, {r.R/1000:g}k' for _,r in eq.iterrows()],fontsize=6)
detail.set_ylim(len(eq)-.5,-.5);detail.set_xlim(-.54,.15);detail.set_xticks([-.5,-.25,0])
detail.set_title('Equal-selection cases\n$\\Delta Q=0$',fontsize=7,pad=5)
detail.set_xlabel('$\\Delta D$',fontsize=7,labelpad=2)
detail.tick_params(length=2,width=.5,pad=2,labelsize=6)
detail.spines[['left','top','right']].set_visible(False)
detail.spines['bottom'].set_color('#9AA6B1')
detail.text(-.02,-.28,'Rows: $q$, $R$',transform=detail.transAxes,fontsize=6,ha='left')
save(fig,'collective_delta_quadrants')

d.to_csv(OUT/'all16_plot_data.csv',index=False)
fixed.to_csv(OUT/'four_additional_configurations.csv',index=False)
tol=1e-9
counts={'higherQ_lowerD':int(((d.DeltaQ>tol)&(d.DeltaD<-tol)).sum()),
 'higherQ_higherD':int(((d.DeltaQ>tol)&(d.DeltaD>tol)).sum()),
 'lowerQ_higherD':int(((d.DeltaQ<-tol)&(d.DeltaD>tol)).sum()),
 'lowerQ_lowerD':int(((d.DeltaQ<-tol)&(d.DeltaD<-tol)).sum()),
 'equalQ_lowerD':int(((abs(d.DeltaQ)<=tol)&(d.DeltaD<-tol)).sum()),
 'equalQ_higherD':int(((abs(d.DeltaQ)<=tol)&(d.DeltaD>tol)).sum())}
(OUT/'verification.json').write_text(json.dumps(counts,indent=2))
print(counts)
print(d[['q','R','P','Q_LLM','D_LLM','DeltaQ','DeltaD']].to_string(index=False))
