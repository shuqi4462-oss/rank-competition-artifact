"""Fresh audit and matched metrics for the full std1 grid plus near-fixed-budget runs."""
from pathlib import Path
import json,re,csv,math
import numpy as np
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'output/global_std1_story'

def scalar(text,key):
    return float(re.search(r'^\s*'+key+r':\s*([-+0-9.eE]+)\s*$',text,re.M).group(1))

def load(path,q,R,baseline=False):
    summary=json.loads(path.read_text(encoding='utf-8'))
    aa=sorted(summary['agent_final_status'],key=lambda a:a['agent_id'])
    ids=[a['agent_id'] for a in aa]; assert ids==list(range(1,201))
    c=np.array([a['intrinsic_ability'] for a in aa]); inv=np.zeros(200); score=np.zeros(200)
    fs=sorted((path.parent/'rounds').glob('round_*.json')); assert len(fs)==50
    formula_error=0; allocation_error=0
    if baseline:
        rng=np.random.default_rng(0); true=np.clip(rng.normal(.5,1,200),-100,100)
        assert np.allclose(c,true,rtol=0,atol=1e-12)
        rng.normal(.5,.25,200); rng.normal(35,20,200); rng.normal(0,.35,200)
    for t,p in enumerate(fs,1):
        r=json.loads(p.read_text(encoding='utf-8')); assert r['round']==t
        a=sorted(r['agents_data'],key=lambda a:a['agent_id']); assert [a['agent_id'] for a in a]==ids
        x=np.array([a['input'] for a in a],float); observed=np.array([a['score'] for a in a],float)
        assert np.isfinite(x).all() and np.all((0<=x)&(x<=100))
        inv+=x; score+=observed
        logits=c*x/20; w=np.exp(logits-logits.max()); alloc=20000*w/w.sum()
        if baseline: noise=rng.normal(0,5,200)
        else:
            details=[a['calculation_details'] for a in a]
            assert all('cost' not in d and 'ability_investment_logit' in d for d in details)
            noise=np.array([d['luck_factor'] for d in details])
            allocation_error=max(allocation_error,float(np.abs(alloc-[d['resource_allocation'] for d in details]).max()))
        predicted=np.maximum(0,alloc+noise)
        formula_error=max(formula_error,float(np.abs(predicted-observed).max()))
    assert formula_error<(.005001 if baseline else .050001)
    if not baseline: assert allocation_error<.000001
    rank=np.array([a['rank'] for a in a]); avg=np.array([a['avg_score'] for a in a]); assert sorted(rank)==list(range(1,201))
    K=int(round(q*200)); P=K*R
    high=set(np.argsort(-c,kind='stable')[:K]); selected=set(np.where(rank<=K)[0]); rebuilt=set(np.argsort(-score,kind='stable')[:K])
    hits=len(high&selected); recall=hits/K; hits_rebuilt=len(high&rebuilt)
    return dict(Q=(recall-q)/(1-q),D=float(inv.sum()/P),I=float(inv.sum()),C=float(inv.sum()/1000000),
        Recall=recall,hits=hits,Q_rebuilt=(hits_rebuilt/K-q)/(1-q),changed_winners=len(selected^rebuilt)//2,
        I_summary=sum(a['total_investment'] for a in aa),
        max_agent_investment_error=float(np.abs(inv-[a['total_investment'] for a in aa]).max()),
        max_mean_score_error=float(np.abs(avg-score/50).max()),summary_rounds=summary['total_rounds'],
        formula_max_error=formula_error,allocation_max_error=allocation_error,source=str(path.resolve())),c

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    rows=[]
    for folder,kind in [('std1','grid'),('P250000','near_fixed_budget')]:
        for p in sorted((ROOT/'data/reward_experiment/llm_reward'/folder).rglob('experiment_summary.json')):
            s=json.loads(p.read_text(encoding='utf-8'))
            if not s.get('agent_final_status'): continue
            config=next(parent/'runtime_config.yaml' for parent in p.parents if (parent/'runtime_config.yaml').exists()).read_text(encoding='utf-8')
            q=scalar(config,'top_percentage'); R=scalar(config,'final_reward'); assert scalar(config,'ability_std')==1
            llm,c=load(p,q,R)
            primary=ROOT/f'data/reward_experiment/baseline_reward/std1/q_{q}/reward_{int(R)}/seed_0/experiment_summary.json'
            cached=ROOT/f'output/social_dissipation/baseline/current_code/q_{q}/seed_0/experiment_summary.json'
            basepath=primary if primary.exists() else cached; assert basepath.exists()
            base,bc=load(basepath,q,R,True); assert np.allclose(c,bc,rtol=0,atol=1e-12)
            row=dict(kind=kind,q=q,R=R,K=int(round(q*200)),P=int(round(q*200))*R,
                DeltaQ=llm['Q']-base['Q'],DeltaD=llm['D']-base['D'],DeltaC=llm['C']-base['C'],
                relative_investment_pct=100*(llm['I']/base['I']-1))
            for suffix,obj in [('LLM',llm),('Base',base)]: row.update({f'{k}_{suffix}':v for k,v in obj.items()})
            rows.append(row)
    assert len(rows)==16
    with (OUT/'metrics_all_std1.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(sorted(rows,key=lambda r:(r['R'],r['q'])))
    print('Fresh audit: 16 LLM configurations; 160000 records; matched baselines verified.')
    for r in rows:
        if r['max_mean_score_error_LLM']>1e-8 or r['max_agent_investment_error_LLM']>1e-8:
            print('Ledger note',r['q'],r['R'],'avg_error',r['max_mean_score_error_LLM'],'investment_error',r['max_agent_investment_error_LLM'],
                  'Q_reported',r['Q_LLM'],'Q_rebuilt',r['Q_rebuilt_LLM'],'winner_changes',r['changed_winners_LLM'])

if __name__=='__main__': main()
