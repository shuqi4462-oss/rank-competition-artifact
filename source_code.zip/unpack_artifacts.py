"""Expand bundled, sanitized review data. No network or API access."""
from pathlib import Path
import gzip
import shutil
import zipfile

ROOT = Path(__file__).resolve().parent

def main():
    for archive in sorted((ROOT/'artifacts/runs').glob('*.zip')):
        with zipfile.ZipFile(archive) as z:
            for member in z.infolist():
                target=(ROOT/member.filename).resolve()
                if ROOT not in target.parents:
                    raise ValueError('Archive member outside artifact directory')
                target.parent.mkdir(parents=True, exist_ok=True)
                with z.open(member) as src, target.open('wb') as dst:
                    shutil.copyfileobj(src,dst)
    for archive in (ROOT/'artifacts/tables').rglob('*.gz'):
        target=ROOT/archive.relative_to(ROOT/'artifacts/tables').with_suffix('')
        target.parent.mkdir(parents=True,exist_ok=True)
        with gzip.open(archive,'rb') as src, target.open('wb') as dst:
            shutil.copyfileobj(src,dst)
    print('Expanded 32 sanitized runs and compressed analysis tables.')

if __name__=='__main__':main()
