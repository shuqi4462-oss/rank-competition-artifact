"""Meaningful offline checks of scoring, archived outcomes and file integrity."""
from pathlib import Path
import hashlib,json,sys
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'involution'))
from src.utils.boltzmann import calculate_score_arrays
from prepare_global_std1 import load

def main():
    scores,*_=calculate_score_arrays([20,20],[-1,1],noise_std=0)
    assert scores[1]>scores[0]
    assert np.isclose(scores.sum(),20000)
    data=pd.read_csv(ROOT/'output/global_std1_story/metrics_all_std1.csv')
    inventory=json.loads((ROOT/'artifacts/run_inventory.json').read_text())
    assert len(inventory)==32
    for item in inventory:
        row=data[np.isclose(data.q,float(item['q'])) & np.isclose(data.R,float(item['R']))].iloc[0]
        pop=item['population']
        actual,_=load(ROOT/item['summary'],float(item['q']),float(item['R']),baseline=pop=='Base')
        for metric in ['I','Q','D']:
            assert np.isclose(actual[metric],row[metric+'_'+pop],rtol=1e-10,atol=1e-8),(item,metric)
    print('PASS: score direction and scoring-pool conservation; 32 full runs independently verified against reported I, Q, D.')

if __name__=='__main__':main()
