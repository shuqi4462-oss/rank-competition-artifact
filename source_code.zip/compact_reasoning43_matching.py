"""Compact Figure 7, using unchanged matched-analysis summaries."""
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent
DATA=ROOT/'output/reasoning43_reanalysis_20261022'
OUT=ROOT/'output/pdf/figure7_compact'
OUT.mkdir(parents=True,exist_ok=True)
C=['D1a','D1b','D1c','D2a','D2b','D2c','D2d','D3b']
N=['Reward-cost comparison','Qualification trade-off','Capital retention','Secure lead',
   'Qualification at risk','Catch-up attainable*','Catch-up unlikely','Weak investment returns']
plt.rcParams.update({'font.family':'Arial','font.size':7,'pdf.fonttype':42,'svg.fonttype':'none',
 'text.color':'#26384B','axes.labelcolor':'#26384B','xtick.color':'#425466','ytick.color':'#425466',
 'axes.spines.top':False,'axes.spines.right':False,'axes.spines.left':False})
m=pd.read_csv(DATA/'matched_label_contrasts.csv')
fig,axs=plt.subplots(1,2,figsize=(6.85,1.95),sharey=True)
for ax,kind,title,limits,ticks in zip(axs,['rank','ability'],
 ['(a) Rank contrast | similar ability','(b) Ability contrast | similar rank'],
 [(-25,25),(-8,11)],[[-20,-10,0,10,20],[-5,0,5,10]]):
    mm=m[m.setting.eq(kind+'_primary')].set_index('code').loc[C]
    per=pd.read_csv(DATA/(kind+'_primary_condition_effects.csv'))
    for i,c in enumerate(C):
        ax.scatter(per[c],np.full(len(per),i),s=11,color='#8296AB',alpha=.48,edgecolors='none',zorder=2)
    ax.scatter(mm.delta_pp,np.arange(len(C)),s=31,color='#173F70',edgecolors='white',linewidths=.45,zorder=4)
    ax.axvline(0,color='#8B99A8',lw=.65,ls=(0,(3,2)),zorder=1)
    ax.set_xlim(*limits);ax.set_xticks(ticks)
    ax.set_ylim(7.5,-.5)
    ax.set_title(title,loc='left',fontsize=7.7,pad=8)
    ax.set_yticks(range(8),N,fontsize=7)
    ax.tick_params(axis='y',length=0,pad=4)
    ax.tick_params(axis='x',length=2,width=.5,labelsize=6.7,pad=2)
    ax.grid(axis='x',color='#E9EDF2',lw=.5);ax.set_axisbelow(True)
    ax.spines['bottom'].set_color('#A5AFBA');ax.spines['bottom'].set_linewidth(.5)
    for i,v in enumerate(mm.delta_pp):
        ax.text(1.025,i,f'{v:+.2f}',transform=ax.get_yaxis_transform(),ha='left',va='center',
                fontsize=7.1,color='#173F70',fontweight='bold',clip_on=False)
    ax.text(1.025,1.045,'Mean',transform=ax.transAxes,ha='left',va='bottom',fontsize=6.5,color='#425466')
axs[1].tick_params(axis='y',left=False,labelleft=False)
fig.subplots_adjust(left=.235,right=.935,bottom=.20,top=.84,wspace=.32)
fig.text(.58,.015,'Judgment difference (percentage points)',ha='center',va='bottom',fontsize=7)
for ext in ['pdf','png','svg']:
    fig.savefig(OUT/('reasoning43_matching_compact.'+ext),dpi=320,bbox_inches='tight',pad_inches=.025)
print(OUT)
