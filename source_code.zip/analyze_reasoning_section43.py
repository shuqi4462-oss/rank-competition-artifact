"""Descriptive reanalysis of main std1 runs; raw data and codes stay unchanged.

No p-values or agent-round confidence intervals: one simulation per condition.
Greedy disjoint matches are exact on experiment and decision round.
"""
from pathlib import Path
import json, hashlib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'output/reasoning43_reanalysis_20261022'
OUT.mkdir(parents=True,exist_ok=True)
FIG=OUT/'figures';FIG.mkdir(exist_ok=True)
KEY=['experiment','agent_id','round']
STRATEGIES=['aggressive','moderate','conservative']
SELECT=['D1a','D1b','D1c','D2a','D2b','D2c','D2d','D3b']
NAMES={'D1a':'Reward-cost comparison','D1b':'Qualification trade-off','D1c':'Capital retention',
 'D2a':'Secure lead','D2b':'Qualification at risk','D2c':'Catch-up attainable*',
 'D2d':'Catch-up unlikely','D3b':'Weak investment returns'}
COLORS=['#B66B58','#8A9254','#365D8D']
plt.rcParams.update({'font.family':'Arial','font.size':10,'axes.spines.top':False,
 'axes.spines.right':False,'svg.fonttype':'none','axes.labelcolor':'#26384B',
 'text.color':'#26384B','xtick.color':'#425466','ytick.color':'#425466'})

def csv(d,name):d.to_csv(OUT/(name+'.csv'),index=False,encoding='utf-8-sig')
def savefig(fig,name):
    fig.savefig(FIG/(name+'.png'),dpi=220,bbox_inches='tight')
    fig.savefig(FIG/(name+'.svg'),bbox_inches='tight');plt.close(fig)

def load():
    d=pd.read_csv(ROOT/'reason_analysis/labeled_v1/reasons_labeled.csv',keep_default_na=False)
    d=d[d.experiment.str.startswith('std1_')].copy()
    assert len(d)==120000 and d.experiment.nunique()==12 and not d.duplicated(KEY).any()
    d=d[d.quality!='Q3'].copy().reset_index(drop=True)
    assert len(d)==119999
    for c in ['agent_id','round','investment','rank_before_decision','intrinsic_ability']:
        d[c]=pd.to_numeric(d[c],errors='coerce')
    d['q']=d.experiment.str.extract(r'q_([0-9.]+)').astype(float)
    d['reward']=d.experiment.str.extract(r'reward_(\d+)').astype(int)
    d['uid']=d.experiment+'|'+d.agent_id.astype(str)
    agents=d[['experiment','uid','intrinsic_ability']].drop_duplicates()
    assert len(agents)==2400
    agents['ability_z']=agents.groupby('experiment').intrinsic_ability.transform(lambda s:(s-s.mean())/s.std(ddof=0))
    agents['ability_pct']=agents.groupby('experiment').intrinsic_ability.rank(method='first',pct=True)
    d=d.merge(agents,on=['experiment','uid','intrinsic_ability'],validate='many_to_one')
    d['ability_group']=np.select([d.ability_pct<=.25,d.ability_pct>.75],['low','high'],default='middle')
    d['inside']=d.rank_before_decision<=200*d.q
    book=pd.read_csv(ROOT/'reason_analysis/labeled_v1/codebook.csv')
    codes=[c for c in book.code if c.startswith('D') and not c.endswith('u')]
    assert len(codes)==25
    for c in codes:
        if c.startswith('D4'):d[c]=((d.D4_primary==c)|(d.D4_secondary==c)).astype(int)
        else:d[c]=d[c[:2]].str.split(';').map(lambda a:int(c in a))
    for dim in ['D1','D2','D3','D4','D5']:d['any_'+dim]=d[[c for c in codes if c.startswith(dim)]].any(axis=1).astype(int)
    z=np.load(ROOT/'pic/pca_global_coordinates.npz')
    m=pd.DataFrame(z['meta'],columns=['q','round','agent_id','cluster_investment','snapshot_rank','reward'])
    for c in m:m[c]=pd.to_numeric(m[c])
    m['strategy']=z['strategies']
    m['experiment']='std1_q_'+m.q.map(lambda x:f'{x:g}')+'_reward_'+m.reward.astype(int).astype(str)
    assert len(m)==12000 and not m.duplicated(KEY).any()
    s=m.merge(d,on=KEY,how='left',validate='one_to_one',indicator=True,suffixes=('_cluster',''))
    missing=s[s['_merge']!='both'][KEY]
    csv(missing,'snapshot_unusable_records')
    s=s[s['_merge']=='both'].copy()
    assert np.allclose(s.investment,s.cluster_investment)
    assert set(s.strategy)==set(STRATEGIES)
    d=d.reset_index(drop=True);d['row_id']=d.index
    return d,s,codes,book

def profiles(d,s,codes):
    dims=[]
    for name,g in [('all_50_rounds',d),('post_feedback',d[d.rank_before_decision.notna()])]:
        for dim in ['D1','D2','D3','D4','D5']:
            by=g.groupby('experiment')['any_'+dim].mean()*100
            dims.append(dict(period=name,dimension=dim,n=len(g),pooled_percent=100*g['any_'+dim].mean(),
                equal_condition_percent=by.mean(),condition_min=by.min(),condition_max=by.max()))
    csv(pd.DataFrame(dims),'dimension_coverage')
    inv=d[codes].agg(['sum','mean']).T.reset_index(names='code').rename(columns={'sum':'n','mean':'pooled_rate'})
    csv(inv,'all_25_inventory')
    stats=[];rows=[]
    for period,g in [('all_snapshots',s),('post_feedback_snapshots',s[s['round']>5])]:
        for strategy,h in g.groupby('strategy'):
            stats.append(dict(period=period,strategy=strategy,n=len(h),mean_investment=h.investment.mean(),
                zero_percent=(h.investment==0).mean()*100,full_percent=(h.investment==100).mean()*100,
                n_conditions=h.experiment.nunique(),n_agents=h.uid.nunique()))
            by=h.groupby('experiment')[codes].mean()*100
            for code in codes:rows.append(dict(period=period,strategy=strategy,code=code,n=len(h),
                pooled_percent=100*h[code].mean(),equal_condition_percent=by[code].mean(),
                condition_min=by[code].min(),condition_max=by[code].max()))
    csv(pd.DataFrame(stats),'strategy_investment_summary')
    p=pd.DataFrame(rows);csv(p,'strategy_label_profiles')
    csv(s.groupby(['experiment','round','strategy'])[codes+['investment']].mean().reset_index(),'strategy_profiles_by_condition_round')
    # Independent numeric action grouping; intentionally distinct from text clusters.
    d['numeric_behavior']=np.select([d.investment==0,d.investment==100],['zero','full'],default='interior')
    csv(d.groupby('numeric_behavior')[codes+['investment']].mean().reset_index(),'numeric_behavior_profiles')
    # Comparison of judgment profiles between text clusters, holding condition+snapshot fixed.
    diffs=[]
    for period,ss in [('all_snapshots',s),('post_feedback_snapshots',s[s['round']>5])]:
        for a,b in [('aggressive','conservative'),('aggressive','moderate'),('moderate','conservative')]:
            means=ss.groupby(['experiment','round','strategy'])[codes].mean()
            aa=means.xs(a,level='strategy');bb=means.xs(b,level='strategy');shared=aa.index.intersection(bb.index)
            delta=(aa.loc[shared]-bb.loc[shared])*100
            by=delta.groupby('experiment').mean()
            for c in codes:diffs.append(dict(period=period,contrast=a+' minus '+b,code=c,n_shared_cells=len(shared),
              n_conditions=len(by),equal_condition_delta_pp=by[c].mean(),conditions_positive=int((by[c]>0).sum()),
              condition_min=by[c].min(),condition_max=by[c].max()))
    csv(pd.DataFrame(diffs),'strategy_matched_condition_round_contrasts')
    return p

def pair_match(v,kind,ability_caliper=.05,rank_gap=20,rank_caliper=10,ability_gap=1,extremes=False):
    pairs=[]
    for (exp,rnd),g in v.groupby(['experiment','round'],sort=True):
        if extremes:g=g[g.ability_group.isin(['high','low'])]
        rank=g.rank_before_decision.to_numpy();ability=g.ability_z.to_numpy();ids=g.row_id.to_numpy()
        dr=np.abs(rank[:,None]-rank);da=np.abs(ability[:,None]-ability)
        valid=np.triu(np.ones(dr.shape,dtype=bool),1)
        if kind=='rank':valid&=(da<=ability_caliper)&(dr>=rank_gap)
        else:
            valid&=(dr<=rank_caliper)&(da>=ability_gap)&(g.inside.to_numpy()[:,None]==g.inside.to_numpy())
            if extremes:valid&=(g.ability_group.to_numpy()[:,None]!=g.ability_group.to_numpy())
        ii,jj=np.where(valid)
        # Primary: closest ability then widest rank gap. Reverse roles for ability comparison.
        order=np.lexsort((-dr[ii,jj],da[ii,jj])) if kind=='rank' else np.lexsort((-da[ii,jj],dr[ii,jj]))
        used=set()
        for k in order:
            i,j=ii[k],jj[k]
            if i in used or j in used:continue
            used.update([i,j])
            if (kind=='rank' and rank[i]>rank[j]) or (kind=='ability' and ability[i]<ability[j]):i,j=j,i
            pairs.append(dict(experiment=exp,round=rnd,a=int(ids[i]),b=int(ids[j]),
               rank_gap=float(abs(rank[i]-rank[j])),ability_gap_sd=float(abs(ability[i]-ability[j]))))
    return pd.DataFrame(pairs,columns=['experiment','round','a','b','rank_gap','ability_gap_sd'])

def summarize_pairs(p,d,codes,setting):
    if len(p)==0:return [],dict(setting=setting,n_pairs=0,n_conditions=0)
    a=d.loc[p.a];b=d.loc[p.b]
    delta=pd.DataFrame((a[codes].to_numpy()-b[codes].to_numpy())*100,columns=codes)
    delta['experiment']=p.experiment.to_numpy()
    by=delta.groupby('experiment')[codes].mean()
    csv(by.reset_index(),setting+'_condition_effects')
    rows=[]
    for c in codes:rows.append(dict(setting=setting,code=c,n_pairs=len(p),n_conditions=len(by),
         delta_pp=by[c].mean(),pooled_delta_pp=delta[c].mean(),conditions_positive=int((by[c]>0).sum()),
         conditions_negative=int((by[c]<0).sum()),condition_min=by[c].min(),condition_max=by[c].max(),
         a_pooled_percent=a[c].mean()*100,b_pooled_percent=b[c].mean()*100))
    info=dict(setting=setting,n_pairs=len(p),n_records=2*len(p),n_agents=d.loc[np.r_[p.a,p.b]].uid.nunique(),
      n_conditions=len(by),n_time_cells=p[['experiment','round']].drop_duplicates().shape[0],
      mean_rank_gap=p.rank_gap.mean(),max_rank_gap=p.rank_gap.max(),
      mean_ability_gap_sd=p.ability_gap_sd.mean(),max_ability_gap_sd=p.ability_gap_sd.max())
    p['a_uid']=a.uid.to_numpy();p['b_uid']=b.uid.to_numpy()
    csv(p,setting+'_pairs')
    return rows,info

def matching(d,codes):
    v=d[d.rank_before_decision.notna()]
    rows=[];support=[];primary={}
    settings=[('rank_primary','rank',dict()),('rank_tight','rank',dict(ability_caliper=.025)),
     ('rank_wide','rank',dict(ability_caliper=.1)),('rank_gap40','rank',dict(rank_gap=40)),
     ('ability_primary','ability',dict()),('ability_rank5','ability',dict(rank_caliper=5)),
     ('ability_rank20','ability',dict(rank_caliper=20)),('ability_gap05','ability',dict(ability_gap=.5)),
     ('ability_extreme_quartiles','ability',dict(extremes=True))]
    for name,kind,kwargs in settings:
        p=pair_match(v,kind,**kwargs);r,info=summarize_pairs(p,d,codes,name)
        rows.extend(r);support.append(info)
        if name.endswith('primary'):primary[kind]=p.copy()
        print(name,info['n_pairs'],flush=True)
    for kind in ['rank','ability']:
        p=pair_match(v[v['round'].isin(range(6,51,5))],kind)
        r,info=summarize_pairs(p,d,codes,kind+'_first_after_feedback');rows.extend(r);support.append(info)
    csv(pd.DataFrame(rows),'matched_label_contrasts');csv(pd.DataFrame(support),'matching_support')
    # Transparent cases for subsequent human review. No synthetic quotations.
    examples=[]
    for kind,p in primary.items():
        p=p.sort_values(['ability_gap_sd','rank_gap'],ascending=[True,False]) if kind=='rank' else p.sort_values(['rank_gap','ability_gap_sd'],ascending=[True,False])
        for exp,g in p.groupby('experiment'):
            chosen=0
            for row in g.itertuples():
                aa=d.loc[row.a];bb=d.loc[row.b]
                if not any(aa[c]!=bb[c] for c in SELECT):continue
                rec=dict(comparison=kind,experiment=exp,round=row.round)
                for side,h in [('a',aa),('b',bb)]:
                    for col in ['agent_id','intrinsic_ability','rank_before_decision','investment','reason','evidence','review_reason']:
                        rec[side+'_'+col]=h[col]
                    rec[side+'_labels']=';'.join(c for c in codes if h[c])
                examples.append(rec);chosen+=1
                if chosen==2:break
    csv(pd.DataFrame(examples),'matched_reason_examples_for_review')
    return pd.DataFrame(rows),pd.DataFrame(support)

def residualize(a,groups):
    x=np.asarray(a,dtype=float).copy()
    for _ in range(100):
        old=x.copy()
        for group in groups:
            idx,n=np.unique(group,return_inverse=True)[1],len(np.unique(group))
            counts=np.bincount(idx,minlength=n)
            sums=np.zeros((n,x.shape[1]));np.add.at(sums,idx,x)
            x-=sums[idx]/counts[idx,None]
        if np.max(np.abs(x-old))<1e-9:break
    return x

def models(d,codes):
    v=d[d.rank_before_decision.notna()].copy()
    v['rank20']=(200-v.rank_before_decision)/20
    mat=v[['rank20','ability_z']+codes].to_numpy(float)
    cell=v.experiment+'|'+v['round'].astype(str)
    r=residualize(mat,[cell]);x=r[:,:2];y=r[:,2:]
    fit=x@np.linalg.lstsq(x,y,rcond=None)[0]
    fit_rank=x[:,:1]@np.linalg.lstsq(x[:,:1],y,rcond=None)[0]
    fit_ability=x[:,1:2]@np.linalg.lstsq(x[:,1:2],y,rcond=None)[0]
    sst=(y*y).sum(axis=0);sse=((y-fit)**2).sum(axis=0)
    beta=np.linalg.lstsq(x,y,rcond=None)[0]
    rows=[]
    for j,c in enumerate(codes):rows.append(dict(code=c,rank_pp_per20=beta[0,j]*100,ability_pp_per_sd=beta[1,j]*100,
      rank_added_r2=(((y-fit_ability)**2).sum(axis=0)[j]-sse[j])/sst[j] if sst[j]>0 else np.nan,
      ability_added_r2=(((y-fit_rank)**2).sum(axis=0)[j]-sse[j])/sst[j] if sst[j]>0 else np.nan))
    csv(pd.DataFrame(rows),'joint_rank_ability_descriptive_models')
    rr=residualize(v[['rank20']+codes].to_numpy(float),[v.uid,cell])
    b=np.linalg.lstsq(rr[:,:1],rr[:,1:],rcond=None)[0][0]*100
    csv(pd.DataFrame({'code':codes,'pp_per20_better_rank':b}),'within_agent_rank_associations_std1')
    # Feedback comparisons pair the same agent at update round k and k+1.
    prev=d[d['round'].isin(range(10,46,5))].copy()
    prev['next_round']=prev['round']+1
    events=prev.merge(d,left_on=['experiment','agent_id','next_round'],right_on=KEY,suffixes=('_before','_after'),validate='one_to_one')
    events['rank_improvement']=events.rank_before_decision_before-events.rank_before_decision_after
    events['feedback_group']=np.select([events.rank_improvement>=10,events.rank_improvement<=-10],['improved_10plus','worsened_10plus'],default='change_under10')
    events['crossing']=np.select([~events.inside_before&events.inside_after,events.inside_before&~events.inside_after],['entered','left'],default='none')
    out=[]
    for col in ['feedback_group','crossing']:
        for group,g in events.groupby(col):
            for c in SELECT:
                out.append(dict(grouping=col,group=group,code=c,n_events=len(g),before_percent=g[c+'_before'].mean()*100,
                    after_percent=g[c+'_after'].mean()*100))
    csv(pd.DataFrame(out),'feedback_before_after_std1')
    return pd.DataFrame(rows),pd.DataFrame({'code':codes,'pp_per20_better_rank':b})

def figures(p,m,support):
    pp=p[p.period=='post_feedback_snapshots'].pivot(index='code',columns='strategy',values='equal_condition_percent').loc[SELECT,STRATEGIES]
    fig,ax=plt.subplots(figsize=(6.8,4.9));im=ax.imshow(pp,vmin=0,vmax=100,cmap='YlGnBu',aspect='auto')
    ax.set(xticks=range(3),xticklabels=[s.capitalize() for s in STRATEGIES],yticks=range(8),yticklabels=[NAMES[c] for c in SELECT])
    ax.xaxis.tick_top();ax.tick_params(length=0)
    for i in range(8):
        for j in range(3):ax.text(j,i,f'{pp.iloc[i,j]:.1f}',ha='center',va='center',color='white' if pp.iloc[i,j]>55 else '#26384B')
    fig.colorbar(im,ax=ax,label='Within-strategy prevalence (%)',shrink=.75)
    fig.suptitle('Judgments within the three text-based strategy clusters',fontsize=12,y=1.02)
    fig.text(.5,.015,'Rounds 15, 25, 35, 45; conditions weighted equally. Labels overlap.\n* Catch-up coding has known boundary ambiguities.',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.09,1,.99));savefig(fig,'01_strategy_judgments')
    fig,axs=plt.subplots(1,2,figsize=(12,6),sharey=True)
    for ax,kind,title in zip(axs,['rank','ability'],['Similar ability, different rank','Similar rank, different ability']):
        rr=m[m.setting==kind+'_primary'].set_index('code').loc[SELECT]
        for i,c in enumerate(SELECT):
            vals=pd.read_csv(OUT/(kind+'_primary_condition_effects.csv'))[c]
            ax.scatter(vals,np.repeat(i,len(vals)),s=18,alpha=.35,c='#8295AA',edgecolors='none')
        ax.scatter(rr.delta_pp,np.arange(8),c='#173F70',s=48,label='Equal-condition mean',zorder=3)
        ax.axvline(0,c='#8B9298',lw=.8,ls='--');ax.set_title(title,fontsize=11)
        ax.set_xlabel('Judgment prevalence difference (percentage points)')
        ax.set_yticks(range(8),[NAMES[c] for c in SELECT]);ax.grid(axis='x',alpha=.16);ax.set_xlim(-25,25)
        inf=support[support.setting==kind+'_primary'].iloc[0]
        note=('Better rank minus worse rank; ability gap <= 0.05 SD; rank gap >= 20.' if kind=='rank' else 'Higher ability minus lower ability; rank gap <= 10; ability gap >= 1 SD.\nBoth agents on the same side of the reward boundary.')
        ax.text(.5,-.24,note+f'\n{int(inf.n_pairs):,} pairs, {int(inf.n_conditions)} conditions; exact condition and round.',transform=ax.transAxes,ha='center',fontsize=8)
    axs[0].invert_yaxis()
    fig.text(.60,.015,'Large dots: equal-condition means. Small dots: individual conditions. No causal interpretation.',ha='center',fontsize=8.5)
    fig.subplots_adjust(left=.22,right=.99,top=.90,bottom=.30,wspace=.12)
    savefig(fig,'02_matched_judgment_differences')
    fig,axs=plt.subplots(1,2,figsize=(10,4))
    for ax,kind in zip(axs,['rank','ability']):
        sub=support[support.setting.str.startswith(kind)].copy()
        ax.barh(sub.setting.str.replace(kind+'_','',regex=False),sub.n_pairs,color='#52779C')
        for i,n in enumerate(sub.n_pairs):ax.text(n,i,f' {int(n):,}',va='center',fontsize=9)
        ax.set_title(kind.capitalize()+' comparison');ax.set_xlabel('Disjoint pairs within condition and round')
        ax.invert_yaxis();ax.set_xlim(0,sub.n_pairs.max()*1.2)
    fig.tight_layout();savefig(fig,'03_matching_support')

def additional(d,codes):
    """Check sample composition, nonlinearity at eligibility, and code coverage."""
    matched=[];composition=[]
    for setting in ['rank_primary','ability_primary']:
        p=pd.read_csv(OUT/(setting+'_pairs.csv'))
        a=d.loc[p.a].reset_index(drop=True);b=d.loc[p.b].reset_index(drop=True)
        categories=np.select([a.inside&b.inside,~a.inside&~b.inside],['both_inside','both_outside'],default='cross_boundary')
        for cat in np.unique(categories):
            mask=categories==cat
            dif=pd.DataFrame((a.loc[mask,codes].to_numpy()-b.loc[mask,codes].to_numpy())*100,columns=codes)
            dif['experiment']=p.loc[mask,'experiment'].to_numpy();by=dif.groupby('experiment')[codes].mean()
            for c in codes:matched.append(dict(setting=setting,support_region=cat,code=c,n_pairs=int(mask.sum()),n_conditions=len(by),delta_pp=by[c].mean(),
                conditions_positive=int((by[c]>0).sum()),conditions_negative=int((by[c]<0).sum()),condition_min=by[c].min(),condition_max=by[c].max()))
        for side,h in [('a',a),('b',b)]:
            composition.append(dict(setting=setting,side=side,n=len(h),mean_ability=h.intrinsic_ability.mean(),
              mean_rank=h.rank_before_decision.mean(),median_rank=h.rank_before_decision.median(),inside_percent=h.inside.mean()*100,
              ability_high_percent=(h.ability_group=='high').mean()*100,ability_middle_percent=(h.ability_group=='middle').mean()*100,
              ability_low_percent=(h.ability_group=='low').mean()*100))
    csv(pd.DataFrame(matched),'matched_contrasts_by_support_region');csv(pd.DataFrame(composition),'matched_sample_composition')
    v=d[d.rank_before_decision.notna()].copy()
    margin=v.rank_before_decision-200*v.q
    v['boundary_position']=np.select([margin<=-10,margin<=0,margin<=10],['inside_buffer10plus','inside_last10','outside_first10'],default='outside_farther10')
    h=v.groupby(['experiment','boundary_position'])[codes].mean()*100
    csv(h.reset_index(),'judgments_near_reward_boundary_by_condition')
    agg=h.groupby('boundary_position').mean();csv(agg.reset_index(),'judgments_near_reward_boundary')
    fig,axs=plt.subplots(1,2,figsize=(10,4.7))
    dim=pd.read_csv(OUT/'dimension_coverage.csv');dim=dim[dim.period=='post_feedback']
    axs[0].barh(['D1 Rewards/costs','D2 Perceived position','D3 Efficacy/ability','D4 Action intent','D5 Others'],dim.equal_condition_percent,color='#52779C')
    for i,x in enumerate(dim.equal_condition_percent):axs[0].text(x+1,i,f'{x:.2f}%',va='center',fontsize=9)
    axs[0].set(xlim=(0,110),xlabel='At least one substantive code (%)',title='A. Five coding dimensions');axs[0].invert_yaxis()
    focus=pd.read_csv(ROOT/'reason_analysis/ability_focus/reasons_with_focus.csv',keep_default_na=False)
    cols=[c for c in focus if c.startswith('focus_')]
    focus=v[KEY].merge(focus[KEY+cols],on=KEY,validate='one_to_one')
    topic=focus.groupby('experiment')[cols].mean().mean()*100
    csv(topic.rename('equal_condition_percent').rename_axis('topic').reset_index(),'literal_topic_mentions_postfeedback')
    topicnames=['Rewards/costs','Position','Qualification','Effectiveness','Own ability','Time','Others','Learning']
    order=['focus_cost_reward','focus_position','focus_qualification','focus_effectiveness','focus_ability','focus_time','focus_others','focus_learning']
    axs[1].barh(topicnames,topic.loc[order],color='#8A9254')
    for i,x in enumerate(topic.loc[order]):axs[1].text(x+1,i,f'{x:.1f}%',va='center',fontsize=9)
    axs[1].set(xlim=(0,115),xlabel='Literal topic mention (%)',title='B. Separate checks of topic mentions');axs[1].invert_yaxis()
    fig.text(.5,.01,'Rounds 6-50; equal-condition averages. A coded judgment and a topic mention are different measurements.',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.07,1,1));savefig(fig,'00_coding_and_topic_overview')
    within=pd.read_csv(OUT/'within_agent_rank_associations_std1.csv').set_index('code')
    fig,ax=plt.subplots(figsize=(7,4.8));vals=within.loc[SELECT,'pp_per20_better_rank']
    ax.barh([NAMES[c] for c in SELECT],vals,color=['#52779C' if x>=0 else '#B66B58' for x in vals])
    for i,x in enumerate(vals):ax.text(x+(.1 if x>=0 else -.1),i,f'{x:+.2f}',ha='left' if x>=0 else 'right',va='center',fontsize=9)
    ax.axvline(0,c='#777777',lw=.7);ax.invert_yaxis();ax.set_xlim(-7,8)
    ax.set(title='Judgments change with rank within the same agent',xlabel='Percentage-point association per 20-place better rank')
    fig.text(.5,.01,'Agent and condition-by-round fixed effects. Ability is fixed within each agent. Descriptive associations.',ha='center',fontsize=8)
    fig.tight_layout(rect=(0,.06,1,1));savefig(fig,'04_within_agent_rank_associations')
    order=['inside_buffer10plus','inside_last10','outside_first10','outside_farther10']
    matrix=agg.loc[order,['D2a','D2b','D2c','D2d']]
    fig,ax=plt.subplots(figsize=(7,3.8));im=ax.imshow(matrix,cmap='YlGnBu',vmin=0,vmax=60,aspect='auto')
    ax.set(yticks=range(4),yticklabels=['Inside: buffer >= 10 places','Inside: last 10 places','Outside: first 10 places','Outside: more than 10 places'],
      xticks=range(4),xticklabels=['Secure lead','At risk','Catch-up\nattainable*','Catch-up\nunlikely'])
    for i in range(4):
        for j in range(4):ax.text(j,i,f'{matrix.iloc[i,j]:.1f}',ha='center',va='center',color='white' if matrix.iloc[i,j]>32 else '#26384B')
    fig.colorbar(im,ax=ax,label='Judgment prevalence (%)',shrink=.8)
    ax.set_title('Judgments relative to the reward boundary',pad=12)
    fig.text(.5,.01,'Descriptive, not ability-matched. Equal-condition means; all four positions exist in all 12 conditions.\n* Catch-up coding requires boundary review.',ha='center',fontsize=8)
    fig.tight_layout(rect=(0,.10,1,1));savefig(fig,'05_reward_boundary_judgments')
    # Source-linked quotations illustrate candidates; they are not adjudicated examples.
    cases=[]
    p=pd.read_csv(OUT/'rank_primary_pairs.csv')
    for exp,g in p.groupby('experiment'):
        for label_a,label_b,tag in [('D2a','D2d','secure_vs_unlikely'),('D2b','D2d','at_risk_vs_unlikely')]:
            aa=d.loc[g.a];bb=d.loc[g.b]
            mask=(aa[label_a].to_numpy()==1)&(bb[label_b].to_numpy()==1)
            candidate=g[mask].sort_values(['ability_gap_sd','round'])
            if len(candidate):
                row=candidate.iloc[0];rec=dict(experiment=exp,round=int(row['round']),comparison=tag)
                for side,idx in [('a',int(row.a)),('b',int(row.b))]:
                    h=d.loc[idx]
                    for col in ['agent_id','intrinsic_ability','rank_before_decision','investment','reason','evidence']:
                        rec[side+'_'+col]=h[col]
                cases.append(rec)
    csv(pd.DataFrame(cases),'illustrative_rank_pair_reason_candidates')

def main():
    d,s,codes,book=load();print('loaded',len(d),len(s),flush=True)
    p=profiles(d,s,codes);m,support=matching(d,codes);joint,within=models(d,codes);figures(p,m,support);additional(d,codes)
    csv(d[KEY+['uid','q','reward','intrinsic_ability','ability_z','ability_pct','ability_group','rank_before_decision','inside','investment','numeric_behavior']+codes], 'prepared_main_decisions')
    csv(s[KEY+['strategy','investment','rank_before_decision']+codes], 'prepared_strategy_snapshots')
    meta=dict(scope='12 std1 runs only, one run per condition',n_decisions=len(d),n_postfeedback=int(d.rank_before_decision.notna().sum()),
      n_snapshot_records=len(s),n_snapshot_postfeedback=int((s['round']>5).sum()),codes=codes,
      matching='Greedy non-reused pairs per exact experiment-round; ranked by closest matching variable then widest contrast.',
      primary_rank='ability gap <=0.05 within-condition agent ability SD; rank gap >=20',
      primary_ability='rank gap <=10; ability gap >=1 SD; same side of qualification boundary',
      estimand='Matched-sample descriptive prevalence differences; equal weight for available conditions.',
      independent_units='12 distinct condition runs, not independent replications of any condition. Agent-rounds and pairs are repeated.',
      limitations=['rules_v1.1 not independently human validated','D2c/D3a boundaries need review','D4c/D4d depend on D2 by coding construction',
       'Matching does not control all past feedback/history or imply causation','Text clusters and codes use the same rationale text',
       'Shared support changes with calipers; sensitivity estimates describe different matched samples'],
      source_sha256={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'pic/pca_global_coordinates.npz',ROOT/'reason_analysis/labeled_v1/reasons_labeled.csv']})
    (OUT/'metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
    print('OUTPUT',OUT,flush=True)
    print(m[m.setting.isin(['rank_primary','ability_primary'])&m.code.isin(SELECT)][['setting','code','delta_pp','n_pairs','conditions_positive','conditions_negative']].to_string(index=False))

if __name__=='__main__':main()
