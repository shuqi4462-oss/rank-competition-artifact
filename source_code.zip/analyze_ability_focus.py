"""Focus-object aggregation and rank-matched ability comparisons.

Keeps existing labels untouched. Distinguishes label aggregation from literal
topic-mention supplements and reports sensitivity to both definitions.
"""
import json,re
from pathlib import Path
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'reason_analysis/ability_focus'
OUT.mkdir(exist_ok=True)
NAMES={'cost_reward':'奖励与成本','position':'竞争位置','qualification':'获奖机会',
       'effectiveness':'投入效能','ability':'自身能力','time':'时间因素',
       'others':'他人行为','learning':'信息与学习'}
MERGE={'cost_reward':['D1a','D1c'],'position':['D2a','D2b','D2c','D2d','D2e'],
       'qualification':['D1b'],'effectiveness':['D3a','D3b','D3c'],
       'ability':['D3d','D3e'],'others':['D5a','D5b','D5c','D5d'],
       'learning':['D1d','D4e'],'time':[]}
PATTERNS={
 'cost_reward':r'\b(?:reward|prize|cost\w*|capital|wealth|saving|savings)\b|(?:preserv\w*|retain\w*|keep\w*|conserv\w*).{0,30}(?:units|100|funds)',
 'position':r'\b(?:rank|ranking|ranked|cutoff|buffer|cushion|eligibility|eligible|qualification|reward zone)\b',
 'qualification':r'\b(?:probability|odds|chance|likelihood|prospect|recoverable|attainable|unattainable|recovery|qualifying|qualify|achievable)\b|(?:finish|qualification|qualifying|reaching|entering).{0,40}(?:unlikely|likely|impossible|secure|uncertain)|(?:unlikely|impossible).{0,40}(?:finish|qualification|qualifying|reach|enter)',
 'effectiveness':r'(?:invest\w*|spend\w*).{0,65}(?:produc\w*|generat\w*|yield\w*|deliver\w*|result\w*|effect\w*|benefit\w*|response|return\w*|support\w*|improv\w*)|(?:score|scoring|return|result|benefit|effect|response|performance).{0,40}(?:from|with|of|to|under|after|than|at).{0,25}(?:invest\w*|spend\w*)|(?:conversion|score efficiency|scoring efficiency)|(?:higher|extra|additional|more|lower|low|zero)\W+invest\w*.{0,45}(?:unnecessary|unjustified|unreliable|effective|ineffective)|(?:poor|weak|uncertain|demonstrated).{0,25}value.{0,35}(?:invest\w*|spend\w*)',
 'ability':r'\b(?:scoring ability|intrinsic ability|competitive ability|own ability|my ability|uncertain ability|superior ability|weak ability|limited ability|ability advantage|scoring advantage|scoring disadvantage|scoring dominance)\b',
 'time':r'\b(?:rounds? (?:left|remain\w*|to go)|remaining (?:(?:\d+|one|two|three|four|five) )?(?:rounds?|time)|last (?:few |five |ten )?rounds?|final (?:round|rounds|block|phase|stage)|only (?:one|two|three|four|five|\d+) rounds?|(?:one|two|three|four|five|\d+) rounds? (?:left|remain\w*|to go)|checkpoint|time (?:left|remain\w*)|early (?:rounds?|stage)|late (?:rounds?|stage)|first (?:five.round |ranking )?checkpoint)\b',
 'others':r'\b(?:other (?:agents|players|investors)|others|competitors?|rivals?|opponents?|neighbors?)\b',
 'learning':r'\b(?:test|testing|explor\w*|learn\w*|information|evidence|feedback|signal|observation\w*|benchmark|uncertain|uncertainty|unknown|unclear|unproven|reassess\w*)\b|(?:adjust|revise|respond).{0,30}(?:after|once).{0,25}(?:rank|score|feedback)',
}
RE={k:re.compile(p,re.I) for k,p in PATTERNS.items()}

def save(df,name):df.to_csv(OUT/name,index=False,encoding='utf-8-sig')

def paired(frame,width,columns):
    a=frame[(frame.ability_group!='middle')&frame['rank_before_decision'].notna()].copy()
    a['stratum']=a.experiment+'|'+a['round'].astype(str)+'|'+((a.rank_before_decision-1)//width).astype(int).astype(str)
    tab=a.groupby(['stratum','ability_group']).size().unstack(fill_value=0)
    eligible=tab.index[(tab.high>0)&(tab.low>0)]
    a=a[a.stratum.isin(eligible)].copy()
    a['high']=(a.ability_group=='high').astype(float)
    cols=['high']+columns
    r=a[cols]-a.groupby('stratum')[cols].transform('mean')
    x=r.high.to_numpy();xx=x@x;clusters=a.experiment.to_numpy()
    out=[]
    for col in columns:
        y=r[col].to_numpy();b=float(x@y/xx)
        scores=pd.Series(x*(y-b*x)).groupby(clusters).sum().to_numpy()
        g=len(scores);se=np.sqrt((scores@scores)/(xx*xx)*g/(g-1)) if g>1 else np.nan
        critical={12:2.201,13:2.179,14:2.160,15:2.145,16:2.131,17:2.120,18:2.110}.get(g,2.3)
        out.append({'rank_band_width':width,'focus':col,'name':NAMES[col.replace('merged_','').replace('focus_','')],
                    'high_minus_low_pp':100*b,'cluster_experiment_se_pp':100*se,
                    'approx_95_lower_pp':100*(b-critical*se),'approx_95_upper_pp':100*(b+critical*se),
                    'n_records_common_support':len(a),'n_agents_common_support':a[['experiment','agent_id']].drop_duplicates().shape[0],
                    'n_strata_common_support':len(eligible),'n_experiments_common_support':a.experiment.nunique()})
    return pd.DataFrame(out),a

def main():
    d=pd.read_csv(ROOT/'reason_analysis/labeled_v1/reasons_labeled.csv',keep_default_na=False)
    d=d[d.quality!='Q3'].copy()
    for c in ['agent_id','round','intrinsic_ability','rank_before_decision','investment']:d[c]=pd.to_numeric(d[c],errors='coerce')
    labelsets=(d.D1+';'+d.D2+';'+d.D3+';'+d.D4_primary+';'+d.D4_secondary+';'+d.D5).str.split(';').apply(set)
    for key in NAMES:
        d['merged_'+key]=labelsets.apply(lambda s:any(c in s for c in MERGE[key])).astype(int)
        # Topic mentions are checked independently from evaluative labels.
        # An absent merged label is not proof the topic was absent.
        d['focus_'+key]=d.reason.apply(lambda s:int(bool(RE[key].search(s))))
    agents=d[['experiment','agent_id','intrinsic_ability']].drop_duplicates()
    agents['ability_pct']=agents.groupby('experiment').intrinsic_ability.rank(method='first',pct=True)
    agents['ability_group']=np.where(agents.ability_pct<=.25,'low',np.where(agents.ability_pct>.75,'high','middle'))
    d=d.merge(agents,on=['experiment','agent_id','intrinsic_ability'],validate='many_to_one')
    cols=['focus_'+k for k in NAMES];merged=['merged_'+k for k in NAMES if k!='time']
    summary=[]
    for col in cols+merged:
        h=d[d.ability_group=='high'][col].mean();l=d[d.ability_group=='low'][col].mean()
        f=d.groupby(['experiment','ability_group'])[col].mean().unstack()
        summary.append({'focus':col,'name':NAMES[col.replace('focus_','').replace('merged_','')],
                        'high_percent':100*h,'low_percent':100*l,'high_minus_low_pp':100*(h-l),
                        'n_mentions':int(d[col].sum()),'n_conditions_high_more':int((f.high>f.low).sum()),
                        'n_conditions_low_more':int((f.high<f.low).sum())})
    summary=pd.DataFrame(summary);save(summary,'focus_by_ability.csv')
    per=d.groupby(['experiment','ability_group'])[cols+merged].mean().reset_index()
    save(per,'focus_by_experiment.csv')
    matches=[]
    for width in [5,10,20]:
        result,matched=paired(d,width,cols+merged);matches.append(result)
        if width==10:
            save(matched[['experiment','agent_id','round','rank_before_decision','intrinsic_ability','ability_group']], 'matched_sample_index.csv')
    result=pd.concat(matches,ignore_index=True);save(result,'rank_matched_comparisons.csv')
    # Nonlinear regression sensitivity uses all high/low observations with rank
    # feedback; matching remains the main comparison because support is uneven.
    a=d[(d.ability_group!='middle')&d.rank_before_decision.notna()].copy()
    a['cell']=a.experiment+'|'+a['round'].astype(str)
    a['high']=(a.ability_group=='high').astype(float)
    z=(a.rank_before_decision-100.5)/100
    a['rank1']=z;a['rank2']=z*z;a['rank3']=z*z*z
    a['text_length']=a.reason.str.split().str.len()
    regress=[]
    for length in [False,True]:
        controls=['high','rank1','rank2','rank3']+(['text_length'] if length else [])
        r=a[controls+cols]-a.groupby('cell')[controls+cols].transform('mean')
        x=r[controls].to_numpy(float);y=r[cols].to_numpy(float)
        b=np.linalg.lstsq(x,y,rcond=None)[0]
        for j,col in enumerate(cols):regress.append({'focus':col,'name':NAMES[col[6:]],'controls_text_length':length,'high_minus_low_pp':100*b[0,j]})
    save(pd.DataFrame(regress),'nonlinear_rank_adjusted.csv')
    # Existing extraction supplies pre-decision recent scores and investments.
    records=[]
    allowed=set(d.experiment)
    for folder in sorted((ROOT/'data/reward_experiment/llm_reward').glob('**/rounds')):
        parts=folder.relative_to(ROOT/'data/reward_experiment/llm_reward').parts
        experiment='_'.join(parts[:3])
        if experiment not in allowed:continue
        for file in sorted(folder.glob('round_*.json')):
            raw=json.loads(file.read_text(encoding='utf-8'))
            records.extend({'experiment':experiment,'agent_id':row['agent_id'],'round':raw['round'],
                            'score':row['score'],'investment':row.get('current_round_investment',row.get('input'))}
                           for row in raw['agents_data'])
    history=pd.DataFrame(records)
    history=history.sort_values(['experiment','agent_id','round'])
    for col in ['score','investment']:
        history['recent_'+col]=history.groupby(['experiment','agent_id'])[col].transform(lambda s:s.shift(1).rolling(5,min_periods=1).mean())
    a=a.merge(history[['experiment','agent_id','round','recent_score','recent_investment']],on=['experiment','agent_id','round'],validate='one_to_one')
    # Mean score has extreme tails; use log1p for nonnegative scores.
    assert a.recent_score.min()>=0
    a['log_recent_score']=np.log1p(a.recent_score)
    controls=['high','rank1','rank2','rank3','text_length','log_recent_score','recent_investment']
    r=a[controls+cols]-a.groupby('cell')[controls+cols].transform('mean')
    x=r[controls].to_numpy(float);y=r[cols].to_numpy(float);b=np.linalg.lstsq(x,y,rcond=None)[0]
    historyeffects=pd.DataFrame([{'focus':col,'name':NAMES[col[6:]],'high_minus_low_pp':100*b[0,j]} for j,col in enumerate(cols)])
    save(historyeffects,'history_adjusted.csv')
    # Stratified sample for agent-assisted reading, not human gold labels.
    audit=[]
    for group in ['high','low']:
        s=d[d.ability_group==group].sample(16,random_state=314)
        audit.extend(s[['experiment','agent_id','round','reason']+cols].to_dict('records'))
    save(pd.DataFrame(audit),'audit_sample.csv')
    base=['experiment','agent_id','round','intrinsic_ability','rank_before_decision','investment','reason','ability_group']
    save(d[base+cols+merged],'reasons_with_focus.csv')
    assert len(d)==179998 and not d.duplicated(['experiment','agent_id','round']).any()
    metadata={'records':len(d),'focus_names':NAMES,'merged_labels':MERGE,'mention_patterns':PATTERNS,
              'primary_definition':'literal topic mentions, distinct from evaluative labels; supplements do not replace labels',
              'system_errors_excluded':2,'manual_gold_annotations':False,'audit_sample_size':len(audit),
              'matching':'same experiment, same decision round, same rank band; only strata containing both ability extremes',
              'matching_interval':'approximate cluster-experiment t interval with cluster-specific critical value; exploratory, not multiple-testing adjusted',
              'history':'mean score and investment in previous five logged rounds; does not imply every statistic was visible to agent',
              'limitations':['automated mention patterns not validated by independent human coders','matching may retain a selected minority of observations',
                             'rank and historical feedback may mediate ability associations; controls do not identify direct causal effects',
                             'text topic mentions are not internal attention or reasoning quality','only one run per observed condition, 18 experiments total']}
    (OUT/'metadata.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2),encoding='utf-8')
    print('FOCUS SUMMARY');print(summary.round(3).to_string(index=False))
    print('MATCHED');print(result[(result.rank_band_width==10)&result.focus.str.startswith('focus_')].round(3).to_string(index=False))
    print('REGRESSION');print(pd.DataFrame(regress).round(3).to_string(index=False))
    print('HISTORY');print(historyeffects.round(3).to_string(index=False))
    print('AUDIT');print(pd.DataFrame(audit).to_json(orient='records',force_ascii=True))

if __name__=='__main__':main()
