"""LLM-only Figure 9: fixed-budget mechanism choices, audited inputs."""
from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'output/pdf/fixed_budget_preview';OUT.mkdir(parents=True,exist_ok=True)
d=pd.read_csv(ROOT/'output/fixed_P250000_complete/all_current_metrics.csv').sort_values('q').reset_index(drop=True)
assert list(d.P)==[240000,250000,250000,250000]
plt.rcParams.update({'font.family':'Arial','font.size':7,'axes.labelsize':7.5,
 'xtick.labelsize':7,'ytick.labelsize':7,'pdf.fonttype':42,'svg.fonttype':'none',
 'text.color':'#26384B','axes.labelcolor':'#26384B','xtick.color':'#425466','ytick.color':'#425466',
 'axes.spines.top':False,'axes.spines.right':False})
fig,axs=plt.subplots(2,1,figsize=(3.35,2.9),sharex=True)
blue='#245B89'
for ax,key,title,limits,ticks in zip(axs,['Q','D'],['(a) Selection quality, $Q$','(b) Resource dissipation, $D$'],
 [(.88,1.055),(1.31,2.67)],[[.9,.95,1],[1.5,2,2.5]]):
    vals=d[key+'_LLM']
    ax.axvspan(-.43,.43,color='#F0F2F5',zorder=0)
    ax.axvline(.5,color='#AAB3BD',ls=(0,(2,3)),lw=.6)
    ax.plot(range(4),vals,color=blue,lw=1.2,zorder=2)
    ax.scatter([1,2,3],vals.iloc[1:],c=blue,s=25,edgecolors='white',lw=.5,zorder=3)
    ax.scatter([0],[vals.iloc[0]],s=30,facecolor='white',edgecolor=blue,lw=1.1,zorder=3)
    for i,v in enumerate(vals):
        ax.annotate(f'{v:.3f}',(i,v),xytext=(0,6),textcoords='offset points',ha='center',
           va='bottom',fontsize=7,color=blue,weight='bold')
    if key=='D':
        for a,b,txt in [(1,2,'-4.8%'),(2,3,'-33.4%')]:
            ax.text((a+b)/2,(vals.iloc[a]+vals.iloc[b])/2+.15,txt,ha='center',fontsize=6.8,
               color=blue,weight='bold',bbox=dict(fc='white',ec='none',pad=.5,alpha=.9))
    ax.set_ylim(*limits);ax.set_yticks(ticks);ax.set_xlim(-.48,3.38)
    ax.set_title(title,loc='left',fontsize=7.8,pad=3)
    ax.grid(axis='y',color='#E2E7ED',lw=.5);ax.set_axisbelow(True)
    ax.spines[['left','bottom']].set_color('#A7B2BE');ax.spines[['left','bottom']].set_linewidth(.55)
    ax.tick_params(length=2,width=.5,pad=2)
axs[0].tick_params(axis='x',bottom=False)
axs[1].set_xticks(range(4),['$q=.06$\n$R=20k$','$q=.125$\n$R=10k$','$q=.25$\n$R=5k$','$q=.5$\n$R=2.5k$'])
fig.text(.235,.965,'$P=240k$',ha='center',fontsize=6.6,color='#6D7988')
fig.text(.65,.965,'$P=250k$ (equal budget)',ha='center',fontsize=6.6)
fig.subplots_adjust(left=.16,right=.98,top=.85,bottom=.19,hspace=.60)
fig.text(.57,.015,'Shaded column: different budget. Connecting lines are visual guides.',ha='center',fontsize=5.8,color='#6D7988')
for ext in ['pdf','png','svg']:
    fig.savefig(OUT/('fixed_budget_llm_only.'+ext),dpi=350,bbox_inches='tight',pad_inches=.045)
print(OUT)
