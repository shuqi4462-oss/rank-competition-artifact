# Submission and anonymity

Conference policy checked: https://www2027.thewebconf.org/research-track-papers/

The Research Track specifies double-blind review and omission of identifying information. The checked page does not prescribe an anonymous GitHub account, Anonymous GitHub, or a particular code-upload format. This artifact uses an anonymous review repository as an implementation choice, not as a claimed conference mandate.

For a review link, use an anonymizing repository service or a genuinely anonymous GitHub account. A repository hosted directly under an identifiable personal account should not be cited as an anonymous artifact. Configure the review service to omit source-repository links and identifying metadata, then inspect the resulting review page while signed out.

No remote repository or review URL has been created merely by building this directory. Publication status must be verified separately.
