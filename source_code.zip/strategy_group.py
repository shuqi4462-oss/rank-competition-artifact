#!/usr/bin/env python3
"""
绘制策略-排名堆叠柱状图（基于全局聚类，自动扫描实验目录）
每个子图展示一个分面值，x 轴为轮次，每个轮次四个柱子（RZ/NM/MID/LOW）堆叠三种策略。
只绘制两张图：
  1. 固定 R=20000，分面 Q=0.1, 0.4, 0.7
  2. 固定 Q=0.4，分面 R=2500, 5000, 10000, 20000
"""
import os, sys, json
import numpy as np
import re
import matplotlib
matplotlib.rcParams.update({
    'font.family': 'Arial', 'mathtext.fontset': 'dejavusans',
    'pdf.fonttype': 42, 'ps.fonttype': 42,
    'text.color': '#25282C', 'axes.labelcolor': '#25282C',
    'xtick.color': '#454B51', 'ytick.color': '#454B51',
})
import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans
from collections import defaultdict, Counter
from plotting_style import BAR_STRATEGY_COLORS as STRATEGY_COLORS

# =====================================================================
# 第一部分：全局配置
# 作用：定义数据路径、实验参数（Q、R、轮次）、输出目录、策略名称与配色
# =====================================================================
PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_ROOT = os.path.join(PROJECT_DIR, 'data', 'reward_experiment', 'llm_reward')
STD_DIR = "std1"                              # 子目录名

Q_LIST = ["0.1", "0.4", "0.7"]                # 所有 Q 值
REWARDS = ["2500", "5000", "10000", "20000"]  # 所有 R 值

SNAPSHOT_ROUNDS = [5, 15, 25, 35, 45]         # 快照轮次
OUTPUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pic") # 输出目录
os.makedirs(OUTPUT_DIR, exist_ok=True)

N_STRATEGIES = 3
STRATEGY_NAMES = ["aggressive", "moderate", "conservative"]  # 策略名称

# =====================================================================
# 第二部分：自动扫描实验目录
# 作用：遍历 DATA_ROOT/STD_DIR/q_*/reward_*/exp*/，自动找到每个
#       (Q, R) 组合对应的实验目录名，无需手动输入 exp1_xxx
# =====================================================================
def scan_exp_dirs(data_root, std_dir, q_list, rewards):
    exp_dir_map = {}
    std_path = os.path.join(data_root, std_dir)
    if not os.path.exists(std_path):
        raise FileNotFoundError(f"STD path not found: {std_path}")

    for q in q_list:
        q_dir = os.path.join(std_path, f"q_{q}")
        if not os.path.exists(q_dir):
            print(f"  WARNING: Q dir not found: {q_dir}")
            continue
        for reward in rewards:
            r_dir = os.path.join(q_dir, f"reward_{reward}")
            if not os.path.exists(r_dir):
                print(f"  WARNING: Reward dir not found: {r_dir}")
                continue
            subdirs = [d for d in os.listdir(r_dir)
                       if d.startswith("exp") and os.path.isdir(os.path.join(r_dir, d))]
            if not subdirs:
                print(f"  WARNING: No exp dir under: {r_dir}")
                continue
            subdirs.sort()
            exp_dir_map[(q, reward)] = subdirs[-1]
            print(f"  Found Q={q}, R={reward} -> {subdirs[-1]}")
    return exp_dir_map

print("=" * 60)
print("Scanning experiment directories...")
EXP_DIR_MAP = scan_exp_dirs(DATA_ROOT, STD_DIR, Q_LIST, REWARDS)
print(f"Total (Q, R) combinations found: {len(EXP_DIR_MAP)}")

# =====================================================================
# 第三部分：文本归一化函数
# 作用：将 reason 中的具体数值替换为通用占位符，
#       避免聚类被奖励值、排名、轮次、投资额等具体数字干扰
# =====================================================================
def normalize_reason_text(text, reward_value=None):
    text = re.sub(r'\b(2500|5000|10000|20000)\b', '[REWARD]', text)
    text = re.sub(r'\b1\b(?!\d)', '[REWARD]', text)
    text = re.sub(r'rank\s*\d+', '[RANK]', text, flags=re.IGNORECASE)
    text = re.sub(r'\d+\s*rounds?\s*(left|remaining)', '[ROUNDS_LEFT]', text, flags=re.IGNORECASE)
    text = re.sub(r'invest(ment)?\s*\d+', 'invest [INVEST]', text, flags=re.IGNORECASE)
    text = re.sub(r'\b\d+\s*units?\b', '[UNITS]', text)
    text = re.sub(r'top\s*\d+%?', '[TOP_X]', text, flags=re.IGNORECASE)
    text = re.sub(r'score\s*[\d.]+', 'score [SCORE]', text, flags=re.IGNORECASE)
    return text

# =====================================================================
# 第四部分：全局数据加载
# 作用：读取所有 (Q, R, round) 下的 JSON 文件，提取 reason 和元数据
#       （投资额、排名），合并为全局数据集
# =====================================================================
print("=" * 60)
print("Loading ALL data for GLOBAL clustering...")

all_texts = []      # 归一化后的文本，用于聚类
global_meta = []    # 元数据：(q, reward, round, agent_id, investment, rank)

for (q, reward), exp_dir in EXP_DIR_MAP.items():
    rounds_dir = os.path.join(DATA_ROOT, STD_DIR, f"q_{q}",
                              f"reward_{reward}", exp_dir, "expdata", "rounds")
    if not os.path.exists(rounds_dir):
        print(f"  WARNING: rounds dir not found: {rounds_dir}")
        continue
    for rnd in SNAPSHOT_ROUNDS:
        fname = os.path.join(rounds_dir, f"round_{rnd:03d}.json")
        if not os.path.exists(fname):
            print(f"  MISSING: {fname}")
            continue
        with open(fname, encoding='utf-8') as f:
            data = json.load(f)
        for agent in data.get("agents_data", []):
            reason_raw = agent.get("reason", "")
            if not reason_raw or len(reason_raw) < 5:
                continue
            reason_norm = normalize_reason_text(reason_raw, reward)
            all_texts.append(reason_norm)
            global_meta.append((
                q,
                reward,
                rnd,
                int(agent["agent_id"]),
                float(agent.get("current_round_investment", 0)),
                int(agent.get("rank", 100))
            ))

print(f"Total samples: {len(all_texts)}")
if len(all_texts) == 0:
    print("No data. Exiting.")
    sys.exit(1)

# =====================================================================
# 第五部分：全局 TF-IDF + K-Means 聚类
# 作用：对所有 reason 文本进行向量化并聚成 3 类，
#       按平均投资额从高到低命名为 aggressive / moderate / conservative
# =====================================================================
print("\nPerforming GLOBAL TF-IDF and K-Means...")

vectorizer = TfidfVectorizer(
    stop_words='english', max_df=0.8, min_df=3,
    max_features=600, ngram_range=(1, 3)
)
tfidf_matrix = vectorizer.fit_transform(all_texts)

kmeans = KMeans(n_clusters=N_STRATEGIES, random_state=42, n_init=10)
cluster_labels = kmeans.fit_predict(tfidf_matrix)

cluster_avg_invest = defaultdict(list)
for idx, lab in enumerate(cluster_labels):
    cluster_avg_invest[lab].append(global_meta[idx][4])
cluster_mean = {k: np.mean(v) for k, v in cluster_avg_invest.items()}
sorted_clusters = sorted(cluster_mean.items(), key=lambda x: x[1], reverse=True)
cluster_map = {old: STRATEGY_NAMES[rank] for rank, (old, _) in enumerate(sorted_clusters)}
strategy_labels = [cluster_map[l] for l in cluster_labels]
print(f"Global cluster map: {cluster_map}")
print(f"Cluster sizes: {Counter(cluster_labels)}")

# 验证柱状图和散点图使用同一份全局策略分类。
pca_cache = os.path.join(OUTPUT_DIR, 'pca_global_coordinates.npz')
if os.path.isfile(pca_cache):
    with np.load(pca_cache) as cached:
        pca_labels = {(q, reward, int(rnd), int(aid)): str(label)
                      for (q, rnd, aid, invest, rank, reward), label
                      in zip(cached['meta'], cached['strategies'])}
    current_labels = {(q, reward, rnd, aid): label
                      for (q, reward, rnd, aid, invest, rank), label
                      in zip(global_meta, strategy_labels)}
    assert pca_labels == current_labels, 'Global labels differ from the PCA figures.'
    print(f'Verified {len(current_labels)} strategy labels against the PCA figures.')

bar_records = []

# =====================================================================
# 第六部分：构建索引
# 作用：将数据组织成嵌套字典，方便按 (q, reward, round, aid) 快速查询
# =====================================================================
agent_data = defaultdict(lambda: defaultdict(lambda: defaultdict(dict)))  # [q][reward][round][aid]
for i, (q, reward, rnd, aid, _, rank) in enumerate(global_meta):
    agent_data[q][reward][rnd][aid] = (strategy_labels[i], rank)

# =====================================================================
# 第七部分：排名分组函数
# 作用：根据 Q 值动态划分四个排名区间：
#       RZ  = 奖励区（rank 1 到 Q*200）
#       NM  = 惜败区（紧接奖励区）
#       MID = 中游区
#       LOW = 低排名区
# =====================================================================
def get_rank_bands(q):
    total = 200
    rz = int(round(float(q) * total))    # 奖励区大小 = Q * 200
    if rz < 1:
        rz = 1
    if rz > total:
        rz = total
    rem = total - rz                     # 剩余人数
    part = rem // 3                      # 三等分
    extra = rem % 3                      # 余数
    bands = [("RZ", 1, rz)]
    if rem > 0:
        s = rz + 1
        e = s + part + (1 if extra > 0 else 0) - 1
        bands.append(("NM", s, e))
        extra -= 1 if extra > 0 else 0
    else:
        bands.append(("NM", rz+1, rz))
    if rem > part:
        s = bands[-1][2] + 1
        e = s + part + (1 if extra > 0 else 0) - 1
        bands.append(("MID", s, e))
        extra -= 1 if extra > 0 else 0
    else:
        bands.append(("MID", bands[-1][2]+1, bands[-1][2]))
    if bands[-1][2] < total:
        bands.append(("LOW", bands[-1][2]+1, total))
    else:
        bands.append(("LOW", total+1, total))
    return [(name, lo, hi) for name, lo, hi in bands if lo <= hi]

# =====================================================================
# 第八部分：绘图函数
# 作用：绘制 5 行（Round） × N 列（分面值）的堆叠柱状图
#       每列中每个轮次包含四个柱子（RZ/NM/MID/LOW），柱子内堆叠三种策略
#       纵坐标显示该子图所属的条件（固定 Q 时显示 R，固定 R 时显示 Q）
# =====================================================================
def plot_rank_stack(fixed_key, fixed_value, facet_key, facet_values, out_suffix):
    n = len(facet_values)
    # 纵向排列，每行一个分面值
    fig, axes = plt.subplots(n, 1, figsize=(10.8, 10.8), sharey=True)
    if n == 1:
        axes = [axes]

    # 总标题：显示固定的条件，如 "R=20000" 或 "Q=0.4"
    fixed = f'q = {fixed_value}' if fixed_key == 'Q' else f'R = {int(fixed_value):,}'
    fig.suptitle(f'Strategy composition across ranks ({fixed})',
                 x=0.55, y=0.985, fontsize=19, weight='bold')
    fig.text(0.019, 0.985, 'a' if fixed_key == 'Q' else 'b',
             fontsize=23, weight='bold', ha='left', va='top')

    # 子图之间的垂直间距
    fig.subplots_adjust(left=0.115, right=0.99, top=0.86, bottom=0.09,
                        hspace=0.46)

    for fi, val in enumerate(facet_values):
        ax = axes[fi]
        # 确定 Q 值（用于计算排名区间）
        q_val = fixed_value if fixed_key == 'Q' else val
        bands = get_rank_bands(float(q_val))
        n_bands = len(bands)

        # x 轴：每个轮次的位置，间距 1.4
        x = np.arange(len(SNAPSHOT_ROUNDS)) * 1.4
        # 柱宽和组内偏移
        width = 0.23
        offsets = (np.arange(n_bands) - (n_bands - 1) / 2) * 0.25

        # 存储每个柱子顶部的总高度，用于后续标注
        top_values = np.zeros((len(SNAPSHOT_ROUNDS), n_bands))

        for bi, (bname, lo, hi) in enumerate(bands):
            props = {s: [] for s in STRATEGY_NAMES}
            for rnd in SNAPSHOT_ROUNDS:
                agents = []
                for aid in range(1, 201):
                    if fixed_key == 'Q':
                        data = agent_data.get(fixed_value, {}).get(val, {}).get(rnd, {}).get(aid)
                    else:
                        data = agent_data.get(val, {}).get(fixed_value, {}).get(rnd, {}).get(aid)
                    if data:
                        strat, rank = data
                        agents.append((rank, strat))
                # 筛选出该排名区间内的智能体
                band_agents = [(r, s) for r, s in agents if lo <= r <= hi]
                n_total = len(band_agents)
                assert n_total > 0, f'Empty rank band: {q_val}, {val}, {rnd}, {bname}'
                for s in STRATEGY_NAMES:
                    count = sum(1 for _, strat in band_agents if strat == s)
                    props[s].append(count / n_total)
                    bar_records.append(dict(q=q_val,
                        reward=val if fixed_key == 'Q' else fixed_value,
                        round=rnd, band=bname, strategy=s, count=count,
                        band_total=n_total, proportion=count / n_total))
            
            # 堆叠柱状图
            bottom = np.zeros(len(SNAPSHOT_ROUNDS))
            for si, s in enumerate(STRATEGY_NAMES):
                vals = props[s]
                ax.bar(x + offsets[bi], vals, width=width, bottom=bottom,
                       color=STRATEGY_COLORS[s], alpha=0.95,
                       edgecolor='white', linewidth=0.35,
                       label=s.capitalize() if (fi == 0 and bi == 0 and si == 0) else None)
                bottom += np.array(vals)
            top_values[:, bi] = bottom
            assert np.allclose(bottom, 1.0), 'Stacked proportions must sum to 100%.'

        # 在每个柱子上方标注排名分组名称（RZ / NM / MID / LOW）
        for ri, rnd in enumerate(SNAPSHOT_ROUNDS):
            for bi, (bname, lo, hi) in enumerate(bands):
                x_pos = x[ri] + offsets[bi]
                y_pos = top_values[ri, bi]
                if y_pos > 0.02:
                    ax.text(x_pos, 1.035, bname,
                            ha='center', va='bottom', fontsize=9,
                            color='#454B51', transform=ax.get_xaxis_transform(),
                            clip_on=False)

        # x 轴刻度
        ax.set_xticks(x)
        ax.set_xticklabels([str(r) for r in SNAPSHOT_ROUNDS])
        ax.tick_params(axis='both', labelsize=12, direction='out',
                       length=3, width=0.65, pad=5)
        ax.set_xlim(-0.65, x[-1] + 0.65)

        # y 轴设置
        ax.set_ylim(0, 1)
        ax.set_yticks([0, 0.5, 1])
        ax.yaxis.set_major_formatter(PercentFormatter(xmax=1, decimals=0))

        # 纵坐标标签：固定 Q 时显示 R，固定 R 时显示 Q
        if fixed_key == 'Q':
            ylabel_text = f"R = {int(val):,}"
        else:
            ylabel_text = f"q = {val}"
        ax.text(-0.06, 0.5, ylabel_text, fontsize=14, rotation=90,
                va='center', ha='center', transform=ax.transAxes)

        # 网格和边框
        ax.grid(axis='y', color='#E4E7E9', linewidth=0.55)
        ax.set_axisbelow(True)
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        for side in ('left', 'bottom'):
            ax.spines[side].set_color('#7A8188')
            ax.spines[side].set_linewidth(0.65)
        ax.spines['left'].set_bounds(0, 1)

    # 全局图例（策略颜色）
    handles = [plt.Rectangle((0,0),1,1, facecolor=STRATEGY_COLORS[s], edgecolor='white') for s in STRATEGY_NAMES]
    fig.legend(handles, [s.capitalize() for s in STRATEGY_NAMES], loc='upper center',
               ncol=3, fontsize=14, frameon=False, bbox_to_anchor=(0.55, 0.947),
               columnspacing=1.8, handlelength=1.2, handletextpad=0.5)

    # 调整布局，为总标题留出空间
    fig.supxlabel('Round', x=0.55, y=0.018, fontsize=17)
    fig.supylabel('Within-band proportion', x=0.019, y=0.47, fontsize=17)

    # 保存图片
    for ext in ('pdf', 'png'):
        out_path = os.path.join(OUTPUT_DIR, f"strategy_rank_stack_{out_suffix}.{ext}")
        fig.savefig(out_path, dpi=300)
        print(f"Saved: {out_path}")
    plt.close(fig)

# =====================================================================
# 第九部分：执行绘图（只画两张图）
# =====================================================================
print("\n" + "=" * 60)
print("Plotting Figure 1: fixed R=20000, facet by Q")
plot_rank_stack(
    fixed_key='R',
    fixed_value='20000',
    facet_key='Q',
    facet_values=Q_LIST,
    out_suffix='R20000'
)

print("\n" + "=" * 60)
print("Plotting Figure 2: fixed Q=0.4, facet by R")
plot_rank_stack(
    fixed_key='Q',
    fixed_value='0.4',
    facet_key='R',
    facet_values=REWARDS,
    out_suffix='q0.4'
)

with open(os.path.join(OUTPUT_DIR, 'strategy_rank_proportions.json'), 'w', encoding='utf-8') as f:
    json.dump(bar_records, f, indent=2)

# 并排版保持两张图的画布尺寸、标题、图例、绘图区上下边界一致。
from pypdf import PdfReader, PdfWriter, Transformation
from PIL import Image
names = ['strategy_rank_stack_q0.4', 'strategy_rank_stack_R20000']
pages = [PdfReader(os.path.join(OUTPUT_DIR, name + '.pdf')).pages[0] for name in names]
w, h = float(pages[0].mediabox.width), float(pages[0].mediabox.height)
assert all(float(p.mediabox.width) == w and float(p.mediabox.height) == h for p in pages)
writer = PdfWriter()
page = writer.add_blank_page(width=2*w, height=h)
for i, source in enumerate(pages):
    page.merge_transformed_page(source, Transformation().translate(tx=i*w, ty=0))
writer.write(os.path.join(OUTPUT_DIR, 'strategy_rank_stack_side_by_side.pdf'))
images = [Image.open(os.path.join(OUTPUT_DIR, name + '.png')) for name in names]
assert images[0].size == images[1].size
width, height = images[0].size
combined = Image.new('RGB', (2*width, height), 'white')
for i, image in enumerate(images):
    combined.paste(image, (i*width, 0))
    image.close()
combined.save(os.path.join(OUTPUT_DIR, 'strategy_rank_stack_side_by_side.png'))

print("=" * 60)
print("All done! Only two figures generated.")
