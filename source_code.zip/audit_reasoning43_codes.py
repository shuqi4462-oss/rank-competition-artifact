"""Targeted sensitivity check; does not overwrite original codes."""
from pathlib import Path
import json,re
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'output/reasoning43_reanalysis_20261022'
d=pd.read_csv(OUT/'prepared_main_decisions.csv')
raw=pd.read_csv(ROOT/'reason_analysis/labeled_v1/reasons_labeled.csv',keep_default_na=False)
raw=raw[raw.experiment.str.startswith('std1_')&(raw.quality!='Q3')]
keys=['experiment','agent_id','round']
d=d.merge(raw[keys+['reason','evidence','review_reason']],on=keys,validate='one_to_one')
rules=json.loads((ROOT/'reason_analysis/labeled_v1/rules.json').read_text(encoding='utf-8'))['patterns']['D2a']
old=[re.compile(p,re.I) for p in rules]
new=[re.compile(p.replace('(?:buffer|cushion|margin)',r'(?:buffers?|cushions?|margins?)\b'),re.I) for p in rules]
flags=[]
for i,row in d[d.D2a==1].iterrows():
    sentences=[s.strip() for s in re.split(r'(?<=[.!?])\s+(?=[A-Z])',row.reason) if s.strip()]
    original=[s for s in sentences if any(p.search(s) for p in old)]
    revised=[s for s in sentences if any(p.search(s) for p in new)]
    if original and not revised:
        flags.append(dict(row_id=i,**row[keys+['rank_before_decision','investment','reason','evidence']].to_dict(),
                          original_match=' | '.join(original),review_issue='margin keyword matched inside a longer word; no remaining strict D2a regex hit'))
flag=pd.DataFrame(flags);flag.to_csv(OUT/'D2a_word_boundary_review_candidates.csv',index=False,encoding='utf-8-sig')
clean=d.D2a.copy();clean.loc[flag.row_id]=0
checks=[]
for name in ['rank_primary','ability_primary']:
    p=pd.read_csv(OUT/(name+'_pairs.csv'))
    for version,y in [('original',d.D2a),('targeted_word_boundary_sensitivity',clean)]:
        delta=pd.DataFrame({'experiment':p.experiment,'delta':(y.loc[p.a].to_numpy()-y.loc[p.b].to_numpy())*100})
        checks.append(dict(comparison=name,version=version,D2a_delta_pp=delta.groupby('experiment').delta.mean().mean()))
pd.DataFrame(checks).to_csv(OUT/'D2a_word_boundary_sensitivity.csv',index=False,encoding='utf-8-sig')
out=dict(n_D2a=int(d.D2a.sum()),n_boundary_candidates=len(flag),
         conclusion='Targeted lexical sensitivity only; not human-adjudicated recoding. Original files and all primary results unchanged.')
(OUT/'targeted_coding_audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(out);print(pd.DataFrame(checks).to_string(index=False))
