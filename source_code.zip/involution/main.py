import argparse
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from src.exp.runner import ExperimentRunner


def main():
    parser = argparse.ArgumentParser(description="Involution Game Theory Experiments")
    parser.add_argument(
        "--experiment", "-e",
        type=str,
        default="1b",
        choices=["all", "1", "2", "3", "1b", "1l", "2b", "2l", "3l", "custom"],
        help="选择要运行的实验 (all=全部, 1=实验1全部, 1b=实验1baseline, 1l=实验1LLM, 2=实验2全部, 2b=实验2baseline, 2l=实验2LLM, 3=实验3, 3l=实验3LLM, custom=自定义实验3)"
    )
    parser.add_argument(
        "--config", "-c",
        type=str,
        default=os.path.join(os.path.dirname(os.path.abspath(__file__)), "config", "experiment_config.yaml"),
        help="配置文件路径"
    )
    # 自定义实验3参数
    parser.add_argument(
        "--ability-std",
        type=float,
        default=None,
        help="自定义 ability_std (实验3)"
    )
    parser.add_argument(
        "--network-type",
        type=str,
        default=None,
        choices=["none", "small_world", "hybrid"],
        help="自定义网络类型 (实验3)"
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        default=None,
        help="自定义输出目录 (实验3)"
    )

    args = parser.parse_args()
    runner = ExperimentRunner(config_path=args.config)

    experiment_map = {
        "all": runner.run_all,
        "1": lambda: (runner.run_experiment1_baseline(), runner.run_experiment1_llm()),
        "1b": runner.run_experiment1_baseline,
        "1l": runner.run_experiment1_llm,
        "2": lambda: (runner.run_experiment2_baseline(), runner.run_experiment2_llm()),
        "2b": runner.run_experiment2_baseline,
        "2l": runner.run_experiment2_llm,
        "3": runner.run_experiment3_llm,
        "3l": runner.run_experiment3_llm,
        "custom": lambda: runner.run_experiment3_llm(
            ability_std=args.ability_std,
            network_type=args.network_type,
            output_dir=args.output_dir
        ),
    }

    experiment_map[args.experiment]()


if __name__ == "__main__":
    main()