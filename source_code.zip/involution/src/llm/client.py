"""
LLM 客户端封装模块（针对 Shubiaobiao API）
-------------------------------------------------
该模块提供统一的语言模型调用接口，供智能体（Agent）使用。
主要职责：
1. 接收 prompt 文本；
2. 调用 Shubiaobiao 的 Chat Completion 接口；
3. 返回模型生成的纯文本响应；
4. 提供容错与调试输出。
-------------------------------------------------
"""
import os
import logging
import time
import threading
import concurrent.futures
from typing import Optional
from openai import OpenAI  # 使用 OpenAI 官方客户端

class LLMClient:
    """
    Shubiaobiao API 客户端
    """
    def __init__(self,
                 api_key: Optional[str] = None,
                 base_url: str = "https://api.openai.com/v1",
                 model_name: str = "gpt-4o",  
                 temperature: float = 1,
                 max_tokens: int = 1024,
                 verbose: bool = False,
                 default_timeout: float = 120.0):
        """
        初始化 Shubiaobiao API 客户端
        Args:
            api_key: Shubiaobiao API Key。如果为 None，则使用环境变量 DEEPSEEK_API_KEY。
            base_url: Shubiaobiao API 基础 URL
            model_name: 使用的模型名称
            temperature: 控制生成的随机性
            max_tokens: 最大返回长度
            verbose: 是否输出调试信息
            default_timeout: 默认超时时间（秒）
        """
        self.api_key = api_key or os.getenv("LLM_API_KEY")
        if not self.api_key:
            raise ValueError("Shubiaobiao API key not provided")
        
        self.base_url = os.getenv('LLM_BASE_URL', base_url).rstrip('/')
        self.model_name = os.getenv('LLM_MODEL', model_name)
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.verbose = verbose
        self.default_timeout = default_timeout

        # 初始化 OpenAI 客户端
        self.client = OpenAI(
            base_url=self.base_url,
            api_key=self.api_key,
            timeout=self.default_timeout  # 设置默认超时
        )

        if self.verbose:
            logging.info(f"[LLMClient] Initialized with model {self.model_name}, base_url {self.base_url}")

    def generate(self, prompt: str) -> str:
        """
        向 Shubiaobiao API 发送 prompt，并返回响应文本。
        Args:
            prompt: 输入提示词文本
        Returns:
            response_text: 模型输出文本
        """
        completion = self.client.chat.completions.create(
            model=self.model_name,
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": prompt}
            ],
            temperature=self.temperature,
            max_tokens=self.max_tokens
        )

        content = completion.choices[0].message.content.strip()
        if self.verbose:
            logging.info(f"[LLMClient] Response: {content[:200]}")
        return content

    def generate_with_timeout(self, prompt: str, timeout_seconds: Optional[float] = None) -> str:
        """
        带超时控制的生成方法
        Args:
            prompt: 输入提示词文本
            timeout_seconds: 超时时间（秒），默认为 default_timeout
        Returns:
            response_text: 模型输出文本
        """
        if timeout_seconds is None:
            timeout_seconds = self.default_timeout

        # 使用线程池执行器实现超时控制
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
            future = executor.submit(self.generate, prompt)
            try:
                result = future.result(timeout=timeout_seconds)
                return result
            except concurrent.futures.TimeoutError:
                future.cancel()
                logging.warning(f"[LLMClient] Generation timeout after {timeout_seconds} seconds")
                raise TimeoutError(f"LLM generation timeout after {timeout_seconds} seconds")

    def set_model(self, model_name: str):
        """
        动态切换模型
        """
        self.model_name = os.getenv('LLM_MODEL', model_name)
        if self.verbose:
            logging.info(f"[LLMClient] Switched model to {self.model_name}")

    def set_temperature(self, temperature: float):
        """
        动态调整随机性参数
        """
        self.temperature = temperature
        if self.verbose:
            logging.info(f"[LLMClient] Temperature set to {self.temperature}")

    def __repr__(self):
        return f"<LLMClient model={self.model_name}, temp={self.temperature}, timeout={self.default_timeout}>"