"""
提示词管理模块
负责根据实验类型生成不同的提示词模板
"""
from typing import Dict, Any, List


class PromptManager:
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.experiment_type = config.get('experiment', {}).get('type', 1)
        self.final_reward = config.get('resources', {}).get('final_reward') 
        self.top_percentage = config.get('resources', {}).get('top_percentage') * 100
    def get_decision_prompt(self, agent_id: int, visible_info: Dict[str, Any], memory: str) -> str:
        """
        生成决策提示词
        """
        total_agents = self.config['agent_params']['count']
        total_rounds = self.config['experiment']['total_rounds']
        current_round = visible_info['current_round']
        rounds_left = total_rounds - current_round 
        
        total_assets = visible_info.get('total_assets', 0)
        total_investment = visible_info.get('total_investment', 0)
        
        base_prompt = f"""
Scenario Information:
You are a professional investor (ID: {agent_id}) participating in an investment game with {total_agents} players.
Your objective is to maximize your final total wealth.

Investment Rules:
1. The game lasts for {total_rounds} rounds. The current round is round {current_round + 1}.
2. In each round, you receive 100 units of capital. You must decide how much to invest this round, between 0 and 100.
   The capital received each round can only be used in that round.
3. Any capital not invested in a round is directly added to your final total wealth and cannot be used later.
4. After deciding your investment amount, the environment will return a score. This score depends on your relative 
   investment level compared to others.
5. Your score in each round is related to the relative level of your investment amount among the group in that round
   your own scoring ability, and random factors.
6. Every 5 rounds, the environment computes your ranking based on the average of your accumulated scores.
7. The score itself does not directly affect your final reward; it is only used to determine rankings.
8. Final reward: after 50 rounds, the top {self.top_percentage}% of agents by ranking receive a reward of {self.final_reward} units. Others receive 0.
9. Final total wealth = uninvested capital from all rounds + final reward (0 or {self.final_reward}).

{memory}

Key Financial and Ranking Information:
Rounds remaining until the end: {rounds_left}
Current accumulated total assets: {total_assets}
Historical total investment amount: {total_investment}

Thinking Guidance:
Please follow these steps carefully, with the goal of maximizing your final total wealth:
1. List the key pieces of information that directly affect your final wealth.
2. Reconfirm your objective: maximizing final wealth, considering the final reward, remaining rounds, and current ranking.
3. Reflect on historical experience: examine recent 5 rounds of scores and investment trends, and assess your ranking 
   position and average score.
4. Based on the above, evaluate the marginal value of additional investment. Given the current round, what is the 
   probability that you can enter the final reward zone? How does the required cumulative investment compare to the 
   potential final reward?
5. Consider your own ability level assessment from recent reflections, and incorporate it into the factors considered in your investment strategy,
   so as to prevent unnecessary waste of funds and missed opportunities.
"""
        
        if self.experiment_type in (2, 3):
            thinking_chain_extension = """6. Based on the above, carefully determine how much to invest this round.
7. Evaluate all available information about your neighbors:
   - Analyze neighbors' investment amounts, score trends, and ranking fluctuations over the last 3–5 rounds.
   - Compare your investment intensity with neighbors and assess their impact on the overall ranking structure.
   - Anticipate neighbors' potential next strategies (conservative vs aggressive) and their threat to your ranking.
8. Final decision: choose a specific investment_amount (0–100) and provide 1–2 sentences of justification.
"""
        else:
            thinking_chain_extension = """6. Based on the above, carefully determine how much to invest this round.
7. Final decision: choose a specific investment_amount (0–100) and provide 1–2 sentences of justification.
"""
        
        output_format = """
Decision Output Requirements:
Based on the above information and reasoning process, decide how much to invest this round.

Output Format (must strictly follow, must strictly follow, must strictly follow):
{
    "thinking_process": "<your detailed reasoning>",
    "investment_amount": <a number between 0 and 100, integer>,
    "reason": "<1-2 sentence explanation>"
}

Notes:
1. You must output pure JSON only. Do not include any incorrect or non-standard characters, prefixes, suffixes, or additional explanations. For example, the following is **not allowed**: ```json {...}```.
2. The "investment_amount" must be a number between 0 and 100.
3. All fields must be present; none can be omitted.
4. The "thinking_process" field must contain a detailed explanation of your reasoning before giving the investment decision.
5. Before submitting, double-check that the JSON is correctly formatted and free of errors.
"""
        
        return base_prompt + thinking_chain_extension + output_format

    def get_memory_summary_prompt(self, agent_id: int, memory_content: str) -> str:
        """
        生成记忆总结提示词
        """
        total_agents = self.config.get('agent_params', {}).get('count', 0)
        total_rounds = self.config.get('experiment', {}).get('total_rounds', 0)
        base_summary_prompt = f"""
You are a professional investor (ID: {agent_id}) participating in an investment game with {total_agents} players.
Your objective is to maximize your final total wealth.

Investment Rules:
1. The game lasts for {total_rounds} rounds.
2. In each round, you receive 100 units of capital. You must decide how much to invest this round, between 0 and 100.
   The capital received each round can only be used in that round.
3. Any capital not invested in a round is directly added to your final total wealth and cannot be used later.
4. After deciding your investment amount, the environment will return a score. This score depends on your relative 
   investment level compared to others.
5. Your score in each round is related to the relative level of your investment amount among the group in that round
   your own scoring ability, and random factors.
6. Every 5 rounds, the environment computes your ranking based on the average of your accumulated scores.
7. The score itself does not directly affect your final reward; it is only used to determine rankings.
8. Final reward: after 50 rounds, the top {self.top_percentage}% of agents by ranking receive a reward of {self.final_reward} units. Others receive 0.
9. Final total wealth = uninvested capital from all rounds + final reward (0 or {self.final_reward}).

You are now asked to summarize and reflect on your recent investment experience.

Below is your recent investment performance and observed information:
{memory_content}

Please summarize based on the following aspects:
1. Analyze how effective your recent investment strategies have been, clearly distinguishing between opportunity costs 
   and sunk costs.
2. Evaluate your recent investments together with ranking and average score feedback, and reflect on how to maximize 
   your final wealth.
3. Based on the available information, assess your own scoring ability level (from 1 to 5, where 1 is the lowest and 5 is the highest).
   Provide a specific score and brief reasoning for your assessment.
   Consider: How does your investment translate into scores compared to others? What patterns do you observe?
"""
        
        if self.experiment_type in (2, 3):
            summary_extension = """4. Analyze your neighbors' investment strategies and their relative performance compared to you.
5. Summarize how neighbors' behaviors influenced your ranking and asset accumulation, and extract actionable insights.
6. Plan your next-stage investment strategy, clarifying how to respond to neighbors to improve your ranking.
"""
        else:
            summary_extension = """4. Summarize successful experiences and key mistakes.
5. Plan your next-stage investment strategy.
"""
        
        conclusion = """
Important: After your reflection, you MUST output pure JSON only, following the same format as decide_input. Do not include any incorrect or non-standard characters, prefixes, suffixes, or additional explanations.
Output Format (must strictly follow, must strictly follow, must strictly follow):
{
    "ABILITY_ASSESSMENT": <Your self-assessed ability level from 1 to 5, integer>,
    "MEMORY_SUMMARY": "<1-2 concise paragraphs (within 200 words) to summarize your recent investment experience>"
}

Notes:
1. The "ABILITY_ASSESSMENT" must be an integer between 1 and 5.
2. All fields must be present; none can be omitted.
3. Before submitting, double-check that the JSON is correctly formatted and free of errors.
"""
        return base_summary_prompt + summary_extension + conclusion
