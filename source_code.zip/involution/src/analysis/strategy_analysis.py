#!/usr/bin/env python3
"""
实验1 策略分析：TF-IDF 语义聚类 + K-Means 策略分类 + PCA 可视化 + 策略投入分析

适配：3 个 reward 条件（1, 500, 5000）替代原文的 3 种网络结构
输出：
  - Fig 4:  PCA 2D 策略分布快照（每 reward 一列，每 10 轮一行）
  - Table 2: 各 reward 条件下各策略占比表
  - Fig 5:  各策略类型平均投入曲线
"""
import sys, os, json, re
import numpy as np
import matplotlib
matplotlib.rcParams['font.family'] = 'Times New Roman'
matplotlib.rcParams['mathtext.fontset'] = 'stix'
import matplotlib.pyplot as plt
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from collections import defaultdict

# ========================= 配置 =========================
DATA_ROOT = "data/reward_experiment/llm_reward"
OUTPUT_DIR = "data/reward_experiment/picture"
REWARDS = ["1", "500", "5000"]
REWARD_LABELS = {"1": "Reward=1", "500": "Reward=500", "5000": "Reward=5000"}
EXP_DIRS = {
    "1": "exp1_20260514_150656",
    "500": "exp1_20260515_093854",
    "5000": "exp1_20260515_122314",
}
SNAPSHOT_ROUNDS = [5, 15, 25, 35, 45]
N_STRATEGIES = 3
STRATEGY_NAMES = ["aggressive", "moderate", "conservative"]
STRATEGY_COLORS = {"aggressive": "#F44336", "moderate": "#4CAF50", "conservative": "#2196F3"}

DPI = 300
os.makedirs(OUTPUT_DIR, exist_ok=True)

# ========================= 1. 数据加载 =========================
# 结构: summaries[reward][round_num] = [(agent_id, memory_summary_text, input, score), ...]
summaries = {r: {} for r in REWARDS}
all_texts = []
text_meta = []  # (reward, round_num, agent_id, input, score)

stop_words = {
    'the', 'a', 'an', 'is', 'are', 'was', 'were', 'be', 'been', 'being',
    'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could',
    'should', 'may', 'might', 'can', 'shall', 'to', 'of', 'in', 'for',
    'on', 'with', 'at', 'by', 'from', 'as', 'into', 'through', 'during',
    'before', 'after', 'above', 'below', 'between', 'under', 'again',
    'further', 'then', 'once', 'here', 'there', 'when', 'where', 'why',
    'how', 'all', 'both', 'each', 'few', 'more', 'most', 'other', 'some',
    'such', 'no', 'not', 'only', 'own', 'same', 'so', 'than', 'too',
    'very', 'and', 'but', 'or', 'if', 'while', 'that', 'this', 'it',
    'its', 'my', 'i', 'me', 'we', 'our', 'he', 'she', 'they', 'also',
    'which', 'just', 'about', 'over', 'within', 'across', 'along',
    'round', 'rounds', 'investment', 'investments', 'invest', 'investing',
    'investor', 'game', 'capital', 'rounds_until_publication',
}

print("=" * 60)
print("Loading data...")

for reward in REWARDS:
    rounds_dir = os.path.join(DATA_ROOT, f"reward_{reward}", EXP_DIRS[reward], "expdata", "rounds")
    for rnd in SNAPSHOT_ROUNDS:
        fname = os.path.join(rounds_dir, f"round_{rnd:03d}.json")
        if not os.path.exists(fname):
            print(f"  MISSING: {fname}")
            continue
        with open(fname) as f:
            rd = json.load(f)
        entries = []
        for agent in rd.get("agents_data", []):
            summary = agent.get("memory_summary")
            if not summary or len(summary) < 20:
                continue
            entries.append((
                int(agent["agent_id"]),
                summary,
                float(agent.get("input", 0)),
                float(agent.get("score", 0)),
                float(agent.get("current_round_investment", 0)),
            ))
        summaries[reward][rnd] = entries
        for aid, txt, inp, sc, invest in entries:
            all_texts.append(txt)
            text_meta.append((reward, rnd, aid, inp, sc, invest))
    print(f"  Reward={reward}: loaded {sum(len(v) for v in summaries[reward].values())} summaries")

print(f"\nTotal summaries: {len(all_texts)}")

# ========================= 2. TF-IDF + K-Means =========================
print("\n" + "=" * 60)
print("TF-IDF vectorization...")
vectorizer = TfidfVectorizer(
    stop_words='english',
    max_df=0.7,
    min_df=5,
    max_features=800,
    ngram_range=(1, 2),
)
tfidf_matrix = vectorizer.fit_transform(all_texts)
print(f"TF-IDF shape: {tfidf_matrix.shape}")

print("K-Means clustering...")
kmeans = KMeans(n_clusters=N_STRATEGIES, random_state=42, n_init=10)
cluster_labels = kmeans.fit_predict(tfidf_matrix)

# 根据聚类中心的平均输入大小命名策略类型
cluster_avg_inputs = {}
for i, label in enumerate(cluster_labels):
    meta_idx = i
    _, _, _, _, _, invest = text_meta[meta_idx]
    if label not in cluster_avg_inputs:
        cluster_avg_inputs[label] = []
    cluster_avg_inputs[label].append(invest)

cluster_mean = {k: np.mean(v) for k, v in cluster_avg_inputs.items()}
sorted_clusters = sorted(cluster_mean.items(), key=lambda x: x[1], reverse=True)
cluster_map = {}
for rank, (old_label, _) in enumerate(sorted_clusters):
    cluster_map[old_label] = STRATEGY_NAMES[rank]

print(f"Cluster mapping (by avg investment):")
for old, new in cluster_map.items():
    print(f"  cluster {old} → {new} (avg_invest={cluster_mean[old]:.1f})")

# 映射每个 summary 的策略
strategy_labels = [cluster_map[l] for l in cluster_labels]

# ========================= 3. 构建 Agent 级时间序列 =========================
# agent_invest_history[reward][agent_id] = {round: invest}
agent_invest_history = defaultdict(lambda: defaultdict(dict))

# 从 round JSON 提取所有轮次的 investment
for reward in REWARDS:
    rounds_dir = os.path.join(DATA_ROOT, f"reward_{reward}", EXP_DIRS[reward], "expdata", "rounds")
    for rnd in range(1, 51):
        fname = os.path.join(rounds_dir, f"round_{rnd:03d}.json")
        if not os.path.exists(fname):
            continue
        with open(fname) as f:
            rd = json.load(f)
        for agent in rd.get("agents_data", []):
            agent_invest_history[reward][int(agent["agent_id"])][rnd] = \
                float(agent.get("current_round_investment", agent.get("input", 0)))

# 将策略标签也映射到每个 snapshot 的每个 agent
agent_strategy = defaultdict(lambda: defaultdict(dict))  # agent_strategy[reward][round][aid] = strategy

idx = 0
for reward, rnd, aid, inp, sc, invest in text_meta:
    agent_strategy[reward][rnd][aid] = strategy_labels[idx]
    idx += 1

# ========================= 4. Fig 4: PCA 2D 快照 (纵向排列：行=轮次，列=Reward) =========================
print("\n" + "=" * 60)
print("Generating Fig 4: PCA strategy snapshots...")

pca = PCA(n_components=2, random_state=42)
pca_coords = pca.fit_transform(tfidf_matrix.toarray())

# 为每个 (reward, round) 建立索引
coord_index = {}
idx = 0
for reward, rnd, aid, inp, sc, invest in text_meta:
    key = (reward, rnd)
    if key not in coord_index:
        coord_index[key] = []
    coord_index[key].append((pca_coords[idx], strategy_labels[idx], aid))
    idx += 1

n_rewards = len(REWARDS)
n_snapshots = len(SNAPSHOT_ROUNDS)

# 字体大小配置
FS_TICK = 12
FS_LABEL = 13
MS = 12
ALPHA = 0.55

# ✅ 翻转布局：行=轮次，列=Reward
fig4, axes = plt.subplots(n_snapshots, n_rewards, figsize=(n_rewards * 2.8, n_snapshots * 2.6))

for ri, rnd in enumerate(SNAPSHOT_ROUNDS):  # 行：轮次
    for si, reward in enumerate(REWARDS):   # 列：Reward条件
        ax = axes[ri][si] if n_snapshots > 1 else axes[si]
        key = (reward, rnd)
        if key not in coord_index:
            ax.set_visible(False)
            continue

        pts = coord_index[key]
        coords = np.array([p[0] for p in pts])
        strats = [p[1] for p in pts]

        for s_name in STRATEGY_NAMES:
            mask = [st == s_name for st in strats]
            if any(mask):
                ax.scatter(coords[mask, 0], coords[mask, 1],
                          c=STRATEGY_COLORS[s_name], s=MS, alpha=ALPHA,
                          edgecolors='none')

        # 统一坐标轴范围
        ax.set_xlim(-0.30, 0.50)
        ax.set_ylim(-0.40, 0.40)
        ax.set_xticks([-0.2, 0.0, 0.2, 0.4])
        ax.set_yticks([-0.4, -0.2, 0.0, 0.2, 0.4])

        # 保留所有子图的完整边框
        ax.spines['top'].set_visible(True)
        ax.spines['right'].set_visible(True)
        ax.spines['bottom'].set_visible(True)
        ax.spines['left'].set_visible(True)

        # ✅ 列标题 (仅第一行显示Reward)
        if ri == 0:
            ax.set_title(REWARD_LABELS[reward], fontsize=FS_LABEL, fontweight='bold', pad=6)

        # ✅ 行标签 (仅第一列显示Round)
        if si == 0:
            ax.set_ylabel(f"Round {rnd}", fontsize=FS_LABEL, fontweight='bold')

        # 坐标轴显示规则
        if si == 0:
            # 最左边一列：显示y轴刻度
            ax.tick_params(axis='y', labelsize=FS_TICK, left=True)
        else:
            # 非最左边一列：完全隐藏y轴
            ax.set_yticklabels([])
            ax.tick_params(axis='y', left=False)
            ax.set_ylabel("")

        if ri == n_snapshots - 1:
            # 最下面一行：显示x轴刻度
            ax.tick_params(axis='x', labelsize=FS_TICK, bottom=True)
        else:
            # 非最下面一行：完全隐藏x轴
            ax.set_xticklabels([])
            ax.tick_params(axis='x', bottom=False)
            ax.set_xlabel("")

# 图例配置
handles = [plt.Line2D([0], [0], marker='s', color='w',
                       markerfacecolor=STRATEGY_COLORS[s],
                       markeredgecolor=STRATEGY_COLORS[s],
                       markersize=10, label=s.capitalize() + " Strategy")
           for s in STRATEGY_NAMES]
fig4.legend(handles=handles, loc='lower center', ncol=N_STRATEGIES, fontsize=12,
            frameon=True, bbox_to_anchor=(0.5, 0.97))

# 调整子图间距
plt.subplots_adjust(left=0.10, right=0.97, top=0.93, bottom=0.08, wspace=0.08, hspace=0.12)
fig4.savefig(os.path.join(OUTPUT_DIR, "exp1_strategy_pca_snapshots.pdf"), dpi=DPI,
             bbox_inches='tight')
plt.close()
print("  → exp1_strategy_pca_snapshots.pdf")

# ========================= 5. Table 2: 策略占比 =========================
print("\n" + "=" * 60)
print("Table 2: Strategy Proportions")

print(f"\n{'Reward':<12}", end="")
for rnd in SNAPSHOT_ROUNDS:
    print(f"{'Round ' + str(rnd):>32}", end="")
print()
print(f"{'':12}", end="")
for _ in SNAPSHOT_ROUNDS:
    for s in STRATEGY_NAMES:
        print(f"  {s[:4]:>6}", end="")
print()

for reward in REWARDS:
    print(f"{REWARD_LABELS[reward]:<12}", end="")
    for rnd in SNAPSHOT_ROUNDS:
        strategies_at = agent_strategy[reward].get(rnd, {})
        total = len(strategies_at)
        if total == 0:
            for _ in STRATEGY_NAMES:
                print(f"  {'-':>6}", end="")
        else:
            for s in STRATEGY_NAMES:
                cnt = sum(1 for st in strategies_at.values() if st == s)
                pct = f"{cnt/total*100:.1f}%"
                print(f"  {pct:>6}", end="")
    print()

# 同时保存 CSV
csv_path = os.path.join(OUTPUT_DIR, "exp1_strategy_proportions.csv")
with open(csv_path, 'w') as f:
    f.write("Reward,Round,Strategy,Count,Proportion\n")
    for reward in REWARDS:
        for rnd in SNAPSHOT_ROUNDS:
            strategies_at = agent_strategy[reward].get(rnd, {})
            total = len(strategies_at)
            for s in STRATEGY_NAMES:
                cnt = sum(1 for st in strategies_at.values() if st == s)
                pct = cnt / total if total > 0 else 0
                f.write(f"{reward},{rnd},{s},{cnt},{pct:.4f}\n")
print(f"  → {csv_path}")

# ========================= 6. Fig 5: 各策略平均投入曲线 (已修改) =========================
print("\n" + "=" * 60)
print("Generating Fig 5: Average input per strategy type...")

fig5, axes5 = plt.subplots(1, n_rewards, figsize=(5* n_rewards, 4.5), sharey=True)

# ========== ✅ 全部放大字体 ==========
FS_LABEL5 = 18       # 坐标轴标签（Round / f_i）
FS_TICK5 = 16        # 刻度数字
FS_TXT5 = 20         # Reward 文字
LW5 = 2.5
MARKER_SIZE = 9

# ✅ 只在 5/15/25/35/45 显示横坐标
PLOT_ROUNDS = list(range(5, 51, 5))
SHOW_XTICKS = [5,15,25,35,45]

# 构建 agent 每轮使用的策略
agent_round_strategy = defaultdict(lambda: defaultdict(dict))
for reward in REWARDS:
    for aid in range(1, 201):
        for rnd in range(1, 51):
            nearest_snap = 5
            for sr in sorted(SNAPSHOT_ROUNDS):
                if sr <= rnd:
                    nearest_snap = sr
                else:
                    break
            strat = agent_strategy[reward].get(nearest_snap, {}).get(aid)
            if strat is not None:
                agent_round_strategy[reward][aid][rnd] = strat

# 聚合绘图
for ri, reward in enumerate(REWARDS):
    ax = axes5[ri]
    
    for s_name in STRATEGY_NAMES:
        avg_per_round = []
        for rnd in PLOT_ROUNDS:
            vals = []
            for aid in range(1, 201):
                strat = agent_round_strategy[reward].get(aid, {}).get(rnd)
                invest = agent_invest_history[reward].get(aid, {}).get(rnd)
                if strat == s_name and invest is not None:
                    vals.append(invest)
            avg_per_round.append(np.mean(vals) if vals else np.nan)
        
        ax.plot(PLOT_ROUNDS, avg_per_round, color=STRATEGY_COLORS[s_name],
                linewidth=LW5, marker='o', markersize=MARKER_SIZE,
                label=s_name.capitalize(), alpha=0.85)
    
    # Reward 标题（左上角，更大）
    ax.text(0.03, 0.97, REWARD_LABELS[reward], transform=ax.transAxes,
            fontsize=FS_TXT5, fontweight='bold', va='top', ha='left')
    
    # 坐标轴标签（放大）
    ax.set_xlabel("Round", fontsize=FS_LABEL5, fontweight='bold')
    if ri == 0:
        ax.set_ylabel(r"$f_i$", fontsize=FS_LABEL5+2, fontweight='bold')
    
    # ========== ✅ 横坐标：每10轮显示一个 ==========
    ax.set_xticks(SHOW_XTICKS)
    # ========== ✅ 纵坐标：每20显示一个 ==========
    ax.set_yticks(np.arange(0, 81, 20))
    
    # ========== ✅ 刻度数字放大 ==========
    ax.tick_params(axis='x', labelsize=FS_TICK5)
    ax.tick_params(axis='y', labelsize=FS_TICK5)
    
    ax.set_xlim(0, 52)
    ax.spines['top'].set_visible(True)
    ax.spines['right'].set_visible(True)

# 图例（放大）
handles5 = [plt.Line2D([0], [0], color=STRATEGY_COLORS[s], linewidth=LW5+1,
                        marker='o', markersize=MARKER_SIZE+1,
                        label=s.capitalize()) for s in STRATEGY_NAMES]
fig5.legend(handles=handles5, loc='upper center', ncol=N_STRATEGIES, fontsize=24,
            frameon=True, bbox_to_anchor=(0.5, 1.16))

plt.tight_layout()
fig5.savefig(os.path.join(OUTPUT_DIR, "exp1_strategy_avg_input.pdf"), dpi=DPI, bbox_inches='tight')
plt.close()
print("  → exp1_strategy_avg_input.pdf")

print("\n" + "=" * 60)
print("All outputs saved to:", OUTPUT_DIR)
print("  - Fig 4: exp1_strategy_pca_snapshots.pdf")
print("  - Table 2: exp1_strategy_proportions.csv")
print("  - Fig 5: exp1_strategy_avg_input.pdf")