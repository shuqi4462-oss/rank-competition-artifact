import time
from typing import Dict, Any, Tuple
from src.llm.client import LLMClient
from src.llm.prompts import PromptManager
from src.core.memory import MemorySystem
from src.utils.llm_parser import LLMResponseParser


class Agent:
    def __init__(self,
                agent_id: int,
                intrinsic_ability: float,
                llm_client: LLMClient,
                prompt_manager: PromptManager,
                memory_system: MemorySystem,
                config: Dict[str, Any] = None
               ):
        self.id = agent_id
        self.c = intrinsic_ability
        self.llm = llm_client
        self.prompts = prompt_manager
        self.memory = memory_system

        self.total_assets = 0.0
        self.total_investment = 0.0

        self.config = config or {}
        self.timeout_seconds = self.config.get('timeout_seconds', 120)
        self.enable_circuit_breaker = self.config.get('enable_circuit_breaker', True)
        self.circuit_breaker_threshold = self.config.get('circuit_breaker_threshold', 5)
        self.current_round_income = self.config.get('current_round_income', 100.0)
        self.failure_count = 0

    def decide_input_with_timeout(self, visible_info, timeout_seconds=None, max_parse_retries=5):
        if timeout_seconds is None:
            timeout_seconds = self.timeout_seconds

        if self.enable_circuit_breaker and self.failure_count >= self.circuit_breaker_threshold:
            print(f"Agent {self.id} 熔断状态，快速返回默认值")
            return 0.5, "熔断状态，使用默认值"

        memory_content = self.memory.summarize_recent_experience(visible_info)

        visible_info_with_finance = visible_info.copy()
        visible_info_with_finance['total_assets'] = self.total_assets
        visible_info_with_finance['total_investment'] = self.total_investment

        prompt = self.prompts.get_decision_prompt(
            agent_id=self.id,
            visible_info=visible_info_with_finance,
            memory=memory_content
        )


        # 重试循环：解析失败时重新调用 LLM
        for retry in range(max_parse_retries):
            start_time = time.time()
            response = self.llm.generate_with_timeout(prompt, timeout_seconds)
            elapsed_time = time.time() - start_time

            print(f"Agent {self.id} LLM响应时间: {elapsed_time:.2f}秒" + 
                  (f" (重试 {retry+1}/{max_parse_retries})" if retry > 0 else ""))

            try:
                input_val, reason = LLMResponseParser.parse_llm_response(response, self.id)
            except Exception as parse_err:
                print(f"⚠️ Agent {self.id} JSON解析失败 (第{retry+1}次): {parse_err}")
                if retry == max_parse_retries - 1:
                    raise  # 最后一次重试失败，抛出给上层 Environment 处理
                continue  # 重试 LLM 调用

            input_val = max(0.0, min(input_val, 100))
            self.pending_investment = input_val
            self.failure_count = 0
            return input_val, reason


    def update_memory(self, memory_data: Dict[str, Any]):
        if hasattr(self, 'pending_investment'):
            investment = self.pending_investment
            self.total_assets += (self.current_round_income - investment)
            self.total_investment += investment
            delattr(self, 'pending_investment')

        self.memory.update_memory(memory_data)

    def _generate_memory_summary(self):
        summary_text = self.memory.generate_memory_summary(self.llm, self.prompts)
        return summary_text

    def _generate_memory_summary_with_timeout(self, timeout_seconds):
        try:
            return self._generate_memory_summary()
        except Exception as e:
            print(f"⚠️ Agent {self.id} 记忆总结失败: {e}")
            return None

    def get_financial_info(self) -> Dict[str, float]:
        return {
            'total_assets': self.total_assets,
            'total_investment': self.total_investment
        }