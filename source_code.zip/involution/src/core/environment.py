import numpy as np
import yaml
import asyncio
import concurrent.futures
import signal
import time
import json
import os
import random
from typing import List, Dict, Any, Optional, Tuple
from src.utils.boltzmann import calculate_batch_performances
from src.utils.logger import ExperimentLogger


class Environment:
    def __init__(self, config_path: str, agents: List, network_manager=None,
                 experiment_type: int = 1, state_file: str = None,
                 logger_base_dir: str = "data/results"):
        with open(config_path, 'r', encoding='utf-8') as f:
            self.config = yaml.safe_load(f)

        self.agents = agents
        self.agents_dict = {agent.id: agent for agent in agents}
        self.network = network_manager
        self.experiment_type = experiment_type
        self.current_round = 0

        self.total_rounds = self.config['experiment']['total_rounds']
        self.rounds_per_block = self.config['experiment']['rounds_per_block']
        self.total_resources = self.config['resources']['total']
        self.top_percentage = self.config['resources']['top_percentage']

        boltzmann_config = self.config.get('boltzmann', {})
        self.temperature = boltzmann_config.get('temperature', 10)
        self.noise_std = boltzmann_config.get('noise_std', 2.0)

        timeout_config = self.config.get('timeout', {})
        self.decision_timeout = timeout_config.get('decision_timeout', 60.0)
        self.memory_summary_timeout = timeout_config.get('memory_summary_timeout', 120.0)
        self.max_workers = timeout_config.get('max_workers', min(10, len(agents)))

        self.max_retries = timeout_config.get('max_retries', 3)
        self.retry_delay = timeout_config.get('retry_delay', 2.0)
        self.circuit_breaker_threshold = timeout_config.get('circuit_breaker_threshold', 5)
        self.max_failed_agents = timeout_config.get('max_failed_agents', 5)

        self.enable_auto_save = self.config.get('recovery', {}).get('enable_auto_save', True)
        self.save_interval = self.config.get('recovery', {}).get('save_interval', 10)

        self.executor = concurrent.futures.ThreadPoolExecutor(
            max_workers=self.max_workers,
            thread_name_prefix="agent_worker"
        )

        self.loop = None
        self._setup_event_loop()

        self.performance_history = []
        self.input_history = []

        self.failure_counts = {agent.id: 0 for agent in agents}
        self.circuit_breaker_status = {agent.id: False for agent in agents}

        self.state_file = state_file or f"data/recovery/experiment_state_{experiment_type}.json"
        self._resume_logger_dir = None

        self._load_recovery_state()

        self.logger = ExperimentLogger(
            experiment_type=experiment_type,
            config=self.config,
            base_dir=logger_base_dir,
            resume_dir=self._resume_logger_dir
        )
        relationships = self.network.get_all_relationships() if self.network else None
        self.logger.initialize_agent_logs(self.agents, relationships)

    def _setup_event_loop(self):
        try:
            self.loop = asyncio.get_event_loop()
            if self.loop.is_closed():
                self.loop = asyncio.new_event_loop()
                asyncio.set_event_loop(self.loop)
        except RuntimeError:
            self.loop = asyncio.new_event_loop()
            asyncio.set_event_loop(self.loop)

        self.loop.set_debug(True)

        if hasattr(signal, 'SIGINT'):
            try:
                self.loop.add_signal_handler(
                    signal.SIGINT,
                    lambda: self._handle_interrupt()
                )
            except NotImplementedError:
                pass

    def _handle_interrupt(self):
        print("\n接收到中断信号，正在保存状态并清理资源...")
        self._save_recovery_state()
        self._cleanup_resources()
        raise KeyboardInterrupt

    def _cleanup_resources(self):
        if hasattr(self, 'executor') and self.executor:
            print("正在关闭线程池...")
            self.executor.shutdown(wait=False, cancel_futures=True)

    def _save_recovery_state(self):
        if not self.enable_auto_save:
            return

        try:
            os.makedirs(os.path.dirname(self.state_file), exist_ok=True)

            state = {
                'current_round': self.current_round,
                'performance_history': self.performance_history,
                'input_history': self.input_history,
                'logger_dir': getattr(self.logger, 'root_dir', None),
                'agents_state': []
            }

            for agent in self.agents:
                agent_state = {
                    'id': agent.id,
                    'total_assets': agent.total_assets,
                    'total_investment': agent.total_investment,
                    'failure_count': self.failure_counts.get(agent.id, 0),
                    'circuit_breaker': self.circuit_breaker_status.get(agent.id, False),
                    'memory': {
                        'raw_history': list(agent.memory.raw_history),
                        'latest_summary': agent.memory.latest_summary,
                        'last_published_rank': agent.memory.last_published_rank,
                        'last_published_avg_score': agent.memory.last_published_avg_score,
                        'ability_assessment': agent.memory.ability_assessment,
                        'assessment_history': agent.memory.assessment_history,
                    }
                }
                state['agents_state'].append(agent_state)

            with open(self.state_file, 'w', encoding='utf-8') as f:
                json.dump(state, f, ensure_ascii=False, indent=2)

            print(f"✓ 实验状态已保存到 {self.state_file}")
        except Exception as e:
            print(f"✗ 保存状态失败: {e}")

    def _load_recovery_state(self):
        try:
            if os.path.exists(self.state_file):
                with open(self.state_file, 'r', encoding='utf-8') as f:
                    state = json.load(f)

                self.current_round = state['current_round']
                self.performance_history = state['performance_history']
                self.input_history = state['input_history']
                self._resume_logger_dir = state.get('logger_dir')

                for agent_state in state['agents_state']:
                    agent_id = agent_state['id']
                    self.failure_counts[agent_id] = agent_state['failure_count']
                    self.circuit_breaker_status[agent_id] = agent_state['circuit_breaker']

                    agent = self.agents_dict.get(agent_id)
                    if agent:
                        agent.total_assets = agent_state['total_assets']
                        agent.total_investment = agent_state['total_investment']

                        mem_data = agent_state.get('memory', {})
                        if mem_data:
                            from collections import deque
                            agent.memory.raw_history = deque(
                                mem_data.get('raw_history', []),
                                maxlen=5
                            )
                            agent.memory.latest_summary = mem_data.get('latest_summary')
                            agent.memory.last_published_rank = mem_data.get('last_published_rank')
                            agent.memory.last_published_avg_score = mem_data.get('last_published_avg_score')
                            agent.memory.ability_assessment = mem_data.get('ability_assessment')
                            agent.memory.assessment_history = mem_data.get('assessment_history', [])

                print(f"✓ 从 {self.state_file} 恢复实验状态，当前轮次: {self.current_round}")
        except Exception as e:
            print(f"✗ 加载状态失败: {e}")

    async def _async_decide_input_with_retry(self, agent, visible_info, timeout: float = None):
        if timeout is None:
            timeout = self.decision_timeout

        if self.circuit_breaker_status.get(agent.id, False):
            print(f"⚠️ Agent {agent.id} 处于熔断状态，使用默认值")
            return 0.5, "熔断状态，使用默认值", agent.id

        # 添加随机延迟（0-3秒），分散请求避免触发API限流
        await asyncio.sleep(random.uniform(0, 3))

        for retry in range(self.max_retries):
            try:
                visible_info_with_retry = visible_info.copy()
                visible_info_with_retry['retry_count'] = retry
                visible_info_with_retry['max_retries'] = self.max_retries

                result = await asyncio.wait_for(
                    self.loop.run_in_executor(
                        self.executor,
                        lambda: agent.decide_input_with_timeout(visible_info_with_retry, timeout)
                    ),
                    timeout=timeout + 5
                )
                input_value, reason = result

                self.failure_counts[agent.id] = 0
                return input_value, reason, agent.id

            except asyncio.TimeoutError:
                print(f"⚠️ Agent {agent.id} 第{retry+1}次重试超时（{timeout}秒）")

                if retry < self.max_retries - 1:
                    await asyncio.sleep(self.retry_delay * (retry + 1))
                else:
                    print(f"⚠️ Agent {agent.id} 达到最大重试次数，使用默认值")
                    self.failure_counts[agent.id] = self.failure_counts.get(agent.id, 0) + 1
                    if self.failure_counts[agent.id] >= self.circuit_breaker_threshold:
                        self.circuit_breaker_status[agent.id] = True
                        print(f"⚠️ Agent {agent.id} 触发熔断，后续将使用默认值")
                    return 0.5, "重试失败，使用默认值", agent.id

            except Exception as e:
                print(f"⚠️ Agent {agent.id} 第{retry+1}次重试错误: {e}")

                if retry < self.max_retries - 1:
                    await asyncio.sleep(self.retry_delay * (retry + 1))
                else:
                    print(f"⚠️ Agent {agent.id} 达到最大重试次数，使用默认值")
                    self.failure_counts[agent.id] = self.failure_counts.get(agent.id, 0) + 1
                    if self.failure_counts[agent.id] >= self.circuit_breaker_threshold:
                        self.circuit_breaker_status[agent.id] = True
                        print(f"⚠️ Agent {agent.id} 触发熔断")
                    return 0.5, f"重试失败: {str(e)[:100]}", agent.id

        return 0.5, "重试失败，使用默认值", agent.id

    async def _make_default_result(self, input_val, reason, agent_id):
        return input_val, reason, agent_id

    async def _parallel_decision(self, agents):
        semaphore = asyncio.Semaphore(self.max_workers)

        async def _run_with_semaphore(agent):
            async with semaphore:
                if self.circuit_breaker_status.get(agent.id, False):
                    return 0.5, "熔断状态", agent.id
                visible_info = self._get_visible_info_for_agent(agent)
                return await self._async_decide_input_with_retry(agent, visible_info)

        tasks = [asyncio.create_task(_run_with_semaphore(agent)) for agent in agents]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        processed_results = []
        for i, result in enumerate(results):
            agent = agents[i]
            if isinstance(result, Exception):
                print(f"⚠️ Agent {agent.id} 任务失败: {result}")
                processed_results.append((0.5, f"任务失败: {result}", agent.id))
            else:
                processed_results.append(result)

        return processed_results

    async def _async_generate_memory_summary(self, agent):
        if self.circuit_breaker_status.get(agent.id, False):
            print(f"⚠️ Agent {agent.id} 熔断状态，跳过记忆总结")
            return None

        loop = asyncio.get_event_loop()
        try:
            return await asyncio.wait_for(
                loop.run_in_executor(
                    self.executor,
                    lambda: agent._generate_memory_summary_with_timeout(self.memory_summary_timeout)
                ),
                timeout=self.memory_summary_timeout + 10
            )
        except asyncio.TimeoutError:
            print(f"⚠️ Agent {agent.id} 记忆总结超时，跳过")
            return None
        except Exception as e:
            print(f"⚠️ Agent {agent.id} 记忆总结错误: {e}")
            return None

    async def _parallel_memory_summary(self):
        tasks = []
        for agent in self.agents:
            if (self.current_round + 1) % self.rounds_per_block == 0:
                tasks.append(self._async_generate_memory_summary(agent))

        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

    def run_round(self):
        try:
            if self.loop.is_closed():
                self._setup_event_loop()

            broken_agents = [aid for aid, status in self.circuit_breaker_status.items() if status]
            if broken_agents:
                print(f"⚠️ 熔断中的Agent: {broken_agents}")

            print(f"\n=== 第 {self.current_round + 1} 轮开始 ===")
            start_time = time.time()

            inputs_and_reasons = self.loop.run_until_complete(
                self._parallel_decision(self.agents)
            )

            decision_time = time.time() - start_time
            print(f"决策完成，耗时: {decision_time:.2f}秒")

            failed_count = sum(self.failure_counts.values())
            if failed_count >= self.max_failed_agents:
                print(f"\n❌ 累计失败Agent数量({failed_count})达到阈值({self.max_failed_agents})，自动中断实验")
                self._save_recovery_state()
                self._cleanup_resources()
                raise RuntimeError(f"累计失败Agent数量达到阈值: {failed_count}/{self.max_failed_agents}")

            performances = self._calculate_performances(inputs_and_reasons)
            current_relationships = self.network.get_all_relationships() if self.network else None

            self.performance_history.append(performances)
            self.input_history.append(inputs_and_reasons)

            if (self.current_round + 1) % self.rounds_per_block == 0:
                # print(f"公布第 {self.current_round // self.rounds_per_block + 1} 块排名")
                agent_public_info = self._publish_rankings()
            else:
                agent_public_info = {}

            self._update_agents_memory(performances, agent_public_info)

            # if (self.current_round + 1) % self.rounds_per_block == 0 and (self.current_round + 1) != self.total_rounds:
                # print("开始记忆总结...")
                # self.loop.run_until_complete(self._parallel_memory_summary())

            self.logger.log_round_data(
                round_number=self.current_round,
                inputs_and_reasons=inputs_and_reasons,
                performances=performances,
                current_relationships=current_relationships,
                agents=self.agents
            )

            self._show_progress()

            if self.enable_auto_save and (self.current_round + 1) % self.save_interval == 0:
                self._save_recovery_state()

            self.current_round += 1

        except KeyboardInterrupt:
            print("\n⚠️ 用户中断，正在保存状态...")
            self._save_recovery_state()
            self._cleanup_resources()
            raise
        except Exception as e:
            print(f"\n⚠️ 第 {self.current_round + 1} 轮运行异常: {e}")
            self._save_recovery_state()
            raise

    def _show_progress(self):
        progress = (self.current_round + 1) / self.total_rounds * 100
        print(f"进度: {self.current_round + 1}/{self.total_rounds} ({progress:.1f}%)")

        if hasattr(self, 'input_history') and self.input_history:
            last_inputs = self.input_history[-1]
            inputs = [i[0] for i in last_inputs]
            print(f"输入范围: {min(inputs):.3f} ~ {max(inputs):.3f}, 均值: {np.mean(inputs):.3f}")

    def _calculate_performances(self, inputs_and_reasons: List[tuple]) -> List[Dict[str, Any]]:
        boltzmann_config = {
            'boltzmann_temperature': self.temperature,
            'total_resources': self.total_resources,
            'noise_std': self.noise_std
        }
        return calculate_batch_performances(
            agents_inputs=inputs_and_reasons,
            agents_dict=self.agents_dict,
            config=boltzmann_config
        )

    def _get_visible_info_for_agent(self, agent) -> Dict[str, Any]:
        financial_info = agent.get_financial_info()
        visible_info = {
            'agent_id': agent.id,
            'current_round': self.current_round,
            'rounds_until_publication': self.rounds_per_block - (self.current_round % self.rounds_per_block),
            'total_assets': financial_info['total_assets'],
            'total_investment': financial_info['total_investment'],
            'top_percentage': self.top_percentage * 100,
        }

        if self.network is None:
            visible_info['neighbors'] = []
            return visible_info

        neighbor_ids = self.network.get_neighbor_info(agent.id)
        neighbor_info = []

        for nid in neighbor_ids:
            neighbor_agent = self.agents_dict.get(nid)
            if not neighbor_agent:
                neighbor_info.append({
                    'agent_id': nid,
                    'recent_inputs': [],
                    'recent_scores': [],
                    'latest_rank': None,
                    'avg_score': None
                })
                continue

            mem = neighbor_agent.memory
            history = list(mem.raw_history)

            neighbor_info.append({
                'agent_id': nid,
                'recent_inputs': [h['input'] for h in history if h.get('input') is not None],
                'recent_scores': [h['score'] for h in history if h.get('score') is not None],
                'latest_rank': mem.last_published_rank,
                'avg_score': mem.last_published_avg_score
            })

        visible_info['neighbors'] = neighbor_info
        return visible_info

    def _update_agents_memory(self, performances: List[Dict[str, Any]], agent_public_info: Dict):
        for agent in self.agents:
            agent_perf = next((p for p in performances if p['agent_id'] == agent.id), None)
            if not agent_perf:
                continue
            memory_data = {
                'round': self.current_round,
                'own_performance': {
                    'score': agent_perf['score'],
                    'input': agent_perf['input'],
                    'reason': agent_perf['reason']
                },
                'visible_info': self._get_visible_info_for_agent(agent),
                'public_info': agent_public_info.get(agent.id, {})
            }
            agent.update_memory(memory_data)

    def _publish_rankings(self) -> Dict[int, Dict[str, Any]]:
        avg_scores = {}

        for agent in self.agents:
            scores = [
                p['score']
                for round_data in self.performance_history
                for p in round_data
                if p['agent_id'] == agent.id
            ]
            avg_scores[agent.id] = np.mean(scores) if scores else 0

        sorted_avg = sorted(avg_scores.items(), key=lambda x: x[1], reverse=True)
        agent_public_info = {}

        for rank, (aid, agent_avg_score) in enumerate(sorted_avg, 1):
            public_info = self._prepare_public_info(aid, rank, agent_avg_score, sorted_avg)
            agent_public_info[aid] = public_info

        return agent_public_info

    def _prepare_public_info(self, agent_id: int, rank: int, agent_avg_score: float,
                             sorted_avg: list) -> Dict[str, Any]:
        info = {
            'own_rank': rank,
            'avg_score': agent_avg_score
        }

        if self.network:
            neighbor_ids = self.network.get_neighbor_info(agent_id)
            info['neighbor_ranks'] = {
                aid: {"rank": idx, "avg_score": neighbor_avg_score}
                for idx, (aid, neighbor_avg_score) in enumerate(sorted_avg, 1)
                if aid in neighbor_ids
            }

        return info

    def finalize(self):
        try:
            self.logger.finalize_experiment()
            print("实验日志已保存")
        except Exception as e:
            print(f"保存日志时出错: {e}")

        self._cleanup_resources()

        if self.loop and not self.loop.is_closed():
            self.loop.close()
            print("事件循环已关闭")

        asyncio.set_event_loop(None)