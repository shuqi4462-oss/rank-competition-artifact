from collections import deque
from typing import Dict, Any, List, Optional
from src.utils.llm_parser import LLMResponseParser


class MemorySystem:
    def __init__(self,
                 agent_id: int,
                 config: Dict[str, Any],
                 experiment_type: int
                 ):
        self.agent_id = agent_id
        self.experiment_type = experiment_type
        self.raw_history: deque[Dict[str, Any]] = deque(maxlen=5)
        self.latest_summary: Optional[str] = None
        self.last_published_rank: Optional[int] = None
        self.last_published_avg_score: Optional[float] = None

        self.ability_assessment: Optional[int] = None
        self.assessment_history: List[Dict[str, Any]] = []

    def update_memory(self, memory_data: Dict[str, Any]):
        round_id = memory_data["round"]
        perf = memory_data["own_performance"]
        public_info = memory_data.get('public_info', {})
        visible = memory_data["visible_info"]

        neighbor_dict = {}
        for n in visible.get("neighbors", []):
            nid = n['agent_id']
            neighbor_dict[nid] = {
                "recent_inputs": n.get("recent_inputs", []),
                "recent_scores": n.get("recent_scores", []),
                "latest_rank": n.get("latest_rank", None),
                "avg_score": n.get("avg_score", [])
            }

        new_rank = public_info.get("own_rank", None)
        if new_rank is not None:
            rank_to_write = new_rank
            self.last_published_rank = new_rank
        elif self.raw_history:
            rank_to_write = self.raw_history[-1].get("rank")
        else:
            rank_to_write = None

        new_avg_score = public_info.get("avg_score", None)
        if new_avg_score is not None:
            self.last_published_avg_score = new_avg_score

        self.raw_history.append({
            "round": round_id,
            "score": perf["score"],
            "input": perf["input"],
            "reason": perf["reason"],
            "rank": rank_to_write,
            "avg_score": self.last_published_avg_score,
            "neighbors": neighbor_dict,
        })

    def _extract_history_stats(self):
        last5 = list(self.raw_history)
        if not last5:
            return None

        rounds = [x["round"] for x in last5]
        scores = [x["score"] for x in last5]
        inputs = [x["input"] for x in last5]
        reasons = [x["reason"] for x in last5]

        rank_records = [x["rank"] for x in last5 if x.get("rank") is not None]
        if len(rank_records) >= 2:
            current_rank = rank_records[-1]
            previous_rank = rank_records[-2]
            rank_change = previous_rank - current_rank
            rank_change_text = (
                f"rose by {abs(rank_change)} places"
                if rank_change > 0 else
                f"dropped by {abs(rank_change)} places"
                if rank_change < 0 else
                "remained unchanged"
            )
            latest_rank_info = f"Rank {current_rank}, compared to last time it {rank_change_text}"
        elif len(rank_records) == 1:
            latest_rank_info = f"Rank {rank_records[-1]} (first time ranking available)"
        else:
            latest_rank_info = "No ranking data available"

        return {
            "last5": last5,
            "rounds": rounds,
            "scores": scores,
            "inputs": inputs,
            "reasons": reasons,
            "latest_rank_info": latest_rank_info,
        }

    def generate_memory_summary(self, llm_client, prompt_manager) -> str:
        summary_data = self.get_summary_data()
        prompt = prompt_manager.get_memory_summary_prompt(
            agent_id=self.agent_id,
            memory_content=str(summary_data)
        )

        summary_response = llm_client.generate(prompt)

        ability_assessment, memory_summary_text = LLMResponseParser.parse_memory_summary_response(summary_response)

        if ability_assessment is not None:
            self.ability_assessment = ability_assessment
            self.assessment_history.append({
                "round": self.raw_history[-1]["round"] if self.raw_history else 0,
                "ability_level": ability_assessment,
                "sequence": len(self.assessment_history) + 1
            })

        if memory_summary_text:
            self.latest_summary = memory_summary_text.strip()
        else:
            self.latest_summary = summary_response.strip()

        return self.latest_summary

    def get_summary_data(self) -> Dict[str, Any]:
        stats = self._extract_history_stats()
        if stats is None:
            return {"Summary Range": "No data available"}

        neighbor_summary = ""
        if stats["last5"] and stats["last5"][-1].get("neighbors"):
            neighbors = stats["last5"][-1]["neighbors"]
            lines = []

            for nid, data in neighbors.items():
                lines.append(
                    f"Neighbor investor {nid}: "
                    f"scores {data.get('recent_scores', [])}, "
                    f"investments {data.get('recent_inputs', [])}, "
                    f"latest rank {data.get('latest_rank')}, "
                    f"average score {data.get('avg_score', [])}"
                )
            neighbor_summary = "\n".join(lines)
        else:
            neighbor_summary = "No available neighbor investor information"

        ability_info = f"Current self-assessed ability level: {self.ability_assessment}/5" if self.ability_assessment else "No ability assessment available"

        return {
            "Summary Round Range": f"{stats['rounds'][0] + 1} to {stats['rounds'][-1] + 1}",
            "Recent Scores": stats["scores"],
            "Recent Investment Amounts": stats["inputs"],
            "Reasons for Each Action": stats["reasons"],
            "Ranking Change": stats["latest_rank_info"],
            "Own Average Score": self.last_published_avg_score if self.last_published_avg_score else "Not available",
            "Ability Assessment": ability_info,
            "Neighbor Investor Information": neighbor_summary,
        }

    def summarize_recent_experience(self, visible_info: Dict[str, Any]) -> str:
        stats = self._extract_history_stats()

        if stats is None:
            scores, inputs = [], []
            self_latest_rank = "No ranking data"
        else:
            scores = stats["scores"]
            inputs = stats["inputs"]
            rank_records = [x["rank"] for x in stats["last5"] if x.get("rank") is not None]
            self_latest_rank = rank_records[-1] if rank_records else "No ranking data"

        self_avg_score = self.last_published_avg_score if self.last_published_avg_score else "Not available"

        neigh_blocks = []
        neighbors = visible_info.get("neighbors", [])
        for neighbor in neighbors:
            nid = neighbor.get("agent_id")
            recent_inputs = neighbor.get("recent_inputs", [])
            recent_scores = neighbor.get("recent_scores", [])
            neigh_latest_rank = neighbor.get("latest_rank", "N/A")
            neigh_avg_score = neighbor.get("avg_score", "Not available")

            inputs_str = str(recent_inputs) if recent_inputs else "N/A"
            scores_str = str(recent_scores) if recent_scores else "N/A"
            avg_score_str = str(neigh_avg_score) if neigh_avg_score else "N/A"

            neigh_blocks.append(
                f"Neighbor investor {nid}: "
                f"last {len(recent_scores)} rounds scores = {scores_str}, "
                f"investments = {inputs_str}, "
                f"average score = {avg_score_str}, "
                f"latest rank = {neigh_latest_rank}"
            )

        summary_text = self.latest_summary or "No summary available"

        summary_parts = [
            f"Your performance in the last {len(scores)} rounds:",
            f"    Scores: {scores}",
            f"    Investment amounts: {inputs}",
            f"    Average score: {self_avg_score}",
            f"    Your most recently published rank: {self_latest_rank}",
            f"",
        ]

        if self.ability_assessment is not None:
            summary_parts.extend([
                f"Your current self-assessed ability level: {self.ability_assessment}/5",
                f""
            ])

        if neigh_blocks:
            neighbor_section = "\n    ".join(neigh_blocks)
            summary_parts.extend([
                f"Visible neighboring investors' performance:",
                f"    {neighbor_section}",
                f""
            ])

        summary_parts.extend([
            f"Your recent reflection:",
            f"    {summary_text}"
        ])

        summary = "\n".join(summary_parts).strip()
        return summary

    def get_ability_assessment(self) -> Dict[str, Any]:
        return {
            "ability_level": self.ability_assessment,
            "assessment_history": self.assessment_history
        }