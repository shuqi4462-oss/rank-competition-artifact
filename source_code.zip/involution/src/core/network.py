"""
NetworkManager
------------------------------------------
负责构建与管理智能体之间的社交网络结构。

支持：
- small_world
- random
- hybrid（Scale-Free + Small-World + AvgDegree=4 + No Isolated Node + Ability-Degree Mapping）
- none（无网络）
------------------------------------------
"""

import networkx as nx
import json
from pathlib import Path
from typing import List, Dict, Any, Optional
import numpy as np
import random


class NetworkManager:
    def __init__(self,
                 config: Dict[str, Any],
                 network_type: str = "none",
                 agent_ids: List[int] = None,
                 personality_path: Optional[str] = None):

        self.config = config
        self.network_type = network_type
        self.agent_ids = agent_ids if agent_ids else []
        if not self.agent_ids:
            raise ValueError("必须提供 agent_ids")

        self.graph = nx.Graph()

        # ----------------------------------------------------
        # hybrid 需要 intrinsic_ability
        # ----------------------------------------------------
        self.intrinsic_abilities = {}
        if network_type == "hybrid":
            if not personality_path:
                raise ValueError("hybrid 网络需要提供 personality_path")
            self.intrinsic_abilities = self._load_abilities(personality_path)

        # ----------------------------------------------------
        # 初始化网络
        # ----------------------------------------------------
        if network_type == "small_world":
            self._init_small_world_network()
        elif network_type == "random":
            self._init_random_network()
        elif network_type == "hybrid":
            self._init_hybrid_network()
        else:
            # none
            self.graph.add_nodes_from(self.agent_ids)

    # ============================================================
    # 加载 intrinsic_ability
    # ============================================================
    def _load_abilities(self, path: str) -> Dict[int, float]:
        try:
            with open(Path(path), "r", encoding="utf-8") as f:
                data = json.load(f)
            return {item["id"]: item["intrinsic_ability"] for item in data}
        except Exception as e:
            raise ValueError(f"加载能力文件失败: {e}")

    # ============================================================
    # small-world 网络
    # ============================================================
    def _init_small_world_network(self):
        n = len(self.agent_ids)
        k = self.config.get("k_neighbors", 4)
        p = self.config.get("rewire_prob", 0.2)

        g = nx.watts_strogatz_graph(n, k, p)
        mapping = {i: self.agent_ids[i] for i in range(n)}
        self.graph = nx.relabel_nodes(g, mapping)

        self._cap_degree()

    # ============================================================
    # random 网络
    # ============================================================
    def _init_random_network(self):
        n = len(self.agent_ids)
        p = self.config.get("connection_prob", 0.08)

        g = nx.erdos_renyi_graph(n, p)
        mapping = {i: self.agent_ids[i] for i in range(n)}
        self.graph = nx.relabel_nodes(g, mapping)

        self._cap_degree()

    # ============================================================
    # 新版 Hybrid 网络（完全满足 Scale-Free + Small-World + AvgDegree=4）
    # ============================================================
    def _init_hybrid_network(self):
        """
        新 Hybrid 模型：
        1. 使用 Holme-Kim (HK) 模型产生 Scale-Free + 高聚类（小世界）结构
        2. 精确调整平均度为 4：总边数 = 2N
        3. 保证无孤立节点（degree >= 1）
        4. Ability 越低 → 映射到度数越高的节点
        """

        n = len(self.agent_ids)
        target_avg_degree = 4
        target_edges = 2 * n
        max_deg = 8
        min_deg = 1

        # ------------------------------------------------------------
        # 1) 生成 Holme–Kim 小世界无标度网络
        # ------------------------------------------------------------
        temp_graph = nx.powerlaw_cluster_graph(
            n=n,
            m=2,      # 控制平均度 ≈ 4
            p=0.3     # 增强聚类系数（小世界特性）
        )

        # ------------------------------------------------------------
        # 2) 精确调整平均度 = 4（总边数 = 2N）
        # ------------------------------------------------------------
        def safe_remove_edge():
            """安全删边：删后两端度数不能 < min_deg"""
            edges = list(temp_graph.edges())
            if not edges:
                return
            u, v = random.choice(edges)
            if temp_graph.degree(u) > min_deg and temp_graph.degree(v) > min_deg:
                temp_graph.remove_edge(u, v)

        def safe_add_edge():
            """安全加边：两端度数不能超过 max_deg 且不能已有边"""
            tries = 0
            while tries < 1000:
                u = random.randint(0, n - 1)
                v = random.randint(0, n - 1)
                tries += 1
                if u != v and not temp_graph.has_edge(u, v):
                    if temp_graph.degree(u) < max_deg and temp_graph.degree(v) < max_deg:
                        temp_graph.add_edge(u, v)
                        return

        # 调整边数
        loop = 0
        while temp_graph.number_of_edges() != target_edges and loop < 8000:
            loop += 1
            m_edges = temp_graph.number_of_edges()

            if m_edges > target_edges:
                safe_remove_edge()
            elif m_edges < target_edges:
                safe_add_edge()

        # ------------------------------------------------------------
        # 3) 保证无孤立节点（若出现则强制连边）
        # ------------------------------------------------------------
        for node in temp_graph.nodes():
            if temp_graph.degree(node) < min_deg:
                candidates = [x for x in temp_graph.nodes()
                              if x != node
                              and not temp_graph.has_edge(node, x)]
                if candidates:
                    target = random.choice(candidates)
                    temp_graph.add_edge(node, target)

        # ------------------------------------------------------------
        # 4) ability → degree 映射（能力低 → 度高）
        # ------------------------------------------------------------
        # (1) agent 按 ability 从低到高排序（低能力 → 度高）
        sorted_agents = sorted(
            self.agent_ids,
            key=lambda aid: self.intrinsic_abilities.get(aid, 0.0)
        )

        # (2) 节点按度从高到低排序
        sorted_nodes = sorted(
            temp_graph.nodes(),
            key=lambda x: temp_graph.degree(x),
            reverse=True
        )

        # (3) 映射
        mapping = {}
        for i in range(n):
            mapping[sorted_nodes[i]] = sorted_agents[i]

        # (4) 重命名节点
        self.graph = nx.relabel_nodes(temp_graph, mapping)

    # ============================================================
    # 限制度：确保 degree ∈ [min_degree, max_degree] (通用辅助)
    # ============================================================
    def _cap_degree(self, min_degree=1, max_degree=8):
        # 1) 剪掉超过 max_degree 的边
        for node in self.graph.nodes():
            while self.graph.degree(node) > max_degree:
                neighbors = list(self.graph.neighbors(node))
                if not neighbors: break
                rem = np.random.choice(neighbors)
                self.graph.remove_edge(node, rem)

        # 2) 补不足 min_degree 的边
        for node in self.graph.nodes():
            while self.graph.degree(node) < min_degree:
                candidates = [
                    x for x in self.agent_ids
                    if x != node and not self.graph.has_edge(node, x)
                ]
                if not candidates:
                    break
                new_n = np.random.choice(candidates)
                self.graph.add_edge(node, new_n)

    # ============================================================
    # API
    # ============================================================
    def get_neighbor_info(self, agent_id: int) -> List[int]:
        if agent_id in self.graph:
            return list(self.graph.neighbors(agent_id))
        return []

    def get_all_connections(self) -> List[tuple]:
        return list(self.graph.edges())

    def get_all_relationships(self) -> Dict[int, List[int]]:
        return {n: list(self.graph.neighbors(n)) for n in self.graph.nodes()}
