import os
import json
from datetime import datetime
from typing import Dict, List, Any
import yaml
import numpy as np


class ExperimentLogger:
    def __init__(self, experiment_type: int, config: Dict[str, Any], base_dir: str = "data/results",
                 resume_dir: str = None):
        """
        日志系统初始化（按新目录结构）
        
        Args:
            experiment_type: 实验类型 (1,2)
            config: 实验配置字典
            base_dir: 基础输出目录
            resume_dir: 续跑的已存在目录（如果提供则复用，不再创建新时间戳目录）
        """
        self.experiment_type = experiment_type
        self.config = config or {}

        if resume_dir and os.path.exists(resume_dir):
            self.root_dir = resume_dir
        else:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            self.root_dir = os.path.join(base_dir, f"exp{experiment_type}_{timestamp}")
        self.experiment_dir = os.path.join(self.root_dir, "expdata")
        
        # 创建目录
        os.makedirs(self.root_dir, exist_ok=True)
        os.makedirs(self.experiment_dir, exist_ok=True)
        
        # 轮次结果子目录
        self.rounds_dir = os.path.join(self.experiment_dir, "rounds")
        os.makedirs(self.rounds_dir, exist_ok=True)

        # 内存结构
        self.agent_logs: Dict[int, Dict[str, Any]] = {}
        self.round_statistics = []  # 每轮系统统计数据

        # 保存配置文件到expdata目录
        self._save_experiment_config()

    def _save_experiment_config(self):
        """保存实验配置到expdata/experiment_config.yaml"""
        try:
            cfg_path = os.path.join(self.experiment_dir, "experiment_config.yaml")
            with open(cfg_path, "w", encoding="utf-8") as f:
                yaml.safe_dump(self.config, f, allow_unicode=True, sort_keys=False)
        except Exception as e:
            print(f"[ExperimentLogger] 保存配置失败: {e}")

    def initialize_agent_logs(self, agents: List[Any], network_relationships: Dict[int, List[int]] = None):
        """初始化智能体基础日志（保留人格信息，可选）"""
        if network_relationships is None:
            network_relationships = {}

        for agent in agents:
            aid = int(agent.id)
            # 初始化时记录初始财务状态
            financial_info = agent.get_financial_info()
            self.agent_logs[aid] = {
                "agent_id": aid,
                "intrinsic_ability": getattr(agent, "c", None),
                "initial_relationships": network_relationships.get(aid, []),
                "initial_total_assets": financial_info['total_assets'],  # 初始总资产
                "initial_total_investment": financial_info['total_investment'],  # 初始总投资
                "round_history": [],
                "ability_assessment_history": []  # 新增：能力评估历史
            }

    def log_round_data(self, round_number: int, inputs_and_reasons: List[tuple],
                       performances: List[Dict[str, Any]],
                       current_relationships: Dict[int, List[int]] = None,
                       agents: List[Any] = None):
        """
        记录单轮详细数据（包含增强字段）
        
        Args:
            round_number: 当前轮次（0-based）
            inputs_and_reasons: (effort, reason, agent_id)列表
            performances: 智能体成绩列表
            current_relationships: 当前网络关系
            agents: 智能体实例列表
        """
        if agents is None:
            agents = []
        if current_relationships is None:
            current_relationships = {}

        round_index = round_number + 1  # 1-based编号
        round_log = {
            "round": round_index,
            "timestamp": datetime.now().isoformat(),
            "agents_data": [],
            "system_stats": {}  # 本轮系统统计
        }

        # 提取本轮所有effort和score用于系统统计
        current_inputs = []
        current_scores = []

        # 处理每个智能体数据
        for (input, reason, agent_id) in inputs_and_reasons:
            aid = int(agent_id)
            perf = next((p for p in performances if int(p.get("agent_id")) == aid), {})
            agent_obj = next((a for a in agents if int(a.id) == aid), None)

            # 获取财务信息
            financial_info = agent_obj.get_financial_info() if agent_obj else {
                'total_assets': 0.0,
                'total_investment': 0.0
            }

            # 获取能力评估信息（新增）
            ability_assessment = None
            if agent_obj and hasattr(agent_obj, 'memory'):
                ability_assessment = getattr(agent_obj.memory, 'ability_assessment', None)
                
                # 记录能力评估历史（新增）
                if ability_assessment is not None and aid in self.agent_logs:
                    self.agent_logs[aid]["ability_assessment_history"].append({
                        "round": round_index,
                        "ability_level": ability_assessment,
                        "timestamp": datetime.now().isoformat()
                    })

            # 基础信息
            agent_entry = {
                "agent_id": aid,
                "input": input,
                "reason": reason,
                "score": perf.get("score", 0),
                # 财务状态
                "total_assets": round(financial_info['total_assets'], 2),
                "total_investment": round(financial_info['total_investment'], 2),
                "current_round_investment": input,
                # 原有字段
                "rank": getattr(agent_obj.memory, "last_published_rank", None) if (agent_obj and hasattr(agent_obj, "memory")) else None,
                "avg_score": getattr(agent_obj.memory, "last_published_avg_score", None) if (agent_obj and hasattr(agent_obj, "memory")) else None,
                # 新增：能力评估字段
                "ability_assessment": ability_assessment,
                "calculation_details": perf.get("calculation_details", {}),
                "memory_summary": getattr(agent_obj.memory, "latest_summary", None) if (agent_obj and hasattr(agent_obj, "memory")) else None,
                "neighbors_info": []  # 实验2的邻居信息
            }

            # 实验3（网络实验）补充邻居详细信息
            if self.experiment_type == 3:
                neighbor_ids = current_relationships.get(aid, [])
                for nid in neighbor_ids:
                    n_agent = next((a for a in agents if int(a.id) == nid), None)
                    n_perf = next((p for p in performances if int(p.get("agent_id")) == nid), {})
                    
                    neighbor_entry = {
                        "agent_id": nid,
                        "input": next((e for e, _, aid in inputs_and_reasons if int(aid) == nid), None),
                        "score": n_perf.get("score", 0),
                        "avg_score": getattr(n_agent.memory, "last_published_avg_score", None) if (n_agent and hasattr(n_agent, "memory")) else None,
                        "rank": getattr(n_agent.memory, "last_published_rank", None) if (n_agent and hasattr(n_agent, "memory")) else None,
                    }
                    agent_entry["neighbors_info"].append(neighbor_entry)

            round_log["agents_data"].append(agent_entry)
            current_inputs.append(input)
            current_scores.append(agent_entry["score"])

            # 更新内存中的round_history
            if aid in self.agent_logs:
                self.agent_logs[aid]["round_history"].append({
                    "round": round_index,
                    "total_assets": round(financial_info['total_assets'],1),
                    "total_investment": round(financial_info['total_investment'], 1),
                    "input": input,
                    "score": perf.get("score", 0),
                    "ability_assessment": ability_assessment  # 新增：记录能力评估
                })

        # 计算本轮系统统计
        avg_input = np.mean(current_inputs) if current_inputs else 0
        avg_score = np.mean(current_scores) if current_scores else 0
        input_cv = (np.std(current_inputs) / avg_input) if avg_input != 0 else 0  # 变异系数
        total_assets_list = [agent["total_assets"] for agent in round_log["agents_data"]]
        total_investment_list = [agent["total_investment"] for agent in round_log["agents_data"]]
        avg_total_assets = np.mean(total_assets_list) if total_assets_list else 0
        avg_total_investment = np.mean(total_investment_list) if total_investment_list else 0

        lying_flat_count = sum(1 for x in current_inputs if x < 0.01)
        lying_flat_ratio = lying_flat_count / len(current_inputs) if current_inputs else 0

        round_log["system_stats"] = {
            "avg_score": round(avg_score, 2),
            "avg_input": round(avg_input, 2),
            "input_cv": round(input_cv, 4),
            "lying_flat_ratio": round(lying_flat_ratio, 4),
            "avg_total_assets": round(avg_total_assets, 2),
            "avg_total_investment": round(avg_total_investment, 2),
        }
        self.round_statistics.append(round_log["system_stats"])

        # 保存轮次文件
        try:
            round_file = os.path.join(self.rounds_dir, f"round_{round_index:03d}.json")
            with open(round_file, "w", encoding="utf-8") as rf:
                json.dump(round_log, rf, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"[ExperimentLogger] 保存轮次{round_index}失败: {e}")

    def finalize_experiment(self):
        """生成实验汇总文件"""
        # 构建汇总数据
        summary = {
            "experiment_type": self.experiment_type,
            "total_rounds": len(self.round_statistics),
            "completion_time": datetime.now().isoformat(),
            "round_statistics": self.round_statistics,
            "final_summary": {
                "overall_avg_score": round(np.mean([s["avg_score"] for s in self.round_statistics]), 2) if self.round_statistics else 0,
                "overall_avg_input": round(np.mean([s["avg_input"] for s in self.round_statistics]), 2) if self.round_statistics else 0,
                "overall_input_cv": round(np.mean([s["input_cv"] for s in self.round_statistics]), 4) if self.round_statistics else 0,
                "overall_lying_flat_ratio": round(np.mean([s["lying_flat_ratio"] for s in self.round_statistics]), 4) if self.round_statistics else 0,
                "overall_avg_total_assets": round(np.mean([s["avg_total_assets"] for s in self.round_statistics]), 2) if self.round_statistics else 0,
                "overall_avg_total_investment": round(np.mean([s["avg_total_investment"] for s in self.round_statistics]), 2) if self.round_statistics else 0
            },
            # 各智能体最终状态
            "agent_final_status": [
                {
                    "agent_id": aid,
                    "intrinsic_ability": data["intrinsic_ability"],
                    "initial_total_assets": data["initial_total_assets"],
                    "final_total_assets": data["round_history"][-1]["total_assets"] if data["round_history"] else data["initial_total_assets"],
                    "total_investment": data["round_history"][-1]["total_investment"] if data["round_history"] else data["initial_total_investment"],
                    "final_ability_assessment": data["round_history"][-1]["ability_assessment"] if data["round_history"] and "ability_assessment" in data["round_history"][-1] else None,
                    "ability_assessment_count": len(data["ability_assessment_history"])
                }
                for aid, data in self.agent_logs.items()
            ]
        }

        # 保存汇总文件
        try:
            summary_file = os.path.join(self.experiment_dir, "experiment_summary.json")
            with open(summary_file, "w", encoding="utf-8") as sf:
                json.dump(summary, sf, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"[ExperimentLogger] 保存汇总失败: {e}")

        # 保存能力评估历史文件（新增）
        self._save_ability_assessment_history()

        # 打印目录信息
        print(f"\n[ExperimentLogger] 实验数据已保存至: {self.root_dir}")
        print(f"  - 配置文件: {os.path.join(self.experiment_dir, 'experiment_config.yaml')}")
        print(f"  - 轮次数据: {self.rounds_dir}")
        print(f"  - 实验汇总: {os.path.join(self.experiment_dir, 'experiment_summary.json')}")

    def _save_ability_assessment_history(self):
        """保存能力评估历史到单独文件（新增）"""
        try:
            assessment_data = {}
            for aid, data in self.agent_logs.items():
                if data.get("ability_assessment_history"):
                    assessment_data[aid] = data["ability_assessment_history"]
            
            if assessment_data:
                assessment_file = os.path.join(self.experiment_dir, "ability_assessment_history.json")
                with open(assessment_file, "w", encoding="utf-8") as af:
                    json.dump(assessment_data, af, ensure_ascii=False, indent=2)
                print(f"  - 能力评估历史: {assessment_file}")
        except Exception as e:
            print(f"[ExperimentLogger] 保存能力评估历史失败: {e}")