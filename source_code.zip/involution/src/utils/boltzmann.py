"""
玻尔兹曼分布成绩计算工具

"""
import numpy as np
from typing import List, Dict, Any, Optional


def calculate_score_arrays(
    investments,
    abilities,
    temperature: float = 20.0,
    total_resources: float = 20000.0,
    noise_std: float = 5.0,
    rng: Optional[np.random.Generator] = None,
):
    investments = np.asarray(investments, dtype=float)
    abilities = np.asarray(abilities, dtype=float)

    if investments.shape != abilities.shape:
        raise ValueError("investments and abilities must have the same shape")

    if temperature <= 0:
        raise ValueError("temperature must be > 0")

    # Paper Eq.(1):
    # logit_i = c_i * o_i / kappa
    logits = abilities * investments / temperature

    # numerical stability
    shifted_logits = logits - np.max(logits)
    weights = np.exp(shifted_logits)
    shares = weights / np.sum(weights)

    deterministic_scores = total_resources * shares

    if rng is None:
        noise = np.random.normal(0.0, noise_std, len(investments))
    else:
        noise = rng.normal(0.0, noise_std, len(investments))

    scores = deterministic_scores + noise
    scores = np.maximum(scores, 0.0)

    return scores, logits, weights, shares, noise


def calculate_global_boltzmann_scores(
    inputs_and_reasons: list,
    agents_dict: dict,
    temperature: float = 20.0,
    total_resources: float = 20000.0,
    noise_std: float = 5.0,
    rng: Optional[np.random.Generator] = None,
) -> List[Dict[str, Any]]:

    inputs = np.array(
        [x[0] for x in inputs_and_reasons],
        dtype=float,
    )

    agent_ids = [x[2] for x in inputs_and_reasons]

    abilities = np.array(
        [agents_dict[aid].c for aid in agent_ids],
        dtype=float,
    )

    scores, logits, weights, shares, noise = calculate_score_arrays(
        investments=inputs,
        abilities=abilities,
        temperature=temperature,
        total_resources=total_resources,
        noise_std=noise_std,
        rng=rng,
    )

    performances = []

    for i, (input_val, reason, agent_id) in enumerate(inputs_and_reasons):
        performances.append({
            "agent_id": agent_id,
            "score": round(float(scores[i]), 1),
            "input": float(input_val),
            "reason": reason,
            "calculation_details": {
                "intrinsic_ability": round(float(abilities[i]), 6),
                "ability_investment_logit": round(float(logits[i]), 6),
                "boltzmann_weight": round(float(weights[i]), 6),
                "resource_allocation": round(
                    float(shares[i] * total_resources), 6
                ),
                "resource_allocation_ratio": round(
                    float(shares[i] * 100.0), 6
                ),
                "luck_factor": round(float(noise[i]), 6),
            }
        })

    return performances


def calculate_batch_performances(
    agents_inputs: list,
    agents_dict: dict,
    config: dict,
    rng: Optional[np.random.Generator] = None,
):
    temperature = config.get(
        "boltzmann_temperature",
        config.get("boltzmann", {}).get("temperature", 20),
    )

    noise_std = config.get(
        "noise_std",
        config.get("boltzmann", {}).get("noise_std", 5.0),
    )

    total_resources = config.get(
        "total_resources",
        config.get("resources", {}).get("total", 20000),
    )

    return calculate_global_boltzmann_scores(
        inputs_and_reasons=agents_inputs,
        agents_dict=agents_dict,
        temperature=temperature,
        total_resources=total_resources,
        noise_std=noise_std,
        rng=rng,
    )