"""工具模块，包含日志、玻尔兹曼计算和初始化功能"""
from .logger import ExperimentLogger
from .boltzmann import calculate_global_boltzmann_scores, calculate_batch_performances
from .initialization import initialize_agents, generate_intrinsic_ability
from .llm_parser import LLMResponseParser

try:
    from .visualization import (
        load_round_data,
        visualize_multiple_experiments,
        visualize_single_ratio_line,
        visualize_avg_score_histogram,
        visualize_zero_input_counts,
        visualize_ability_assessment_accuracy,
        generate_comparison_plots,
    )
    _has_visualization = True
except ImportError:
    _has_visualization = False
    load_round_data = None
    visualize_multiple_experiments = None
    visualize_single_ratio_line = None
    visualize_avg_score_histogram = None
    visualize_zero_input_counts = None
    visualize_ability_assessment_accuracy = None
    generate_comparison_plots = None

__all__ = [
    "ExperimentLogger",
    "calculate_global_boltzmann_scores",
    "calculate_batch_performances",
    "initialize_agents",
    "generate_intrinsic_ability",
    "LLMResponseParser",
    "load_round_data",
    "visualize_multiple_experiments",
    "visualize_single_ratio_line",
    "visualize_avg_score_histogram",
    "visualize_zero_input_counts",
    "visualize_ability_assessment_accuracy",
    "generate_comparison_plots",
]