import yaml
import json
import numpy as np
import os

def initialize_agents(config_path: str = "config\\default.yaml", output_path: str = "data/personality_profiles.json"):
    """
    初始化智能体数据（仅保留ID和内在禀赋）并保存到JSON文件
    新增：批量生成后进行均值校准，保证整体均值接近目标值
    """
    # 加载配置文件
    with open(config_path, 'r', encoding='utf-8') as file:
        config = yaml.safe_load(file)
    
    agent_config = config['agent_params']
    agent_count = agent_config['count']
    ability_config = agent_config['intrinsic_ability']
    target_mean = ability_config.get('target_mean', 0.5)  # 目标均值
    clip_min, clip_max = ability_config['clip_range']
    
    # 第一步：批量生成未校准的内在禀赋原始值
    raw_abilities = []
    for _ in range(agent_count):
        raw_ability = generate_intrinsic_ability(agent_config)
        raw_abilities.append(raw_ability)
    
    # 第二步：均值校准（核心步骤）
    raw_mean = np.mean(raw_abilities)
    offset = target_mean - raw_mean  # 计算偏移量：目标均值 - 原始均值
    calibrated_abilities = [ability + offset for ability in raw_abilities]
    
    # 第三步：二次裁剪（校准后可能超出范围，兜底处理）
    final_abilities = []
    for ability in calibrated_abilities:
        clipped = max(clip_min, min(clip_max, ability))
        final_abilities.append(round(clipped, 3))  # 保留3位小数
    
    # 生成智能体数据
    agents = []
    for agent_id, ability in enumerate(final_abilities, start=1):
        agent = {
            "id": agent_id,
            "intrinsic_ability": ability
        }
        agents.append(agent)
    
    # 保存到JSON文件
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, 'w', encoding='utf-8') as file:
        json.dump(agents, file, indent=2, ensure_ascii=False)
    
    # 打印验证信息
    abilities = [a['intrinsic_ability'] for a in agents]
    print(f"生成{agent_count}个智能体，内在禀赋均值：{np.mean(abilities):.4f}（目标均值：{target_mean}）")
    print(f"内在禀赋最小值：{np.min(abilities):.4f}，最大值：{np.max(abilities):.4f}")
    print(f"内在禀赋中位数：{np.median(abilities):.4f}")
    
    return agents

def generate_intrinsic_ability(config: dict) -> float:
    """
    生成内在禀赋值（支持正态分布/指数分布，指数分布实现小值少、大值多）
    输出：未校准的原始值
    """
    ability_config = config['intrinsic_ability']
    dist_type = ability_config.get('dist_type')
    min_val, max_val = ability_config['clip_range']

    if dist_type == 'normal':
        # 原正态分布逻辑
        value = np.random.normal(ability_config['mean'], ability_config['std'])
    
    elif dist_type == 'exponential':
        # 指数分布逻辑：实现小值少、大值多，且范围与原正态分布匹配
        scale = ability_config.get('scale', 3.0)
        truncate_max = ability_config.get('truncate_max', 9.0)
        target_3sigma_min, target_3sigma_max = ability_config.get('target_3sigma_range', [-8.5, 9.5])
        
        # 1. 生成指数分布随机数（均值=scale）
        x = np.random.exponential(scale=scale)
        
        # 2. 截断到最大值（避免数值过大，对应正态分布3σ）
        x_truncated = min(x, truncate_max)
        
        # 3. 归一化到[0, 1]区间
        x_norm = x_truncated / truncate_max
        
        # 4. 反转：实现小值少、大值多（原指数分布小值多，反转后小值少）
        x_rev = 1 - x_norm
        
        # 5. 缩放平移到目标3σ范围（[-8.5, 9.5]）
        range_width = target_3sigma_max - target_3sigma_min
        value = target_3sigma_min + x_rev * range_width
        
    else:
        raise ValueError(f"不支持的分布类型：{dist_type}，仅支持normal/exponential")

    # 初次裁剪（原始值裁剪，校准后会二次裁剪）
    clipped_value = max(min_val, min(max_val, value))
    return float(clipped_value)  # 暂不保留小数，校准后统一处理
