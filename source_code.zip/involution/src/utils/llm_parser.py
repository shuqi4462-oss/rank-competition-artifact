import json
import re
import ast
from typing import Optional, Dict, Any, Tuple

class LLMResponseParser:
    # =======================
    # Cleaning & Extraction
    # =======================

    @staticmethod
    def clean_response_text(response: str) -> str:
        """清理 LLM 返回的原始文本，去除 Markdown 和常见前缀"""
        if not response:
            return ""
        text = response.strip()

        # 去掉常见前缀
        prefixes = [
            r'^\s*JSON\s*[:\-]\s*',
            r'^\s*Response\s*[:\-]\s*',
            r'^\s*输出\s*[:\-]\s*',
            r'^\s*Answer\s*[:\-]\s*',
            r'^\s*Result\s*[:\-]\s*',
        ]
        for p in prefixes:
            text = re.sub(p, '', text, flags=re.IGNORECASE)

        # 去掉 ```json ... ``` 包裹
        text = re.sub(r'```(?:json)?\s*', '', text, flags=re.IGNORECASE)
        text = re.sub(r'```$', '', text)

        # 去掉 HTML 标签
        text = re.sub(r'</?(pre|code)>', '', text, flags=re.IGNORECASE)

        # 统一中文标点 / 引号
        text = text.replace('“', '"').replace('”', '"')
        text = text.replace('‘', "'").replace('’', "'")
        text = text.replace('，', ',').replace('：', ':').replace('；', ';')

        # 去掉不可见控制字符 (注意：这里不包含 \n, \r, \t 等，因为它们需要被转义而不是直接删除)
        text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]', '', text)
        return text.strip()

    @staticmethod
    def _find_balanced_block(text: str, start: int) -> Optional[str]:
        """寻找平衡的大括号块 {...} 或 [...]"""
        opening = text[start]
        closing = '}' if opening == '{' else ']'
        depth = 0
        in_str = False
        esc = False
        quote = None

        for i in range(start, len(text)):
            ch = text[i]
            if esc:
                esc = False
                continue
            if ch == '\\':
                esc = True
                continue
            if in_str:
                # 如果在字符串内，只关心对应的结束引号
                if ch == quote:
                    in_str = False
            else:
                if ch in ('"', "'"):
                    in_str = True
                    quote = ch
                elif ch == opening:
                    depth += 1
                elif ch == closing:
                    depth -= 1
                    if depth == 0:
                        return text[start:i + 1]
        return None

    @staticmethod
    def extract_json_from_text(text: str) -> Optional[str]:
        """从文本中提取第一个看起来像 JSON 对象或数组的块"""
        for m in re.finditer(r'[\{\[]', text):
            block = LLMResponseParser._find_balanced_block(text, m.start())
            if block:
                return block
        return None

    # =======================
    # JSON 修复 (核心修复逻辑)
    # =======================

    @staticmethod
    def repair_json_format(text: str) -> str:
        """
        尝试修复损坏的 JSON 字符串。
        能够处理：注释、Key 无引号、尾部逗号、Value 中未转义的引号/控制字符。
        """
        s = text.strip()

        # 1. 去除 C 风格注释 // ... 和 /* ... */
        s = re.sub(r'//.*', '', s)
        s = re.sub(r'/\*[\s\S]*?\*/', '', s)

        # 2. 修复 Key 没有引号的情况
        s = re.sub(r'(?<=[\{\s,])([a-zA-Z_][a-zA-Z0-9_]*)\s*:', r'"\1":', s)

        # 3. 【关键修复】处理字符串 Value 内部的未转义双引号和控制字符
        # 问题：字符串内容中包含未转义的引号时，需要找到真正的结束位置（后面跟着 , 或 }）
        # 解决方案：找到 :"..." 模式，然后找到后面第一个 ", 或 "} 或 "$ 作为结束
        result = []
        i = 0
        while i < len(s):
            if s[i] == ':' and i + 1 < len(s):
                # 找到字段值的起始位置
                j = i + 1
                while j < len(s) and s[j] in ' \t\n\r':
                    j += 1
                if j < len(s) and s[j] == '"':
                    # 找到字符串值的起始引号
                    start = j
                    j += 1
                    # 现在找到真正的字符串结束位置
                    # 规则：找到下一个未转义的 "，且后面紧跟 , 或 } 或字符串结束
                    end_quote = -1
                    escaped = False
                    k = j
                    while k < len(s):
                        if escaped:
                            escaped = False
                            k += 1
                            continue
                        if s[k] == '\\':
                            escaped = True
                            k += 1
                            continue
                        if s[k] == '"':
                            # 检查后面是否是 , 或 } 或结尾
                            after = s[k+1:k+2]
                            if after == ',' or after == '}' or k+1 == len(s):
                                end_quote = k
                                break
                        k += 1
                    
                    if end_quote != -1:
                        # 找到了有效的结束引号
                        content = s[start+1:end_quote]
                        # 修复内容中的未转义引号和控制字符
                        content = re.sub(r'(?<!\\)"', r'\\"', content)
                        content = content.replace('\n', '\\n').replace('\r', '\\r').replace('\t', '\\t')
                        # 替换到结果中
                        result.append(s[i:start+1])  # : "
                        result.append(content)
                        result.append(s[end_quote])   # "
                        i = end_quote + 1
                        continue
            result.append(s[i])
            i += 1
        s = ''.join(result)
        
        # 4. 额外修复：investment_amount 字段的值可能包含非数字内容（如中文、乱码、换行、英文数字词）
        # 从值中提取纯数字，如果没有数字则设置默认值50
        ENGLISH_NUMBERS = {
            'zero': 0, 'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5,
            'six': 6, 'seven': 7, 'eight': 8, 'nine': 9, 'ten': 10,
            'eleven': 11, 'twelve': 12, 'thirteen': 13, 'fourteen': 14, 'fifteen': 15,
            'sixteen': 16, 'seventeen': 17, 'eighteen': 18, 'nineteen': 19,
            'twenty': 20, 'thirty': 30, 'forty': 40, 'fifty': 50,
            'sixty': 60, 'seventy': 70, 'eighty': 80, 'ninety': 90, 'hundred': 100
        }
        
        # 单独处理 investment_amount 字段
        # 找到 investment_amount 的值并替换为纯数字
        investment_pattern = r'("[^"]*investment_amount[^"]*")\s*:\s*(.+?)(?=\s*,\s*"|\s*})'
        def fix_investment_amount(match):
            key = match.group(1)
            value = match.group(2)
            # 去掉引号
            value = value.strip('"\'')
            # 1. 先尝试提取阿拉伯数字
            nums = re.findall(r'\d+', value)
            if nums:
                return f'{key}: {nums[-1]}'
            # 2. 如果没有阿拉伯数字，尝试提取英文数字词
            value_lower = value.lower()
            for word, num in ENGLISH_NUMBERS.items():
                if word in value_lower:
                    return f'{key}: {num}'
            # 3. 如果都没有，设置默认值50
            return f'{key}: 50'
        
        s = re.sub(investment_pattern, fix_investment_amount, s, flags=re.DOTALL)

        # 5. 删尾逗号
        s = re.sub(r',\s*(?=[}\]])', '', s)

        return s.strip()

    # =======================
    # Strict Parser (主入口)
    # =======================

    @staticmethod
    def parse_llm_response(
        response: str,
        agent_id: Optional[int] = None
    ) -> Tuple[float, str]:
        """
        解析 LLM 响应，返回 (investment_amount, reason)。
        如果 'investment_amount' 缺失，返回默认值 50.0 并在 reason 中打印警告。
        """
        cleaned = LLMResponseParser.clean_response_text(response)
        if not cleaned:
            raise ValueError("LLM response is empty after cleaning")

        json_block = LLMResponseParser.extract_json_from_text(cleaned)
        if not json_block:
            # 尝试直接将清理后的文本当作 JSON 处理 
            if cleaned.startswith('{'): 
                json_block = cleaned
            else:
                # 如果连 {} 或 [] 都找不到，说明 LLM 返回了完全非结构化的内容，直接失败
                raise ValueError("No JSON block found in LLM response")

        # 修复 JSON 格式 (包含对换行符的转义)
        json_block = LLMResponseParser.repair_json_format(json_block)

        data = None
        
        # 尝试 1: 标准 JSON 解析
        try:
            data = json.loads(json_block)
        except Exception:
            # 尝试 2: Python eval 解析 (容错性更强)
            try:
                # 预处理：将 JSON 的 boolean/null 转为 Python 的 Boolean/None
                eval_block = json_block.replace("true", "True") \
                                       .replace("false", "False") \
                                       .replace("null", "None")
                data = ast.literal_eval(eval_block)
            except Exception as e:
                # 如果两次都失败，抛出错误
                raise ValueError(f"JSON parsing failed: {e}") from e

        if not isinstance(data, dict):
            raise TypeError("Parsed JSON is not a dict")

        # ===== 1. investment_amount (处理字段缺失、别名和默认值) =====
        AMOUNT_ALIASES = ["investment_amount", "invest_amount", "amount", "investment", "invest"]
        amount = None
        default_used = False
        
        for key_name in AMOUNT_ALIASES:
            if key_name in data:
                try:
                    amount = float(data[key_name])
                    break # 找到并成功转换为 float 后跳出循环
                except Exception:
                    # 转换失败，继续尝试下一个别名
                    pass 
        
        if amount is None:
            # 核心修改：如果找不到或无效，设置默认值 50.0
            amount = 50.0
            default_used = True

        # ===== 2. reason (处理字段缺失和别名) =====
        REASON_ALIASES = ["reason", "explanation", "thinking_process", "analysis", "justification"]
        reason = None

        for key_name in REASON_ALIASES:
            if key_name in data:
                reason = str(data[key_name])
                if reason.strip():
                    break # 找到非空 reason 后跳出循环

        if not reason or not reason.strip():
            reason = "No detailed reason or explanation provided by LLM."
        
        # ===== 3. 注入警告信息（如果使用了默认值） =====
        if default_used:
            warning_msg = f"[WARNING: investment_amount field was missing, misspelled, or invalid. Defaulting to {amount:.1f}. Check LLM output for formatting error.]"
            reason = f"{warning_msg} {reason}"
            
        return amount, reason

    @staticmethod
    def parse_memory_summary_response(response: str) -> Tuple[Optional[int], Optional[str]]:
        """
        解析记忆总结响应，返回 (ability_assessment, memory_summary)
        
        Args:
            response: LLM返回的记忆总结文本
            
        Returns:
            Tuple[Optional[int], Optional[str]]: (能力评估等级1-5, 记忆总结文本)
        """
        cleaned = LLMResponseParser.clean_response_text(response)
        if not cleaned:
            return None, None

        json_block = LLMResponseParser.extract_json_from_text(cleaned)
        if not json_block:
            if cleaned.startswith('{'): 
                json_block = cleaned
            else:
                return None, None

        # 修复 JSON 格式
        json_block = LLMResponseParser.repair_json_format(json_block)

        data = None
        
        # 尝试解析JSON
        try:
            data = json.loads(json_block)
        except Exception:
            try:
                eval_block = json_block.replace("true", "True") \
                                       .replace("false", "False") \
                                       .replace("null", "None")
                data = ast.literal_eval(eval_block)
            except Exception:
                return None, None

        if not isinstance(data, dict):
            return None, None

        # 提取能力评估
        ability_assessment = None
        if "ABILITY_ASSESSMENT" in data:
            try:
                ability_value = data["ABILITY_ASSESSMENT"]
                if isinstance(ability_value, (int, float)):
                    ability_int = int(ability_value)
                    if 1 <= ability_int <= 5:
                        ability_assessment = ability_int
            except (ValueError, TypeError):
                pass

        # 提取记忆总结文本
        memory_summary = None
        if "MEMORY_SUMMARY" in data:
            memory_summary = str(data["MEMORY_SUMMARY"]).strip()
        
        return ability_assessment, memory_summary

