import os
import json
import numpy as np
import matplotlib.pyplot as plt
from typing import Dict, List, Tuple

def load_round_data(experiment_dir: str) -> Dict[str, List[float]]:
    """Load statistical data for all rounds in the specified experiment folder"""
    rounds_dir = os.path.join(experiment_dir, "expdata", "rounds")
    if not os.path.exists(rounds_dir):
        rounds_dir = os.path.join(experiment_dir, "rounds")
        if not os.path.exists(rounds_dir):
            raise FileNotFoundError(f"Round data directory does not exist: {rounds_dir}")

    data = {
        "rounds": [],
        "avg_score": [],
        "avg_input": [],
        "input_cv": [],
        "lying_ratio": []  # 新增：躺平比例
    }

    for round_num in range(1, 51):
        filename = f"round_{round_num:03d}.json"
        file_path = os.path.join(rounds_dir, filename)

        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Missing round file: {file_path}\nPlease confirm round files are complete")

        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                round_data = json.load(f)
            
            system_stats = round_data.get("system_stats", {})
            if not system_stats:
                # Try to calculate required statistics from agents_data if system_stats is missing
                agents = round_data.get("agents_data", [])
                if not agents:
                    raise KeyError(f"system_stats or agents_data field not found in round file {filename}")
                
                inputs = [agent.get("current_round_investment", 0.0) for agent in agents]
                scores = [agent.get("score", 0.0) for agent in agents]
                
                avg_input = sum(inputs) / len(inputs) if inputs else 0.0
                avg_score = sum(scores) / len(scores) if scores else 0.0
                
                # Calculate coefficient of variation (standard deviation/mean)
                if avg_input != 0:
                    mean = avg_input
                    variance = sum((x - mean) **2 for x in inputs) / len(inputs) if inputs else 0.0
                    std_dev = variance** 0.5
                    input_cv = std_dev / mean
                else:
                    input_cv = 0.0
                
                # Calculate lying ratio (input == 0)
                zero_input_count = sum(1 for x in inputs if x == 0.0)
                lying_ratio = zero_input_count / len(inputs) if inputs else 0.0
                
                system_stats = {
                    "avg_score": avg_score,
                    "avg_input": avg_input,
                    "input_cv": input_cv,
                    "lying_ratio": lying_ratio
                }

            required_fields = ["avg_score", "avg_input", "input_cv"]
            for field in required_fields:
                if field not in system_stats:
                    raise KeyError(f"{field} field missing in system_stats of round file {filename}")
            
            # 获取躺平比例，支持两种字段名
            if "lying_ratio" in system_stats:
                lying_ratio_val = system_stats["lying_ratio"]
            elif "lying_flat_ratio" in system_stats:
                lying_ratio_val = system_stats["lying_flat_ratio"]
            else:
                # 如果都没有，自己计算
                agents = round_data.get("agents_data", [])
                inputs = [agent.get("current_round_investment", 0.0) or agent.get("input", 0.0) for agent in agents]
                zero_input_count = sum(1 for x in inputs if x == 0.0)
                lying_ratio_val = zero_input_count / len(inputs) if inputs else 0.0

            data["rounds"].append(round_num)
            data["avg_score"].append(system_stats["avg_score"])
            data["avg_input"].append(system_stats["avg_input"])
            data["input_cv"].append(system_stats["input_cv"])
            data["lying_ratio"].append(lying_ratio_val)

        except json.JSONDecodeError:
            raise ValueError(f"Round file {filename} format error, cannot parse as JSON")

    return data

def get_file_identifier(folder_paths: List[str]) -> str:
    """
    Generate unique file identifier from folder path list
    Rule: Extract last two digits of the last part of each folder name and concatenate
    Example:
    exp1_20251201_124558 -> 58
    exp1_20251201_170106 -> 06
    exp1_20251202_004542 -> 42
    Final identifier: exp1_580642
    """
    suffix_parts = []
    for path in folder_paths:
        # Get folder name (last level directory)
        folder_name = os.path.basename(os.path.normpath(path))
        # Split by underscore, take last part (timestamp part)
        name_parts = folder_name.split('_')
        if len(name_parts) >= 3:
            timestamp_part = name_parts[-1]  # Take last part (e.g., 124558)
        else:
            timestamp_part = folder_name  # Use full name if format is abnormal
        
        # Extract last two digits (pad with 0 if less than two digits)
        if len(timestamp_part) >= 2:
            suffix = timestamp_part[-2:]
        else:
            suffix = timestamp_part.ljust(2, '0')  # Pad with 0 if less than two digits
        
        # Ensure extracted characters are digits (fault tolerance)
        suffix = ''.join([c for c in suffix if c.isdigit()]) or '00'
        suffix_parts.append(suffix)
    
    # Concatenate all suffixes, keep exp1_ format for prefix
    prefix = "exp1_" if suffix_parts else "exp_"
    return f"{prefix}{''.join(suffix_parts)}"

def generate_comparison_plots(all_data: List[Tuple[str, Dict[str, List[float]]]], 
                             output_dir: str,  # 单个输出目录，而不是多个
                             labels: List[str]):  # 自定义标签列表
    """Generate and save comparison visualization charts for multiple experiments (with unique filename identifier)"""
    # Generate unique file identifier (e.g., exp1_580642)
    path_list = [path for path, _ in all_data] if all_data else []
    file_identifier = get_file_identifier(path_list)
    
    # Create picture folder in main experiment directory
    os.makedirs(output_dir, exist_ok=True)
    
    # Remove Chinese font configuration (no longer needed)
    plt.style.use('default')
    fig_size = (10, 6)
    dpi = 600
    colors = ['blue', 'green', 'red', 'purple', 'orange', 'cyan']  # Extendable color list
    markers = ['o', 's', '^', 'D', 'v', '<']      # Marker style list

    # Average Input Comparison Chart
    plt.figure(figsize=fig_size)
    for i, (path, data) in enumerate(all_data):
        color = colors[i % len(colors)]
        marker = markers[i % len(markers)]
        plt.plot(data["rounds"], data["avg_input"], linestyle='-', color=color, 
                 marker=marker, markersize=4, label=labels[i], alpha=0.8)
    
    plt.title("Average Input Comparison Across Experiments", fontsize=14)
    plt.xlabel("Round", fontsize=12)
    plt.ylabel("Average Input", fontsize=12)
    plt.legend(fontsize=10)
    plt.grid(True, linestyle='--', alpha=0.7)
    
    save_path = os.path.join(output_dir, f"{file_identifier}_avg_input_comparison.png")
    plt.savefig(save_path, dpi=dpi, bbox_inches='tight')
    plt.close()

    # Lying Ratio Comparison Chart (NEW: replaces avg_score)
    plt.figure(figsize=fig_size)
    for i, (path, data) in enumerate(all_data):
        color = colors[i % len(colors)]
        marker = markers[i % len(markers)]
        plt.plot(data["rounds"], data["lying_ratio"], linestyle='-', color=color, 
                 marker=marker, markersize=4, label=labels[i], alpha=0.8)
    
    plt.title("Lying Ratio Comparison Across Experiments", fontsize=14)
    plt.xlabel("Round", fontsize=12)
    plt.ylabel("Lying Ratio (Input=0 Agents / Total Agents)", fontsize=12)
    plt.legend(fontsize=10)
    plt.grid(True, linestyle='--', alpha=0.7)
    
    save_path = os.path.join(output_dir, f"{file_identifier}_lying_ratio_comparison.png")
    plt.savefig(save_path, dpi=dpi, bbox_inches='tight')
    plt.close()

    # Input CV Comparison Chart
    plt.figure(figsize=fig_size)
    for i, (path, data) in enumerate(all_data):
        color = colors[i % len(colors)]
        marker = markers[i % len(markers)]
        plt.plot(data["rounds"], data["input_cv"], linestyle='-', color=color, 
                 marker=marker, markersize=4, label=labels[i], alpha=0.8)
    
    plt.title("Input CV Comparison Across Experiments", fontsize=14)
    plt.xlabel("Round", fontsize=12)
    plt.ylabel("Input CV", fontsize=12)
    plt.legend(fontsize=10)
    plt.grid(True, linestyle='--', alpha=0.7)
    
    save_path = os.path.join(output_dir, f"{file_identifier}_input_cv_comparison.png")
    plt.savefig(save_path, dpi=dpi, bbox_inches='tight')
    plt.close()

def validate_experiment_path(path: str) -> bool:
    """Validate if experiment path is valid (exists and contains rounds data)"""
    if not os.path.exists(path):
        print(f"Path does not exist: {path}")
        return False
    rounds_dir = os.path.join(path, "expdata", "rounds")
    if not os.path.exists(rounds_dir):
        rounds_dir = os.path.join(path, "rounds")
        if not os.path.exists(rounds_dir):
            print(f"Path does not contain valid experiment data: {path}\n   Missing rounds subdirectory")
            return False
    return True

def extract_reward_label(path: str) -> str:
    """Extract reward value from path for labeling"""
    path = os.path.normpath(path)
    parts = path.split(os.sep)
    for part in parts:
        if part.startswith("reward_") and part[7:].replace('.', '').isdigit():
            return part.replace("reward_", "Reward=")
    return os.path.basename(path)

def visualize_multiple_experiments(experiment_paths: List[str]):
    """Entry function for visualizing multiple experiments, display comparison and save to main experiment directory"""
    try:
        # Validate all path validity
        valid_paths = []
        for path in experiment_paths:
            # Handle Windows path escape issues
            path = path.strip().replace("\\", "/").replace('"', '').replace("'", '')
            if validate_experiment_path(path):
                valid_paths.append(path)
        
        if not valid_paths:
            print("No valid experiment paths, visualization terminated")
            return
        
        # Load all experiment data
        all_data = []
        labels = []
        for path in valid_paths:
            label = extract_reward_label(path)
            labels.append(label)
            print(f"Loading experiment data: {path}")
            data = load_round_data(path)
            all_data.append((path, data))
        
        # Determine main output directory: go up to reward_experiment level
        main_output_dir = None
        if valid_paths:
            first_path = os.path.normpath(valid_paths[0])
            parts = first_path.split(os.sep)
            # Find the "reward_experiment" directory
            for i in range(len(parts)):
                if parts[i] == "reward_experiment":
                    main_output_dir = os.sep.join(parts[:i+1])
                    break
        # Fallback: create picture folder in parent directory
        if not main_output_dir:
            main_output_dir = os.path.dirname(os.path.dirname(os.path.normpath(valid_paths[0])))
        main_output_dir = os.path.join(main_output_dir, "picture")
        
        # Generate comparison charts and save to main directory
        generate_comparison_plots(all_data, main_output_dir, labels)
        
        # Generated file identifier
        file_id = get_file_identifier(valid_paths)
        print(f"\nComparison visualization completed! Generated image identifier: {file_id}")
        print(f"Charts have been saved to: {main_output_dir}")
        print(f"Example filename: {file_id}_avg_input_comparison.png")
            
    except Exception as e:
        print(f"Visualization failed: {str(e)}")
        import traceback
        traceback.print_exc()

# 保留其他函数，简化使用
def visualize_single_ratio_line(experiment_paths: List[str]):
    print("\nvisualize_single_ratio_line function is deprecated.")

def visualize_avg_score_histogram(json_paths: List[str]):
    print("\nvisualize_avg_score_histogram function is deprecated.")

def visualize_zero_input_counts(experiment_paths: List[str]):
    print("\nvisualize_zero_input_counts function is deprecated.")

def visualize_ability_assessment_accuracy(experiment_paths: List[str]):
    print("\nvisualize_ability_assessment_accuracy function is deprecated.")
