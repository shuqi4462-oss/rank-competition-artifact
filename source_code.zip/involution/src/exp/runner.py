import os
import json
import yaml
import copy
import numpy as np
from datetime import datetime
from typing import Dict, Any, List, Optional
from collections import deque

from src.core.agent import Agent
from src.core.environment import Environment
from src.core.memory import MemorySystem
from src.llm.prompts import PromptManager
from src.llm.client import LLMClient
from src.utils.logger import ExperimentLogger
from src.utils.boltzmann import calculate_score_arrays
from baseline.purebayes_baseline import BayesianAgent, GameConfig

try:
    from src.core.network import NetworkManager
except ImportError:
    NetworkManager = None


class ExperimentRunner:
    def __init__(self, config_path: str = "config/experiment_config.yaml"):
        with open(config_path, 'r', encoding='utf-8') as f:
            self.config = yaml.safe_load(f)
        self.conditions = self.config.get('experiment_conditions', {})

    def _make_condition_config(
        self,
        final_reward: float,
        ability_std: float,
        top_percentage: float,
        network_type: Optional[str] = None,
    ) -> Dict[str, Any]:
        cfg = copy.deepcopy(self.config)

        cfg.setdefault("resources", {})
        cfg["resources"]["final_reward"] = float(final_reward)
        cfg["resources"]["top_percentage"] = float(top_percentage)

        cfg.setdefault("agent_params", {})
        cfg["agent_params"].setdefault("intrinsic_ability", {})
        cfg["agent_params"]["intrinsic_ability"]["std"] = float(ability_std)

        if network_type is not None:
            cfg.setdefault("network", {})
            cfg["network"]["network_type"] = network_type

        return cfg

    def _create_llm_client(self):
        llm_cfg = self.config.get('llm', {})
        return LLMClient(
            api_key=os.getenv('LLM_API_KEY'),
            base_url=llm_cfg.get('base_url', 'https://api.openai.com/v1'),
            model_name=os.getenv('LLM_MODEL', llm_cfg.get('model_name', 'SET_MODEL_ID')),
            temperature=llm_cfg.get('temperature', 1.0),
            max_tokens=llm_cfg.get('max_tokens', 1024),
            verbose=True
        )

    def _create_llm_agents(self, agent_count: int, ability_std: float,
                           llm_client: LLMClient, experiment_type: int,
                           seed: int = 0, run_config=None,
                           personality_path: str = "data/personality_profiles.json"):
        cfg = run_config if run_config is not None else self.config
        agent_params = cfg.get('agent_params', {})
        ability_mean = agent_params.get('intrinsic_ability', {}).get('mean', 0.5)

        rng = np.random.default_rng(seed)
        abilities = rng.normal(ability_mean, ability_std, agent_count)
        abilities = np.clip(abilities, -100, 100)

        agents = []
        for agent_id in range(1, agent_count + 1):
            cfg.setdefault("experiment", {})
            cfg["experiment"]["type"] = experiment_type
            prompt_manager = PromptManager(cfg)
            memory_system = MemorySystem(
                agent_id=agent_id,
                config=cfg,
                experiment_type=experiment_type
            )
            agent = Agent(
                agent_id=agent_id,
                intrinsic_ability=float(abilities[agent_id - 1]),
                llm_client=llm_client,
                prompt_manager=prompt_manager,
                memory_system=memory_system,
                config=cfg.get('agent', {})
            )
            agents.append(agent)
        return agents

    def _create_network_manager(self, network_type: str, agent_ids: List[int],
                                personality_path: str = "data/personality_profiles.json"):
        if network_type == "none":
            return None

        network_config = self.config.get('network', {}).copy()
        network_config['network_type'] = network_type

        return NetworkManager(
            config=network_config,
            network_type=network_type,
            agent_ids=agent_ids,
            personality_path=personality_path
        )

    def _build_runtime_config(self, final_reward, ability_std, top_percentage=None,
                              network_type=None):
        effective_top_pct = float(
            top_percentage
            if top_percentage is not None
            else self.config.get("resources", {}).get("top_percentage", 0.7)
        )

        runtime_config = {
            'experiment': {
                'total_rounds': self.config.get('experiment', {}).get('total_rounds', 50),
                'rounds_per_block': self.config.get('experiment', {}).get('rounds_per_block', 5),
                'network_modify_interval': self.config.get('experiment', {}).get('network_modify_interval', 5),
            },
            'resources': {
                'total': self.config.get('resources', {}).get('total', 20000),
                'top_percentage': effective_top_pct,
                'final_reward': float(final_reward),
            },
            "top_percentage": effective_top_pct,
            'boltzmann': copy.deepcopy(self.config.get('boltzmann', {})),
            'timeout': copy.deepcopy(self.config.get('timeout', {})),
            'recovery': copy.deepcopy(self.config.get('recovery', {})),
            'agent': copy.deepcopy(self.config.get('agent', {})),
            'agent_params': copy.deepcopy(self.config.get('agent_params', {})),
            'network': copy.deepcopy(self.config.get('network', {})),
            'ability_std': float(ability_std),
        }


        runtime_config["agent_params"].setdefault("intrinsic_ability", {})
        runtime_config["agent_params"]["intrinsic_ability"]["std"] = float(ability_std)

        if network_type:
            runtime_config["network"]["network_type"] = network_type

        return runtime_config

    def _save_runtime_config(self, config: Dict[str, Any], output_dir: str):
        os.makedirs(output_dir, exist_ok=True)
        config_path = os.path.join(output_dir, "runtime_config.yaml")
        with open(config_path, 'w', encoding='utf-8') as f:
            yaml.safe_dump(config, f, allow_unicode=True, sort_keys=False)

    def _run_llm_environment(self, agents: List[Agent], network_manager,
                             runtime_config: Dict[str, Any],
                             output_dir: str, experiment_type: int,
                             state_file: str = None):
        os.makedirs(output_dir, exist_ok=True)

        self._save_runtime_config(runtime_config, output_dir)
        config_path = os.path.join(output_dir, "runtime_config.yaml")

        env = Environment(
            config_path=config_path,
            agents=agents,
            experiment_type=experiment_type,
            network_manager=network_manager,
            state_file=state_file,
            logger_base_dir=output_dir
        )

        total_rounds = runtime_config['experiment']['total_rounds']
        completed_cleanly = False

        try:
            if env.current_round >= total_rounds:
                print(f"检测到恢复状态已完成所有 {total_rounds} 轮次（current_round={env.current_round}），跳过执行")
                completed_cleanly = True
            else:
                for round_num in range(env.current_round, total_rounds):
                    env.run_round()
                    print(f"轮次 {round_num + 1}/{total_rounds} 完成")
                completed_cleanly = True
        except Exception as e:
            print(f"\n实验运行异常: {e}")
            completed_cleanly = False
        finally:
            try:
                env.finalize()
            except Exception as e:
                print(f"finalize 失败: {e}")

        if completed_cleanly:
            summary_path = os.path.join(output_dir, "experiment_summary.json")
            with open(summary_path, 'w', encoding='utf-8') as f:
                json.dump({
                    "completed": True,
                    "experiment_type": experiment_type,
                    "total_rounds": total_rounds,
                    "completion_time": datetime.now().isoformat()
                }, f, ensure_ascii=False, indent=2)
            if state_file and os.path.exists(state_file):
                os.remove(state_file)
                print(f"已清理恢复文件: {state_file}")

        return env

    def _run_baseline_single(self, final_reward: float, ability_std: float,
                             seed: int, output_dir: str,
                             top_percentage: float = None):
        os.makedirs(output_dir, exist_ok=True)

        agent_params = self.config.get('agent_params', {})
        ability_mean = agent_params.get('intrinsic_ability', {}).get('mean', 0.5)
        agent_count = agent_params.get('count', 200)
        total_rounds = self.config.get('experiment', {}).get('total_rounds', 50)
        rounds_per_block = self.config.get('experiment', {}).get('rounds_per_block', 5)
        boltzmann_cfg = self.config.get('boltzmann', {})

        game_config = GameConfig(
            N=agent_count,
            T=total_rounds,
            E=100,
            kappa=float(boltzmann_cfg.get("temperature", 20.0)),
            M=self.config.get("resources", {}).get("total", 20000),

            Q=float(
                top_percentage
                if top_percentage is not None
                else self.config.get("resources", {}).get("top_percentage", 0.7)
            ),

            epsilon_std=boltzmann_cfg.get("noise_std", 5.0),
            final_reward=float(final_reward),
            ability_mean=ability_mean,
            ability_std=float(ability_std),
            rank_update_interval=rounds_per_block,
            seed=seed,

            candidate_step=1,
            use_initial_private_rank=False,
        )

        rng = np.random.default_rng(seed)
        true_abilities = rng.normal(ability_mean, ability_std, agent_count)
        true_abilities = np.clip(true_abilities, -100, 100)

        init_ability_mus = rng.normal(
            game_config.init_ability_mu,
            game_config.init_ability_sigma,
            agent_count
        )
        init_ability_mus = np.clip(init_ability_mus, 0.05, 2.0)

        init_competition_mus = rng.normal(
            game_config.init_competition_mu,
            game_config.init_competition_sigma,
            agent_count
        )
        init_competition_mus = np.clip(init_competition_mus, 0.0, game_config.E)

        initial_rank_signal = init_ability_mus + rng.normal(
            0.0,
            game_config.initial_rank_signal_noise,
            agent_count
        )
        initial_order = np.argsort(-initial_rank_signal)
        initial_ranks = np.empty(agent_count, dtype=int)
        initial_ranks[initial_order] = np.arange(1, agent_count + 1)

        agents = []
        for i in range(agent_count):
            agent = BayesianAgent(
                agent_id=i + 1,
                config=game_config,
                true_ability=float(true_abilities[i]),
                initial_ability_mu=float(init_ability_mus[i]),
                initial_ability_sigma=float(game_config.init_ability_sigma),
                initial_competition_mu=float(init_competition_mus[i]),
                initial_competition_sigma=float(game_config.init_competition_sigma),
            )
            agent.latest_rank = int(initial_ranks[i])
            agent.previous_rank = int(initial_ranks[i])
            agents.append(agent)

        rounds_dir = os.path.join(output_dir, "rounds")
        os.makedirs(rounds_dir, exist_ok=True)

        round_statistics = []

        for round_num in range(total_rounds):
            investments = []
            for agent in agents:
                x = agent.decide_investment(round_num + 1)
                investments.append(x)

            scores = self._calculate_baseline_scores(investments, agents, game_config, rng)

            for i, agent in enumerate(agents):
                agent.observe_result(investments[i], scores[i])

            if (round_num + 1) % rounds_per_block == 0:
                avg_scores = {}
                for agent in agents:
                    all_scores = agent.scores
                    avg_scores[agent.agent_id] = np.mean(all_scores) if all_scores else 0

                sorted_avg = sorted(avg_scores.items(), key=lambda x: x[1], reverse=True)
                for rank, (aid, _) in enumerate(sorted_avg, 1):
                    agent = agents[aid - 1]
                    agent.update_rank_information(rank)

            round_data = self._build_baseline_round_data(
                round_num, investments, scores, agents
            )
            round_file = os.path.join(rounds_dir, f"round_{round_num + 1:03d}.json")
            with open(round_file, 'w', encoding='utf-8') as f:
                json.dump(round_data, f, ensure_ascii=False, indent=2)

            round_statistics.append(round_data['system_stats'])

        summary = self._build_baseline_summary(round_statistics, agents, game_config)
        summary_file = os.path.join(output_dir, "experiment_summary.json")
        with open(summary_file, 'w', encoding='utf-8') as f:
            json.dump(summary, f, ensure_ascii=False, indent=2)

        return summary

    def _calculate_baseline_scores(
        self,
        investments,
        agents,
        game_config,
        rng,
    ):
        abilities = np.array(
            [a.true_ability for a in agents],
            dtype=float,
        )

        scores, _, _, _, _ = calculate_score_arrays(
            investments=np.asarray(investments, dtype=float),
            abilities=abilities,
            temperature=game_config.kappa,
            total_resources=game_config.M,
            noise_std=game_config.epsilon_std,
            rng=rng,
        )

        return scores.tolist()

    def _build_baseline_round_data(self, round_num: int, investments: List[float],
                                   scores: List[float], agents: List[BayesianAgent]):
        round_index = round_num + 1
        agents_data = []
        for i, agent in enumerate(agents):
            agents_data.append({
                "agent_id": agent.agent_id,
                "input": investments[i],
                "reason": "Bayesian optimal decision",
                "score": round(scores[i], 2),
                "total_assets": 0.0,
                "total_investment": 0.0,
                "current_round_investment": investments[i],
                "rank": agent.latest_rank,
                "avg_score": agent.latest_avg_score,
                "ability_assessment": None,
                "calculation_details": {},
                "memory_summary": None,
                "neighbors_info": [],
            })

        current_inputs = investments
        current_scores = scores
        avg_input = np.mean(current_inputs) if current_inputs else 0
        avg_score = np.mean(current_scores) if current_scores else 0
        input_cv = (np.std(current_inputs) / avg_input) if avg_input != 0 else 0
        lying_flat_count = sum(1 for x in current_inputs if x < 0.01)
        lying_flat_ratio = lying_flat_count / len(current_inputs) if current_inputs else 0

        return {
            "round": round_index,
            "timestamp": datetime.now().isoformat(),
            "agents_data": agents_data,
            "system_stats": {
                "avg_score": round(avg_score, 2),
                "avg_input": round(avg_input, 2),
                "input_cv": round(input_cv, 4),
                "lying_flat_ratio": round(lying_flat_ratio, 4),
                "avg_total_assets": 0.0,
                "avg_total_investment": 0.0,
            }
        }

    def _build_baseline_summary(self, round_statistics: List[Dict],
                                agents: List[BayesianAgent],
                                game_config: GameConfig):
        return {
            "experiment_type": "baseline",
            "total_rounds": len(round_statistics),
            "completion_time": datetime.now().isoformat(),
            "round_statistics": round_statistics,
            "final_summary": {
                "overall_avg_score": round(np.mean([s["avg_score"] for s in round_statistics]), 2) if round_statistics else 0,
                "overall_avg_input": round(np.mean([s["avg_input"] for s in round_statistics]), 2) if round_statistics else 0,
                "overall_input_cv": round(np.mean([s["input_cv"] for s in round_statistics]), 4) if round_statistics else 0,
                "overall_lying_flat_ratio": round(np.mean([s["lying_flat_ratio"] for s in round_statistics]), 4) if round_statistics else 0,
                "overall_avg_total_assets": 0.0,
                "overall_avg_total_investment": 0.0,
            },
            "agent_final_status": [
                {
                    "agent_id": agent.agent_id,
                    "intrinsic_ability": agent.true_ability,
                    "initial_total_assets": 0.0,
                    "final_total_assets": 0.0,
                    "total_investment": sum(agent.investments),
                    "final_ability_assessment": None,
                    "ability_assessment_count": 0,
                }
                for agent in agents
            ]
        }

    def run_experiment1_baseline(self):
        cond = self.conditions.get('experiment1', {})
        reward_values = cond.get('reward_values', [357])
        q_values = cond.get('q_values', [0.7])
        ability_std = cond.get('ability_std', 1.0)
        seeds = cond.get('baseline_seeds', [0, 10, 20, 30, 40])

        base_dir = "data/reward_experiment/baseline_reward"
        print(f"\n{'='*60}")
        print(f"实验1 Baseline: 不同 reward 下的 Bayesian 基线")
        print(f"Reward values: {reward_values}")
        print(f"Seeds: {seeds}")
        print(f"{'='*60}")

        for reward in reward_values:
            for q in q_values:
                for seed in seeds:
                    output_dir = os.path.join(base_dir, f"q_{q}", f"reward_{reward}", f"seed_{seed}")
                    self._run_baseline_single(
                        final_reward=float(reward),
                        ability_std=ability_std,
                        seed=seed,
                        output_dir=output_dir,
                        top_percentage=q
                    )

    def run_experiment1_llm(self):
        cond = self.conditions.get('experiment1', {})
        reward_values = cond.get('reward_values', [357])
        ability_std = cond.get('ability_std', 1.0)

        base_dir = "data/reward_experiment/llm_reward"
        print(f"\n{'='*60}")
        print(f"实验1 LLM: 不同 reward 下的 LLM Agent")
        print(f"Reward values: {reward_values}")
        print(f"{'='*60}")

        llm_client = self._create_llm_client()
        agent_count = self.config.get('agent_params', {}).get('count', 200)
        q_values = cond.get(
            "q_values",
            [self.config.get("resources", {}).get("top_percentage", 0.4)]
        )

        for q in q_values:
            for reward in reward_values:

                output_dir = os.path.join(
                    base_dir,
                    f"q_{q}",
                    f"reward_{reward}",
                )

                state_file = os.path.join(
                    output_dir,
                    "recovery_state.json",
                )

                if os.path.exists(
                    os.path.join(output_dir, "experiment_summary.json")
                ):
                    continue

                condition_config = self._make_condition_config(
                    final_reward=float(reward),
                    ability_std=float(ability_std),
                    top_percentage=float(q),
                )

                agents = self._create_llm_agents(
                    agent_count=agent_count,
                    ability_std=ability_std,
                    llm_client=llm_client,
                    experiment_type=1,
                    seed=0,
                    run_config=condition_config,
                )

                runtime_config = self._build_runtime_config(
                    final_reward=float(reward),
                    ability_std=float(ability_std),
                    top_percentage=float(q),
                )

                self._run_llm_environment(
                    agents=agents,
                    network_manager=None,
                    runtime_config=runtime_config,
                    output_dir=output_dir,
                    experiment_type=1,
                    state_file=state_file,
                )

    def run_experiment2_baseline(self):
        cond = self.conditions.get('experiment2', {})
        final_reward = cond.get('final_reward', 500)
        ability_std_values = cond.get('ability_std_values', [0.5, 1.0, 1.5, 2.0, 2.5, 3.0])
        seeds = cond.get('baseline_seeds', [0, 10, 20, 30, 40])

        base_dir = "data/ability_experiment/baseline_ability"
        print(f"\n{'='*60}")
        print(f"实验2 Baseline: 不同能力分布下的 Bayesian 基线")
        print(f"Ability std values: {ability_std_values}")
        print(f"Final reward: {final_reward}")
        print(f"{'='*60}")

        for std_val in ability_std_values:
            print(f"\n--- Ability Std = {std_val} ---")
            for seed in seeds:
                output_dir = os.path.join(base_dir, f"std_{std_val}", f"seed_{seed}")
                if os.path.exists(os.path.join(output_dir, "experiment_summary.json")):
                    print(f"  跳过已完成的 seed={seed}")
                    continue
                print(f"  运行 seed={seed}...")
                self._run_baseline_single(
                    final_reward=float(final_reward),
                    ability_std=std_val,
                    seed=seed,
                    output_dir=output_dir
                )

    #  实验2
    def run_experiment2_llm(self):
        cond = self.conditions.get('experiment2', {})
        final_reward = cond.get('final_reward', 500)
        ability_std_values = cond.get('ability_std_values', [0.5, 1.0, 1.5, 2.0, 2.5, 3.0])
        seeds = cond.get('llm_seeds', [0])

        top_percentage = self.config.get('resources', {}).get('top_percentage', 0.4)

        base_dir = "data/ability_experiment/llm_ability"
        print(f"\n{'='*60}")
        print(f"实验2 LLM: 不同能力分布下的 LLM Agent")
        print(f"Ability std values: {ability_std_values}")
        print(f"LLM seeds: {seeds}")
        print(f"Final reward: {final_reward}")
        print(f"Top percentage: {top_percentage}")
        print(f"{'='*60}")

        llm_client = self._create_llm_client()
        agent_count = self.config.get('agent_params', {}).get('count', 200)

        for std_val in ability_std_values:
            for seed in seeds:
                output_dir = os.path.join(base_dir, f"std_{std_val}", f"seed_{seed}")
                state_file = os.path.join(output_dir, "recovery_state.json")

                if os.path.exists(os.path.join(output_dir, "experiment_summary.json")):
                    print(f"  跳过已完成的 std={std_val} seed={seed}")
                    continue

                print(f"\n--- Ability Std = {std_val}, Seed = {seed} ---")

                condition_config = self._make_condition_config(
                    final_reward=float(final_reward),
                    ability_std=float(std_val),
                    top_percentage=float(top_percentage),
                )

                agents = self._create_llm_agents(
                    agent_count=agent_count,
                    ability_std=std_val,
                    llm_client=llm_client,
                    experiment_type=2,
                    seed=seed,
                    run_config=condition_config,
                )
                runtime_config = self._build_runtime_config(
                    final_reward=float(final_reward),
                    ability_std=std_val,
                    top_percentage=float(top_percentage),
                )
                self._run_llm_environment(
                    agents=agents,
                    network_manager=None,
                    runtime_config=runtime_config,
                    output_dir=output_dir,
                    experiment_type=2,
                    state_file=state_file
                )

    def run_experiment3_llm(self, ability_std=None, network_type=None, output_dir=None):
        cond = self.conditions.get('experiment3', {})
        final_reward = cond.get('final_reward', 500)
        default_ability_std = cond.get('ability_std', 1.0)
        default_network_types = cond.get('network_types', ["none", "small_world", "hybrid"])
        default_base_dir = "data/network_experiment"

        ability_std = ability_std if ability_std is not None else default_ability_std
        network_types = [network_type] if network_type is not None else default_network_types
        base_dir = output_dir if output_dir is not None else default_base_dir

        top_percentage = self.config.get('resources', {}).get('top_percentage', 0.4)

        print(f"\n{'='*60}")
        print(f"实验3 LLM: 不同社会网络下的 LLM Agent")
        print(f"Ability std: {ability_std}")
        print(f"Network types: {network_types}")
        print(f"Final reward: {final_reward}")
        print(f"Top percentage: {top_percentage}")
        print(f"Output base dir: {base_dir}")
        print(f"{'='*60}")

        llm_client = self._create_llm_client()
        agent_count = self.config.get('agent_params', {}).get('count', 200)

        for net_type in network_types:
            if output_dir is not None:
                actual_output_dir = output_dir
            else:
                actual_output_dir = os.path.join(base_dir, f"network_{net_type}")
            state_file = os.path.join(actual_output_dir, "recovery_state.json")

            if os.path.exists(os.path.join(actual_output_dir, "experiment_summary.json")):
                print(f"  跳过已完成的 network={net_type}")
                continue

            print(f"\n--- Network = {net_type} ---")

            condition_config = self._make_condition_config(
                final_reward=float(final_reward),
                ability_std=float(ability_std),
                top_percentage=float(top_percentage),
                network_type=net_type,
            )

            agents = self._create_llm_agents(
                agent_count=agent_count,
                ability_std=ability_std,
                llm_client=llm_client,
                experiment_type=3,
                seed=0,
                run_config=condition_config,
            )
            agent_ids = [a.id for a in agents]
            network_manager = self._create_network_manager(
                network_type=net_type,
                agent_ids=agent_ids
            )
            runtime_config = self._build_runtime_config(
                final_reward=float(final_reward),
                ability_std=ability_std,
                top_percentage=float(top_percentage),
                network_type=net_type,
            )
            self._run_llm_environment(
                agents=agents,
                network_manager=network_manager,
                runtime_config=runtime_config,
                output_dir=actual_output_dir,
                experiment_type=3,
                state_file=state_file
            )

    def run_all(self):
        print("\n" + "=" * 70)
        print("开始运行所有实验")
        print("=" * 70)

        self.run_experiment1_baseline()
        self.run_experiment1_llm()
        self.run_experiment2_baseline()
        self.run_experiment2_llm()
        self.run_experiment3_llm()

        print("\n" + "=" * 70)
        print("所有实验完成")
        print("=" * 70)