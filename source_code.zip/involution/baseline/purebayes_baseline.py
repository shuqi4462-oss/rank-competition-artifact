import math
import numpy as np
import pandas as pd
from dataclasses import dataclass, field
import os


# ============================================================
# 1. Global Parameters
# ============================================================

@dataclass
class GameConfig:
    N: int = 100
    T: int = 50
    E: int = 100
    kappa: float = 10.0
    M: float = 10000.0
    Q: float = 0.50
    epsilon_mean: float = 0.0
    epsilon_std: float = 5.0

    ability_mean: float = 0.5
    ability_std: float = np.sqrt(0.5)

    final_reward: float = 5000.0

    rank_update_interval: int = 5

    belief_update_interval: int = 1
    belief_update_window: int = 5

    candidate_step: int = 1

    use_initial_private_rank: bool = False
    initial_rank_signal_noise: float = 0.35

    init_ability_mu: float = 0.5
    init_ability_sigma: float = 0.25
    init_competition_mu: float = 35.0
    init_competition_sigma: float = 20.0

    inertia_rho: float = 0.0

    ability_signal_noise_std: float = 0.3
    competition_signal_noise_std: float = 10.0

    n_posterior_samples: int = 30

    seed: int = 42

    # Data-driven environment learning parameters
    # Rolling window size for OLS regression of score ~ beta * investment
    learning_window: int = 5
    # Weak prior for marginal benefit beta (based on public game structure)
    beta_prior_mu: float = 0.18
    beta_prior_sigma: float = 1.5
    # Weak prior for cumulative score gap per rank position
    gap_prior: float = 20.0
    gap_prior_sigma: float = 50.0
    # Weak prior for per-round score noise std
    noise_prior: float = 30.0
    noise_prior_weight: float = 3.0
    # Weak prior for competition level k (investment needed to stay at cutoff)
    k_prior: float = 40.0
    k_prior_sigma: float = 25.0
    # Discount factor for future rounds (rational expectation)
    gamma: float = 0.7
    

    @property
    def cutoff_rank(self):
        return int(math.ceil(self.N * self.Q))

    @property
    def average_score_per_round(self):
        return self.M / self.N


# ============================================================
# 2. Bayesian Agent (data-driven baseline)
# ============================================================

def _norm_cdf(z):
    return 0.5 * (1.0 + math.erf(z / math.sqrt(2.0)))


@dataclass
class BayesianAgent:
    agent_id: int
    config: GameConfig

    true_ability: float = 0.5

    initial_ability_mu: float = None
    initial_ability_sigma: float = None
    initial_competition_mu: float = None
    initial_competition_sigma: float = None

    ability_mu: float = field(init=False)
    ability_sigma: float = field(init=False)
    competition_mu: float = field(init=False)
    competition_sigma: float = field(init=False)

    investments: list = field(default_factory=list)
    scores: list = field(default_factory=list)

    latest_rank: int = field(init=False)
    previous_rank: int = field(init=False)

    latest_avg_score: float = 0.0
    previous_avg_score: float = 0.0

    # Data-driven environment model parameters
    beta_mu: float = field(init=False)
    beta_sigma: float = field(init=False)
    gap_estimate: float = field(init=False)
    sigma_estimate: float = field(init=False)
    k_estimate: float = field(init=False)
    k_sigma: float = field(init=False)

    def __post_init__(self):
        if self.initial_ability_mu is None:
            self.ability_mu = self.config.init_ability_mu
        else:
            self.ability_mu = self.initial_ability_mu
        if self.initial_ability_sigma is None:
            self.ability_sigma = self.config.init_ability_sigma
        else:
            self.ability_sigma = self.initial_ability_sigma

        if self.initial_competition_mu is None:
            self.competition_mu = self.config.init_competition_mu
        else:
            self.competition_mu = self.initial_competition_mu
        if self.initial_competition_sigma is None:
            self.competition_sigma = self.config.init_competition_sigma
        else:
            self.competition_sigma = self.initial_competition_sigma

        self.latest_rank = self.config.N // 2
        self.previous_rank = self.config.N // 2

        self.beta_mu = self.config.beta_prior_mu
        self.beta_sigma = self.config.beta_prior_sigma
        self.gap_estimate = self.config.gap_prior
        self.sigma_estimate = self.config.noise_prior
        self.k_estimate = self.config.k_prior
        self.k_sigma = self.config.k_prior_sigma

    # ----------------------------------------------------------------
    # Decision: maximize expected utility
    # ----------------------------------------------------------------
    def decide_investment(self, current_round: int) -> int:
        if self.config.cutoff_rank >= self.config.N:
            return 0

        self._update_environment_model()

        candidates = list(range(0, self.config.E + 1, self.config.candidate_step))

        best_x = 0
        best_eu = -np.inf

        last_x = self.investments[-1] if len(self.investments) > 0 else 0.0

        rng = np.random.default_rng(current_round * 100 + self.agent_id)
        beta_samples = rng.normal(
            self.beta_mu, max(self.beta_sigma, 1e-8),
            size=self.config.n_posterior_samples
        )
        beta_samples = np.clip(beta_samples, 0.01, None)

        gap_samples = rng.normal(
            self.gap_estimate, max(self.gap_estimate * 0.3, 1.0),
            size=self.config.n_posterior_samples
        )
        gap_samples = np.clip(gap_samples, 1.0, None)

        k_samples = rng.normal(
            self.k_estimate, max(self.k_sigma, 1e-8),
            size=self.config.n_posterior_samples
        )
        k_samples = np.clip(k_samples, 0.0, float(self.config.E))

        for x in candidates:
            p_wins = np.zeros(self.config.n_posterior_samples)
            for s in range(self.config.n_posterior_samples):
                p_wins[s] = self._compute_win_prob(
                    x, beta_samples[s], gap_samples[s], k_samples[s], current_round
                )

            expected_utility = -x + self.config.final_reward * np.mean(p_wins)
            expected_utility -= self.config.inertia_rho * ((x - last_x) ** 2)

            if expected_utility > best_eu:
                best_eu = expected_utility
                best_x = x

        return int(best_x)

    def _compute_win_prob(self, x: float, beta: float, gap: float, k: float,
                          current_round: int) -> float:
        cutoff = self.config.cutoff_rank
        D = self.latest_rank - cutoff

        T_rem = max(self.config.T - current_round + 1, 1)
        
        # Discounted future rounds: geometric series
        gamma = self.config.gamma
        f_T = (1.0 - gamma ** T_rem) / (1.0 - gamma)
        
        score_gain = beta * (x - k) * f_T
        score_deficit = D * gap

        total_noise = self.sigma_estimate * math.sqrt(T_rem) + 1e-8

        z = (score_gain - score_deficit) / total_noise
        z = np.clip(z, -8.0, 8.0)

        return _norm_cdf(z)

    # ----------------------------------------------------------------
    # Data-driven environment model update
    # ----------------------------------------------------------------
    def _update_environment_model(self):
        n = len(self.scores)
        window = self.config.learning_window
        if n < max(3, window // 2):
            return

        start = max(0, n - window)
        x_window = np.array(self.investments[start:n])
        s_window = np.array(self.scores[start:n])

        self._update_beta(x_window, s_window)
        self._update_sigma(x_window, s_window)

    def _update_beta(self, x_window, s_window):
        x = x_window.astype(float)
        s = s_window.astype(float)

        idx = np.argsort(x)
        x_sorted = x[idx]
        s_sorted = s[idx]

        slopes = []
        for i in range(len(x_sorted) - 1):
            dx = x_sorted[i + 1] - x_sorted[i]
            if dx > 1e-6:
                slopes.append((s_sorted[i + 1] - s_sorted[i]) / dx)

        if not slopes:
            return

        beta_obs = float(np.median(slopes))

        n_eff = min(len(x_window), self.config.learning_window)
        obs_precision = n_eff / (self.sigma_estimate ** 2 + 1e-8)
        prior_precision = 1.0 / (self.beta_sigma ** 2 + 1e-8)

        post_precision = prior_precision + obs_precision
        self.beta_sigma = float(np.clip(np.sqrt(1.0 / post_precision), 0.01, 20.0))
        self.beta_mu = float((self.beta_mu * prior_precision + beta_obs * obs_precision) / post_precision)
        self.beta_mu = float(np.clip(self.beta_mu, 0.01, 20.0))

    def _update_sigma(self, x_window, s_window):
        x = x_window.astype(float)
        s = s_window.astype(float)

        x_mean = np.mean(x)
        s_mean = np.mean(s)
        x_var = np.var(x)

        if x_var < 1e-6:
            residuals = s - s_mean
        else:
            beta_obs = np.sum((x - x_mean) * (s - s_mean)) / (np.sum((x - x_mean) ** 2) + 1e-8)
            residuals = s - (s_mean + beta_obs * (x - x_mean))

        obs_std = float(np.std(residuals))
        obs_std = max(obs_std, 0.5)

        prior_weight = self.config.noise_prior_weight
        n_obs = len(x_window)
        alpha = n_obs / (n_obs + prior_weight)
        self.sigma_estimate = float(alpha * obs_std + (1.0 - alpha) * self.config.noise_prior)
        self.sigma_estimate = float(np.clip(self.sigma_estimate, 0.5, 50.0))

    # ----------------------------------------------------------------
    # Observation and rank update
    # ----------------------------------------------------------------
    def observe_result(self, investment: int, score: float):
        self.investments.append(investment)
        self.scores.append(score)

    def update_rank_information(self, new_rank: int):
        self.previous_rank = self.latest_rank
        self.latest_rank = new_rank

        self.previous_avg_score = self.latest_avg_score
        self.latest_avg_score = np.mean(self.scores)

        self._update_gap_estimate()
        self._update_k_estimate()
        self._update_ability_belief()
        self._update_competition_belief()

    def _update_gap_estimate(self):
        delta_rank = abs(self.latest_rank - self.previous_rank)
        if delta_rank == 0:
            return

        delta_score_avg = abs(self.latest_avg_score - self.previous_avg_score)
        current_round = len(self.scores)
        delta_cum = delta_score_avg * current_round

        observed_gap = delta_cum / delta_rank
        observed_gap = float(np.clip(observed_gap, 1.0, 500.0))

        alpha = 0.3
        self.gap_estimate = alpha * observed_gap + (1.0 - alpha) * self.gap_estimate

    def _update_k_estimate(self):
        current_round = len(self.scores)
        if current_round < self.config.rank_update_interval:
            return

        # 简单直接：如果排名下降，说明竞争更激烈了，需要增加k
        # 如果排名上升，说明竞争没那么激烈，可以减少k
        avg_x = np.mean(self.investments) if self.investments else float(self.k_estimate)
        D = self.latest_rank - self.config.cutoff_rank
        D_prev = self.previous_rank - self.config.cutoff_rank
        delta_D = D - D_prev

        # 根据排名变化调整k
        if delta_D > 0:
            # 排名下降了，说明需要投入更多才能保持位置
            k_obs = avg_x + 5.0
        elif delta_D < 0:
            # 排名上升了，说明投入可能过多了
            k_obs = avg_x - 5.0
        else:
            # 排名没变，k保持不变
            k_obs = avg_x

        k_obs = float(np.clip(k_obs, 0.0, float(self.config.E)))

        alpha = 0.3
        self.k_estimate = alpha * k_obs + (1.0 - alpha) * self.k_estimate

    # ----------------------------------------------------------------
    # Bayesian update for ability (self-assessment, kept for diagnostics)
    # ----------------------------------------------------------------
    def _update_ability_belief(self):
        window = self.config.belief_update_window
        if len(self.scores) < max(1, window):
            return

        recent_scores = np.array(self.scores[-window:])
        recent_investments = np.array(self.investments[-window:])

        avg_score = np.mean(recent_scores)
        avg_investment = np.mean(recent_investments) + 1e-8

        efficiency = avg_score / (avg_investment + 1.0)
        alpha = avg_investment / (self.config.E / 2)
        signal = efficiency / alpha

        tau = self.config.ability_signal_noise_std
        prior_mu = self.ability_mu
        prior_var = self.ability_sigma ** 2
        noise_var = tau ** 2

        post_var = 1.0 / (1.0 / prior_var + 1.0 / noise_var)
        post_mu = post_var * (prior_mu / prior_var + signal / noise_var)

        self.ability_mu = float(np.clip(post_mu, 0.05, 2.0))
        self.ability_sigma = float(np.clip(np.sqrt(post_var), 0.02, 0.5))

    # ----------------------------------------------------------------
    # Bayesian update for competition (self-assessment, kept for diagnostics)
    # ----------------------------------------------------------------
    def _update_competition_belief(self):
        if len(self.scores) < self.config.belief_update_window:
            return

        rank_change = self.latest_rank - self.previous_rank
        score_change = self.latest_avg_score - self.previous_avg_score

        baseline = self.competition_mu
        proxy = baseline - rank_change / self.config.N * self.config.E * 0.5 \
                + score_change / (self.config.average_score_per_round + 1e-8) * self.config.E * 0.5

        tau = self.config.competition_signal_noise_std
        prior_mu = self.competition_mu
        prior_var = self.competition_sigma ** 2
        noise_var = tau ** 2

        post_var = 1.0 / (1.0 / prior_var + 1.0 / noise_var)
        post_mu = post_var * (prior_mu / prior_var + proxy / noise_var)

        self.competition_mu = float(np.clip(post_mu, 0.0, self.config.E))
        self.competition_sigma = float(np.clip(np.sqrt(post_var), 1.0, self.config.E * 0.5))


# ============================================================
# 3. Environment
# ============================================================

class TournamentEnvironment:
    def __init__(self, config: GameConfig):
        self.config = config
        self.rng = np.random.default_rng(config.seed)
        self.agents = self._initialize_agents()
        self.round_records = []

    def _initialize_agents(self):
        agents = []
        true_abilities = self.rng.normal(
            self.config.ability_mean, self.config.ability_std, self.config.N
        )
        true_abilities = np.clip(true_abilities, 0.05, None)

        init_ability_mus = self.rng.normal(
            self.config.init_ability_mu,
            self.config.init_ability_sigma,
            self.config.N
        )
        init_ability_mus = np.clip(init_ability_mus, 0.05, 2.0)

        init_ability_sigmas = np.full(self.config.N, self.config.init_ability_sigma)

        init_competition_mus = self.rng.normal(
            self.config.init_competition_mu,
            self.config.init_competition_sigma,
            self.config.N
        )
        init_competition_mus = np.clip(init_competition_mus, 0.0, self.config.E)

        init_competition_sigmas = np.full(self.config.N, self.config.init_competition_sigma)

        if self.config.use_initial_private_rank:
            initial_rank_signal = init_ability_mus + self.rng.normal(
                0.0,
                self.config.initial_rank_signal_noise,
                self.config.N
            )
            initial_order = np.argsort(-initial_rank_signal)
            initial_ranks = np.empty(self.config.N, dtype=int)
            initial_ranks[initial_order] = np.arange(1, self.config.N + 1)
        else:
            initial_ranks = np.full(self.config.N, self.config.N // 2, dtype=int)

        for i in range(self.config.N):
            agent = BayesianAgent(
                agent_id=i,
                config=self.config,
                true_ability=true_abilities[i],
                initial_ability_mu=float(init_ability_mus[i]),
                initial_ability_sigma=float(init_ability_sigmas[i]),
                initial_competition_mu=float(init_competition_mus[i]),
                initial_competition_sigma=float(init_competition_sigmas[i])
            )

            agent.latest_rank = int(initial_ranks[i])
            agent.previous_rank = int(initial_ranks[i])

            agents.append(agent)
        return agents

    def run(self):
        for t in range(1, self.config.T + 1):
            self.run_one_round(t)
        final_df = self.build_final_agent_dataframe()
        round_df = pd.DataFrame(self.round_records)
        return round_df, final_df

    def run_one_round(self, current_round: int):
        investments = np.array([
            agent.decide_investment(current_round)
            for agent in self.agents
        ], dtype=float)

        abilities = np.array([agent.true_ability for agent in self.agents])
        scores = self.calculate_scores(investments, abilities)

        for agent, x, s in zip(self.agents, investments, scores):
            agent.observe_result(investment=int(x), score=float(s))

        if (current_round >= self.config.belief_update_window and
                current_round % self.config.belief_update_interval == 0):
            self.update_rankings()

        avg_inv = float(np.mean(investments))
        std_inv = float(np.std(investments))
        cv = std_inv / (avg_inv + 1e-8)
        lying_flat_ratio = float(np.mean(investments == 0))

        self.round_records.append({
            "round": current_round,
            "avg_investment": avg_inv,
            "cv_investment": cv,
            "lying_flat_ratio": lying_flat_ratio,
            "final_reward": self.config.final_reward,
            "ability_mean": self.config.ability_mean,
            "ability_std": self.config.ability_std,
            "ability_variance": self.config.ability_std ** 2
        })

    def calculate_scores(self, investments, abilities):
        logits = abilities * investments / self.config.kappa
        logits = logits - np.max(logits)
        weights = np.exp(logits)
        shares = weights / np.sum(weights)
        deterministic_scores = self.config.M * shares
        noise = self.rng.normal(
            self.config.epsilon_mean, self.config.epsilon_std, self.config.N
        )
        scores = deterministic_scores + noise
        scores = np.clip(scores, 0.0, None)
        return scores

    def update_rankings(self):
        avg_scores = np.array([np.mean(agent.scores) for agent in self.agents])
        order = np.argsort(-avg_scores)
        ranks = np.empty(self.config.N, dtype=int)
        ranks[order] = np.arange(1, self.config.N + 1)
        for agent, rank in zip(self.agents, ranks):
            agent.update_rank_information(int(rank))

    def build_final_agent_dataframe(self):
        final_rows = []
        avg_scores = np.array([np.mean(agent.scores) for agent in self.agents])
        order = np.argsort(-avg_scores)
        final_ranks = np.empty(self.config.N, dtype=int)
        final_ranks[order] = np.arange(1, self.config.N + 1)
        cutoff = self.config.cutoff_rank

        for agent, rank in zip(self.agents, final_ranks):
            total_inv = float(np.sum(agent.investments))
            uninvested = self.config.T * self.config.E - total_inv
            reward = self.config.final_reward if rank <= cutoff else 0.0
            final_wealth = uninvested + reward
            final_rows.append({
                "agent_id": agent.agent_id,
                "true_ability": agent.true_ability,
                "final_rank": int(rank),
                "avg_score": float(np.mean(agent.scores)),
                "total_investment": total_inv,
                "uninvested_wealth": uninvested,
                "reward": reward,
                "final_wealth": final_wealth,
                "final_ability_mu": agent.ability_mu,
                "final_ability_sigma": agent.ability_sigma,
                "final_competition_mu": agent.competition_mu,
                "final_competition_sigma": agent.competition_sigma
            })
        return pd.DataFrame(final_rows)


# ============================================================
# 4. Experiment Runners (with 20 seeds)
# ============================================================

def run_single_experiment(final_reward, ability_std, seed=42):
    config = GameConfig(final_reward=final_reward,
                        ability_std=ability_std,
                        seed=seed)
    env = TournamentEnvironment(config)
    round_df, final_df = env.run()
    return round_df, final_df


def run_multiple_seeds(rewards=(1, 500, 5000),
                       ability_std=np.sqrt(0.5),
                       seeds=tuple(range(0, 200, 10))):
    all_rounds = []
    all_finals = []

    for R in rewards:
        for seed in seeds:
            rdf, fdf = run_single_experiment(R, ability_std, seed)
            rdf["experiment"] = f"R={R}"
            rdf["seed"] = seed
            fdf["experiment"] = f"R={R}"
            fdf["seed"] = seed
            all_rounds.append(rdf)
            all_finals.append(fdf)

    round_df_all = pd.concat(all_rounds, ignore_index=True)
    final_df_all = pd.concat(all_finals, ignore_index=True)
    return round_df_all, final_df_all


if __name__ == "__main__":
    print("Running baseline experiments with 20 seeds...")
    round_df, final_df = run_multiple_seeds()

    os.makedirs("baseline/results", exist_ok=True)
    round_df.to_csv("baseline/results/round_summary.csv", index=False)
    final_df.to_csv("baseline/results/final_agents.csv", index=False)

    print("Round summary saved to baseline/results/round_summary.csv")
    print("Final agent data saved to baseline/results/final_agents.csv")
    print("Done!")